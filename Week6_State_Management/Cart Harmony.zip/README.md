# SmartCart — Global State Management Shopping App

A modern, production-ready shopping experience built for **Week 6 Frontend Development Internship**.
SmartCart demonstrates advanced state management with **Redux Toolkit**, full localStorage persistence,
reusable components, and a polished responsive UI.

> Author: **Muhammad Rashid Azam**

## Features

- 20+ curated products across Electronics, Clothing, Shoes, Accessories, and Home Decor
- Global state with Redux Toolkit (cart + preferences slices)
- Cart: add / remove / increase / decrease / clear with instant totals
- Theme toggle (Light / Dark) — applied app-wide
- Currency selector (USD / EUR / PKR) — prices update everywhere instantly
- Search by name & category, plus category / price / rating filters
- Product details page with stock status
- Settings page mirroring all preferences
- Architecture / Logic diagram page
- Full localStorage persistence — cart, theme, and currency survive refresh
- Responsive across mobile, tablet, and desktop
- Empty-cart, 404, and error boundaries

## Tech Stack

- React 19 + TanStack Start (Vite 7)
- Redux Toolkit + React Redux
- TanStack Router (file-based routing)
- Tailwind CSS v4 (design tokens)
- localStorage persistence
- Lucide icons

## Folder Structure

```
src/
├── app/store.ts                   # Redux store + typed hooks + persistence
├── features/
│   ├── cart/
│   │   ├── cartSlice.ts
│   │   └── CartItem.tsx
│   └── preferences/
│       └── preferenceSlice.ts
├── components/
│   ├── Navbar.tsx
│   ├── Footer.tsx
│   ├── ProductCard.tsx
│   ├── ProductGrid.tsx
│   ├── CartSummary.tsx
│   ├── ThemeToggle.tsx
│   ├── CurrencySelector.tsx
│   ├── SearchBar.tsx
│   ├── LoadingSpinner.tsx
│   └── Price.tsx
├── routes/
│   ├── __root.tsx                 # Providers + layout shell
│   ├── index.tsx                  # Home (hero + filters + products)
│   ├── product.$id.tsx            # Product details
│   ├── cart.tsx                   # Cart page
│   ├── settings.tsx               # Theme + currency settings
│   └── logic.tsx                  # Architecture diagram
├── data/products.ts
├── utils/
│   ├── localStorage.ts
│   └── currencyConverter.ts
└── styles.css                     # Design tokens (Tailwind v4)
```

## Redux Architecture

```
cart slice                       preferences slice
─────────                        ────────────────
state:                           state:
  cartItems[]                      theme: light | dark
  totalQuantity                    currency: USD | EUR | PKR
  totalAmount
actions:                         actions:
  addToCart                        toggleTheme / setTheme
  removeFromCart                   changeCurrency
  increaseQuantity
  decreaseQuantity
  clearCart
  calculateTotals
```

The store subscribes to every change and writes `cartItems` + `preferences`
to `localStorage`. On boot, both slices initialise from localStorage.

## Logic Diagram

```
Products
   │
   ▼
Add To Cart
   │
   ▼
Redux Store
   │
 ┌─┴─┐
 ▼   ▼
Cart  Preferences
 │       │
 ▼       ▼
UI Updates  LocalStorage
        │
        ▼
   Persistent Data
```

## Installation

```bash
bun install
bun run dev
```

Then open the printed preview URL.

## Production Build

```bash
bun run build
```

## Deployment

Deploy from the Lovable Publish dialog, or push to GitHub and deploy on Vercel.

## Screenshots

_Add screenshots here after publishing:_

- ![Home](./screenshots/home.png)
- ![Cart](./screenshots/cart.png)
- ![Settings](./screenshots/settings.png)

## Live Demo

_Replace with your deployed URL._

## GitHub Repository

_Replace with your repo URL._
