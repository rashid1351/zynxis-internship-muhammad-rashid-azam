export type Currency = "USD" | "PKR" | "EUR";

export const RATES: Record<Currency, number> = {
  USD: 1,
  EUR: 0.92,
  PKR: 278,
};

export const SYMBOLS: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  PKR: "₨",
};

export const convert = (usd: number, currency: Currency) => usd * RATES[currency];

export const formatPrice = (usd: number, currency: Currency) => {
  const value = convert(usd, currency);
  const formatted = currency === "PKR"
    ? Math.round(value).toLocaleString()
    : value.toFixed(2);
  return `${SYMBOLS[currency]}${formatted}`;
};
