import { Moon, Sun } from "lucide-react";
import { useAppDispatch, useAppSelector } from "../app/store";
import { toggleTheme } from "../features/preferences/preferenceSlice";

export function ThemeToggle() {
  const theme = useAppSelector((s) => s.preferences.theme);
  const dispatch = useAppDispatch();
  return (
    <button
      onClick={() => dispatch(toggleTheme())}
      className="btn-ghost !p-2"
      aria-label="Toggle theme"
    >
      {theme === "light" ? <Moon className="size-4" /> : <Sun className="size-4" />}
    </button>
  );
}
