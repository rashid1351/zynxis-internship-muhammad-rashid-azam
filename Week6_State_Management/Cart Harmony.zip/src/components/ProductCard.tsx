import { Link } from "@tanstack/react-router";
import { ShoppingCart, Star } from "lucide-react";
import type { Product } from "../data/products";
import { useAppDispatch } from "../app/store";
import { addToCart } from "../features/cart/cartSlice";
import { Price } from "./Price";
import { ProductImage } from "./ProductImage";


export function ProductCard({ product }: { product: Product }) {
  const dispatch = useAppDispatch();
  return (
    <div className="card-surface card-tilt group flex flex-col overflow-hidden">
      <Link
        to="/product/$id"
        params={{ id: product.id }}
        className="relative block aspect-square overflow-hidden bg-muted"
      >
        <ProductImage
          src={product.image}
          alt={product.name}
          seed={product.id}
          className="h-full w-full object-cover transition duration-700 ease-out group-hover:scale-110"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 transition group-hover:opacity-100" />
        <span className="pointer-events-none absolute -left-1/3 top-0 h-full w-1/3 -skew-x-12 bg-white/20 opacity-0 transition duration-700 group-hover:left-[120%] group-hover:opacity-100" />
      </Link>
      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-center justify-between text-xs">
          <span className="rounded-full bg-secondary px-2 py-0.5 text-secondary-foreground">
            {product.category}
          </span>
          <span className="inline-flex items-center gap-1 text-muted-foreground">
            <Star className="size-3 fill-current text-accent" /> {product.rating}
          </span>
        </div>
        <Link to="/product/$id" params={{ id: product.id }}>
          <h3 className="line-clamp-2 text-base font-semibold leading-snug">
            {product.name}
          </h3>
        </Link>
        <div className="mt-auto flex items-center justify-between">
          <Price usd={product.price} className="text-lg font-bold" />
          <div className="flex gap-2">
            <Link
              to="/product/$id"
              params={{ id: product.id }}
              className="btn-ghost !px-3 !py-2 text-xs"
            >
              Details
            </Link>
            <button
              onClick={() =>
                dispatch(
                  addToCart({
                    id: product.id,
                    name: product.name,
                    image: product.image,
                    price: product.price,
                  }),
                )
              }
              className="btn-primary !px-3 !py-2 text-xs"
              aria-label={`Add ${product.name} to cart`}
            >
              <ShoppingCart className="size-3.5" />
              Add
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
