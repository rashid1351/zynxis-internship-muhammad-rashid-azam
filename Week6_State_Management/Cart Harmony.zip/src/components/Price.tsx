import { useAppSelector } from "../app/store";
import { formatPrice } from "../utils/currencyConverter";

export function Price({ usd, className = "" }: { usd: number; className?: string }) {
  const currency = useAppSelector((s) => s.preferences.currency);
  return <span className={className}>{formatPrice(usd, currency)}</span>;
}
