import { useAppDispatch, useAppSelector } from "../app/store";
import { changeCurrency } from "../features/preferences/preferenceSlice";
import type { Currency } from "../utils/currencyConverter";

export function CurrencySelector({ compact = false }: { compact?: boolean }) {
  const currency = useAppSelector((s) => s.preferences.currency);
  const dispatch = useAppDispatch();
  return (
    <select
      value={currency}
      onChange={(e) => dispatch(changeCurrency(e.target.value as Currency))}
      className={`rounded-lg border border-input bg-card text-sm outline-none focus:border-primary ${
        compact ? "px-2 py-1.5" : "px-3 py-2"
      }`}
      aria-label="Select currency"
    >
      <option value="USD">USD</option>
      <option value="EUR">EUR</option>
      <option value="PKR">PKR</option>
    </select>
  );
}
