import logoAsset from "../assets/smartcart-logo.png.asset.json";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-border/60 bg-card/40">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2">
            <img src={logoAsset.url} alt="SmartCart logo" className="size-10 object-contain" />
            <h3 className="font-display text-lg font-bold">SmartCart</h3>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            A global state management shopping experience built with React and Redux Toolkit.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold">Shop</h4>
          <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
            <li>Electronics</li>
            <li>Clothing</li>
            <li>Shoes</li>
            <li>Accessories</li>
            <li>Home Decor</li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Project</h4>
          <p className="mt-2 text-sm text-muted-foreground">
            Week 6 Frontend Internship Project<br />
            by Muhammad Rashid Azam
          </p>
        </div>
      </div>
      <div className="border-t border-border/60 py-4 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} SmartCart. All rights reserved.
      </div>
    </footer>
  );
}
