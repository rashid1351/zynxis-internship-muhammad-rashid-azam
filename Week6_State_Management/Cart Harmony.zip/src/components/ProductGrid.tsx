import type { Product } from "../data/products";
import { ProductCard } from "./ProductCard";

export function ProductGrid({ products }: { products: Product[] }) {
  if (products.length === 0) {
    return (
      <div className="card-surface p-10 text-center">
        <p className="text-lg font-medium">No products found</p>
        <p className="mt-1 text-sm text-muted-foreground">
          Try adjusting your filters or search query.
        </p>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {products.map((p, i) => (
        <div
          key={p.id}
          className="animate-fade-in-up"
          style={{ animationDelay: `${Math.min(i, 8) * 60}ms` }}
        >
          <ProductCard product={p} />
        </div>
      ))}
    </div>
  );
}
