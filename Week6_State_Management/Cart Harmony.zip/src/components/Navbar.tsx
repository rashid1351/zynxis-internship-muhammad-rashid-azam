import { Link } from "@tanstack/react-router";
import { ShoppingBag, Settings as SettingsIcon, Home, Network } from "lucide-react";
import { useAppSelector } from "../app/store";
import { ThemeToggle } from "./ThemeToggle";
import { CurrencySelector } from "./CurrencySelector";
import logoAsset from "../assets/smartcart-logo.png.asset.json";

export function Navbar() {
  const totalQuantity = useAppSelector((s) => s.cart.totalQuantity);

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <img
            src={logoAsset.url}
            alt="SmartCart logo"
            className="size-9 rounded-lg object-contain"
          />
          <span className="font-display text-xl font-bold tracking-tight">
            SmartCart
          </span>
        </Link>


        <nav className="hidden items-center gap-1 md:flex">
          <NavLink to="/" icon={<Home className="size-4" />} label="Home" />
          <NavLink to="/cart" icon={<ShoppingBag className="size-4" />} label="Cart" />
          <NavLink to="/settings" icon={<SettingsIcon className="size-4" />} label="Settings" />
          <NavLink to="/logic" icon={<Network className="size-4" />} label="Logic" />
        </nav>

        <div className="flex items-center gap-2">
          <div className="hidden sm:block">
            <CurrencySelector compact />
          </div>
          <ThemeToggle />
          <Link
            to="/cart"
            className="relative inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition hover:brightness-105"
          >
            <ShoppingBag className="size-4" />
            <span className="hidden sm:inline">Cart</span>
            {totalQuantity > 0 && (
              <span
                key={totalQuantity}
                className="animate-badge-pop ml-1 grid min-w-5 place-items-center rounded-full bg-accent px-1.5 text-xs font-bold text-accent-foreground"
              >
                {totalQuantity}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}

function NavLink({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      to={to}
      activeProps={{ className: "bg-muted text-foreground" }}
      activeOptions={{ exact: to === "/" }}
      className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition hover:bg-muted hover:text-foreground"
    >
      {icon}
      {label}
    </Link>
  );
}
