import { useState } from "react";

export function ProductImage({
  src,
  alt,
  seed,
  className = "",
}: {
  src: string;
  alt: string;
  seed: string;
  className?: string;
}) {
  const [current, setCurrent] = useState(src);
  return (
    <img
      src={current}
      alt={alt}
      loading="lazy"
      className={className}
      onError={() => {
        const fallback = `https://picsum.photos/seed/${encodeURIComponent(seed)}/800/800`;
        if (current !== fallback) setCurrent(fallback);
      }}
    />
  );
}
