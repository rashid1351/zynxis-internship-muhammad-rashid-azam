import { Link } from "@tanstack/react-router";
import { useAppSelector } from "../app/store";
import { Price } from "./Price";

export function CartSummary({ showCheckout = true }: { showCheckout?: boolean }) {
  const { cartItems, totalQuantity, totalAmount } = useAppSelector((s) => s.cart);
  return (
    <aside className="card-surface sticky top-24 h-fit p-6">
      <h3 className="font-display text-xl font-bold">Order Summary</h3>
      <dl className="mt-4 space-y-3 text-sm">
        <Row label="Total Products" value={String(cartItems.length)} />
        <Row label="Total Quantity" value={String(totalQuantity)} />
        <div className="my-3 border-t border-border" />
        <div className="flex items-center justify-between">
          <dt className="font-semibold">Total</dt>
          <dd className="font-display text-2xl font-bold">
            <Price usd={totalAmount} />
          </dd>
        </div>
      </dl>
      {showCheckout && (
        <button
          disabled={cartItems.length === 0}
          className="btn-primary mt-6 w-full disabled:cursor-not-allowed disabled:opacity-50"
          onClick={() => alert("Checkout flow would start here.")}
        >
          Proceed to Checkout
        </button>
      )}
      {cartItems.length === 0 && (
        <Link to="/" className="btn-ghost mt-3 w-full">
          Continue Shopping
        </Link>
      )}
    </aside>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-muted-foreground">
      <dt>{label}</dt>
      <dd className="font-medium text-foreground">{value}</dd>
    </div>
  );
}
