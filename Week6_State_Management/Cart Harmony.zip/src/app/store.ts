import { configureStore } from "@reduxjs/toolkit";
import { useDispatch, useSelector, type TypedUseSelectorHook } from "react-redux";
import cartReducer from "../features/cart/cartSlice";
import preferencesReducer from "../features/preferences/preferenceSlice";
import { saveState } from "../utils/localStorage";

export const store = configureStore({
  reducer: {
    cart: cartReducer,
    preferences: preferencesReducer,
  },
});

// Persist to localStorage
store.subscribe(() => {
  const state = store.getState();
  saveState("smartcart_cart", state.cart.cartItems);
  saveState("smartcart_prefs", state.preferences);
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
