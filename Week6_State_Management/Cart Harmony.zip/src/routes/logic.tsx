import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/logic")({
  head: () => ({
    meta: [
      { title: "Architecture — SmartCart" },
      { name: "description", content: "How Redux state flows through SmartCart." },
    ],
  }),
  component: LogicPage,
});

const Box = ({ children, accent = false }: { children: React.ReactNode; accent?: boolean }) => (
  <div
    className={`rounded-xl border px-5 py-3 text-center font-semibold ${
      accent
        ? "border-primary bg-primary/10 text-primary"
        : "border-border bg-card text-foreground"
    }`}
  >
    {children}
  </div>
);

const Arrow = () => (
  <div className="flex justify-center text-muted-foreground">
    <svg width="20" height="28" viewBox="0 0 20 28" fill="none">
      <line x1="10" y1="0" x2="10" y2="20" stroke="currentColor" strokeWidth="2" />
      <polyline points="4,16 10,24 16,16" stroke="currentColor" strokeWidth="2" fill="none" />
    </svg>
  </div>
);

function LogicPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-4xl font-bold">Architecture & Logic</h1>
      <p className="mt-2 text-muted-foreground">
        SmartCart uses Redux Toolkit as a single source of truth. Every action flows through
        the store, updates the UI reactively, and persists to localStorage.
      </p>

      <div className="card-surface mt-8 space-y-2 p-8">
        <Box>Products Catalog</Box>
        <Arrow />
        <Box>Add to Cart Action</Box>
        <Arrow />
        <Box accent>Redux Store</Box>
        <Arrow />
        <div className="grid grid-cols-2 gap-4">
          <Box>Cart Slice</Box>
          <Box>Preferences Slice</Box>
        </div>
        <Arrow />
        <div className="grid grid-cols-2 gap-4">
          <Box>UI Re-renders</Box>
          <Box>localStorage</Box>
        </div>
        <Arrow />
        <Box accent>Persistent Data — survives refresh</Box>
      </div>

      <div className="mt-10 grid gap-4 md:grid-cols-2">
        <Section title="Cart Slice">
          <li>cartItems, totalQuantity, totalAmount</li>
          <li>addToCart, removeFromCart</li>
          <li>increaseQuantity, decreaseQuantity</li>
          <li>clearCart, calculateTotals</li>
        </Section>
        <Section title="Preferences Slice">
          <li>theme: light | dark</li>
          <li>currency: USD | EUR | PKR</li>
          <li>toggleTheme, setTheme</li>
          <li>changeCurrency</li>
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="card-surface p-6">
      <h3 className="font-display text-lg font-bold">{title}</h3>
      <ul className="mt-3 space-y-1 text-sm text-muted-foreground [&>li]:before:mr-2 [&>li]:before:text-primary [&>li]:before:content-['•']">
        {children}
      </ul>
    </div>
  );
}
