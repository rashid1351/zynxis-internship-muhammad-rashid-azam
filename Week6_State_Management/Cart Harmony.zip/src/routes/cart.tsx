import { createFileRoute, Link } from "@tanstack/react-router";
import { ShoppingBag, Trash2 } from "lucide-react";
import { useAppDispatch, useAppSelector } from "../app/store";
import { clearCart } from "../features/cart/cartSlice";
import { CartItem } from "../features/cart/CartItem";
import { CartSummary } from "../components/CartSummary";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart — SmartCart" },
      { name: "description", content: "Review items in your cart and proceed to checkout." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const items = useAppSelector((s) => s.cart.cartItems);
  const dispatch = useAppDispatch();

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-bold">Your Cart</h1>
          <p className="text-sm text-muted-foreground">
            {items.length} {items.length === 1 ? "item" : "items"} in your bag
          </p>
        </div>
        {items.length > 0 && (
          <button
            onClick={() => dispatch(clearCart())}
            className="btn-ghost text-destructive hover:!bg-destructive/10"
          >
            <Trash2 className="size-4" />
            Clear cart
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="card-surface mx-auto max-w-lg p-12 text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-full bg-muted">
            <ShoppingBag className="size-6 text-muted-foreground" />
          </div>
          <h2 className="mt-4 font-display text-2xl font-bold">Your cart is empty</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Discover handpicked products and start filling your bag.
          </p>
          <Link to="/" className="btn-primary mt-6 inline-flex">Start Shopping</Link>
        </div>
      ) : (
        <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
          <div className="space-y-4">
            {items.map((item) => (
              <CartItem key={item.id} item={item} />
            ))}
          </div>
          <CartSummary />
        </div>
      )}
    </div>
  );
}
