import { createFileRoute } from "@tanstack/react-router";
import { Moon, Sun } from "lucide-react";
import { useAppDispatch, useAppSelector } from "../app/store";
import { setTheme, changeCurrency } from "../features/preferences/preferenceSlice";
import type { Currency } from "../utils/currencyConverter";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — SmartCart" },
      { name: "description", content: "Manage your SmartCart theme and currency preferences." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { theme, currency } = useAppSelector((s) => s.preferences);
  const dispatch = useAppDispatch();

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <h1 className="font-display text-4xl font-bold">Settings</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Preferences are stored globally with Redux and persisted to localStorage.
      </p>

      <section className="card-surface mt-8 p-6">
        <h2 className="font-display text-xl font-bold">Theme</h2>
        <p className="text-sm text-muted-foreground">Choose how SmartCart looks.</p>
        <div className="mt-4 grid grid-cols-2 gap-3">
          {(["light", "dark"] as const).map((t) => (
            <button
              key={t}
              onClick={() => dispatch(setTheme(t))}
              className={`flex items-center justify-center gap-2 rounded-lg border p-4 text-sm font-semibold transition ${
                theme === t
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border hover:border-primary/50"
              }`}
            >
              {t === "light" ? <Sun className="size-4" /> : <Moon className="size-4" />}
              {t === "light" ? "Light" : "Dark"}
            </button>
          ))}
        </div>
      </section>

      <section className="card-surface mt-6 p-6">
        <h2 className="font-display text-xl font-bold">Currency</h2>
        <p className="text-sm text-muted-foreground">All prices update instantly across the app.</p>
        <div className="mt-4 grid grid-cols-3 gap-3">
          {(["USD", "EUR", "PKR"] as Currency[]).map((c) => (
            <button
              key={c}
              onClick={() => dispatch(changeCurrency(c))}
              className={`rounded-lg border p-4 text-sm font-semibold transition ${
                currency === c
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border hover:border-primary/50"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
