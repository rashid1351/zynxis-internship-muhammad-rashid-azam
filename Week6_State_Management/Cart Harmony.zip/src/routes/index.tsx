import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Sparkles, Star } from "lucide-react";
import { products, categories } from "../data/products";
import { ProductGrid } from "../components/ProductGrid";
import { ProductImage } from "../components/ProductImage";
import { SearchBar } from "../components/SearchBar";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SmartCart — Shop Smarter, Globally" },
      { name: "description", content: "Browse 20+ curated products across electronics, fashion, and home decor. Powered by Redux Toolkit global state." },
    ],
  }),
  component: Home,
});

function Home() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<(typeof categories)[number]>("All");
  const [minRating, setMinRating] = useState(0);
  const [maxPrice, setMaxPrice] = useState(500);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (category !== "All" && p.category !== category) return false;
      if (p.rating < minRating) return false;
      if (p.price > maxPrice) return false;
      if (q && !p.name.toLowerCase().includes(q) && !p.category.toLowerCase().includes(q))
        return false;
      return true;
    });
  }, [query, category, minRating, maxPrice]);

  const featured = products.slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border/60 bg-gradient-to-br from-primary/10 via-background to-accent/10">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 md:grid-cols-2 md:py-24">
          <div className="animate-fade-in-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
              <Sparkles className="size-3.5 text-primary" />
              Week 6 Internship Project
            </span>
            <h1 className="mt-4 font-display text-5xl font-bold leading-[1.05] sm:text-6xl">
              Shop smarter with a cart that <span className="text-gradient">remembers</span> everything.
            </h1>

            <p className="mt-4 max-w-lg text-base text-muted-foreground">
              SmartCart is a complete e-commerce experience powered by React, Redux Toolkit
              and localStorage persistence. Your cart, theme, and currency travel with you.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#products" className="btn-primary">Browse Products</a>
              <Link to="/logic" className="btn-ghost">View Architecture</Link>
            </div>
          </div>
          <div className="relative">
            <div className="pointer-events-none absolute -inset-6 -z-10">
              <div className="absolute -left-10 top-0 size-56 rounded-full bg-primary/30 blur-3xl animate-blob" />
              <div className="absolute -bottom-10 right-0 size-72 rounded-full bg-accent/30 blur-3xl animate-blob [animation-delay:-3s]" />
            </div>
            <div className="card-surface grid grid-cols-2 gap-3 p-3 animate-float">
              {featured.map((p, i) => (
                <Link
                  key={p.id}
                  to="/product/$id"
                  params={{ id: p.id }}
                  className="group relative aspect-square overflow-hidden rounded-xl animate-fade-in-up"
                  style={{ animationDelay: `${i * 90}ms` }}
                >
                  <ProductImage
                    src={p.image}
                    alt={p.name}
                    seed={p.id}
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-3 text-white">
                    <p className="text-xs opacity-80">{p.category}</p>
                    <p className="line-clamp-1 text-sm font-semibold">{p.name}</p>
                  </div>
                </Link>
              ))}
            </div>

          </div>
        </div>
      </section>

      {/* Filters + Products */}
      <section id="products" className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="font-display text-3xl font-bold">All Products</h2>
            <p className="text-sm text-muted-foreground">
              {filtered.length} of {products.length} products
            </p>
          </div>
          <div className="w-full md:max-w-sm">
            <SearchBar value={query} onChange={setQuery} />
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
          <aside className="card-surface h-fit space-y-6 p-5">
            <div>
              <h3 className="mb-3 text-sm font-semibold">Category</h3>
              <div className="flex flex-wrap gap-2">
                {categories.map((c) => (
                  <button
                    key={c}
                    onClick={() => setCategory(c)}
                    className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
                      category === c
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-card text-muted-foreground hover:border-primary/50"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h3 className="mb-3 text-sm font-semibold">Max Price (USD)</h3>
              <input
                type="range"
                min={20}
                max={500}
                step={10}
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[var(--color-primary)]"
              />
              <div className="mt-1 flex justify-between text-xs text-muted-foreground">
                <span>$20</span>
                <span className="font-semibold text-foreground">${maxPrice}</span>
                <span>$500</span>
              </div>
            </div>
            <div>
              <h3 className="mb-3 text-sm font-semibold">Min Rating</h3>
              <div className="flex gap-1">
                {[0, 3, 4, 4.5].map((r) => (
                  <button
                    key={r}
                    onClick={() => setMinRating(r)}
                    className={`inline-flex flex-1 items-center justify-center gap-1 rounded-md border px-2 py-1.5 text-xs transition ${
                      minRating === r
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border text-muted-foreground hover:border-primary/50"
                    }`}
                  >
                    {r === 0 ? "Any" : (
                      <>
                        <Star className="size-3 fill-current" />
                        {r}+
                      </>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </aside>

          <ProductGrid products={filtered} />
        </div>
      </section>
    </div>
  );
}
