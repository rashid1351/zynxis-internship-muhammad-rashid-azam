import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ShoppingCart, Star } from "lucide-react";
import { products } from "../data/products";
import { useAppDispatch } from "../app/store";
import { addToCart } from "../features/cart/cartSlice";
import { Price } from "../components/Price";
import { ProductImage } from "../components/ProductImage";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    const product = products.find((p) => p.id === params.id);
    if (!product) throw notFound();
    return product;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.name} — SmartCart` : "Product — SmartCart" },
      { name: "description", content: loaderData?.description ?? "Product details" },
      { property: "og:title", content: loaderData?.name ?? "Product" },
      { property: "og:description", content: loaderData?.description ?? "" },
      { property: "og:image", content: loaderData?.image ?? "" },
    ],
  }),
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-6 py-20 text-center">
      <h1 className="font-display text-3xl font-bold">Product not found</h1>
      <p className="mt-2 text-muted-foreground">
        That item may have sold out or moved.
      </p>
      <Link to="/" className="btn-primary mt-6">Back to shop</Link>
    </div>
  ),
  component: ProductDetailsPage,
});

function ProductDetailsPage() {
  const product = Route.useLoaderData();
  const dispatch = useAppDispatch();

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 animate-fade-in-up">
      <Link to="/" className="btn-ghost mb-6 !px-3 !py-1.5 text-xs">
        <ArrowLeft className="size-3.5" /> Back to products
      </Link>
      <div className="grid gap-10 md:grid-cols-2">
        <div className="card-surface overflow-hidden">
          <ProductImage
            src={product.image}
            alt={product.name}
            seed={product.id}
            className="aspect-square w-full object-cover transition duration-700 hover:scale-105"
          />
        </div>
        <div>
          <span className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
            {product.category}
          </span>
          <h1 className="mt-3 font-display text-4xl font-bold leading-tight">{product.name}</h1>
          <div className="mt-2 inline-flex items-center gap-1 text-sm text-muted-foreground">
            <Star className="size-4 fill-current text-accent" /> {product.rating} rating
          </div>
          <p className="mt-5 text-base text-muted-foreground">{product.description}</p>
          <div className="mt-6 flex items-end gap-3">
            <Price usd={product.price} className="font-display text-4xl font-bold" />
            <span
              className={`mb-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
                product.stock > 0
                  ? "bg-primary/10 text-primary"
                  : "bg-destructive/10 text-destructive"
              }`}
            >
              {product.stock > 0 ? `${product.stock} in stock` : "Out of stock"}
            </span>
          </div>
          <button
            onClick={() =>
              dispatch(
                addToCart({
                  id: product.id,
                  name: product.name,
                  image: product.image,
                  price: product.price,
                }),
              )
            }
            disabled={product.stock === 0}
            className="btn-primary mt-8 w-full sm:w-auto"
          >
            <ShoppingCart className="size-4" />
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
