import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { loadState } from "../../utils/localStorage";
import type { Currency } from "../../utils/currencyConverter";

type Theme = "light" | "dark";

type PreferencesState = {
  theme: Theme;
  currency: Currency;
};

const initialState: PreferencesState = loadState<PreferencesState>("smartcart_prefs", {
  theme: "light",
  currency: "USD",
});

const preferenceSlice = createSlice({
  name: "preferences",
  initialState,
  reducers: {
    toggleTheme(state) {
      state.theme = state.theme === "light" ? "dark" : "light";
    },
    setTheme(state, action: PayloadAction<Theme>) {
      state.theme = action.payload;
    },
    changeCurrency(state, action: PayloadAction<Currency>) {
      state.currency = action.payload;
    },
  },
});

export const { toggleTheme, setTheme, changeCurrency } = preferenceSlice.actions;
export default preferenceSlice.reducer;
