import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { loadState } from "../../utils/localStorage";

export type CartItem = {
  id: string;
  name: string;
  image: string;
  price: number; // USD
  quantity: number;
};

type CartState = {
  cartItems: CartItem[];
  totalQuantity: number;
  totalAmount: number;
};

const calc = (items: CartItem[]) => ({
  totalQuantity: items.reduce((s, i) => s + i.quantity, 0),
  totalAmount: items.reduce((s, i) => s + i.quantity * i.price, 0),
});

const persisted = loadState<CartItem[]>("smartcart_cart", []);

const initialState: CartState = {
  cartItems: persisted,
  ...calc(persisted),
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addToCart(state, action: PayloadAction<Omit<CartItem, "quantity"> & { quantity?: number }>) {
      const { id, name, image, price, quantity = 1 } = action.payload;
      const existing = state.cartItems.find((i) => i.id === id);
      if (existing) existing.quantity += quantity;
      else state.cartItems.push({ id, name, image, price, quantity });
      Object.assign(state, calc(state.cartItems));
    },
    removeFromCart(state, action: PayloadAction<string>) {
      state.cartItems = state.cartItems.filter((i) => i.id !== action.payload);
      Object.assign(state, calc(state.cartItems));
    },
    increaseQuantity(state, action: PayloadAction<string>) {
      const item = state.cartItems.find((i) => i.id === action.payload);
      if (item) item.quantity += 1;
      Object.assign(state, calc(state.cartItems));
    },
    decreaseQuantity(state, action: PayloadAction<string>) {
      const item = state.cartItems.find((i) => i.id === action.payload);
      if (item) {
        item.quantity -= 1;
        if (item.quantity <= 0) {
          state.cartItems = state.cartItems.filter((i) => i.id !== action.payload);
        }
      }
      Object.assign(state, calc(state.cartItems));
    },
    clearCart(state) {
      state.cartItems = [];
      state.totalAmount = 0;
      state.totalQuantity = 0;
    },
    calculateTotals(state) {
      Object.assign(state, calc(state.cartItems));
    },
  },
});

export const {
  addToCart,
  removeFromCart,
  increaseQuantity,
  decreaseQuantity,
  clearCart,
  calculateTotals,
} = cartSlice.actions;

export default cartSlice.reducer;
