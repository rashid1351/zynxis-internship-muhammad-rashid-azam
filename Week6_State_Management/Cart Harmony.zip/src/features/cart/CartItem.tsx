import { Minus, Plus, Trash2 } from "lucide-react";
import { useAppDispatch } from "../../app/store";
import {
  decreaseQuantity,
  increaseQuantity,
  removeFromCart,
  type CartItem as CartItemType,
} from "./cartSlice";
import { Price } from "../../components/Price";
import { ProductImage } from "../../components/ProductImage";

export function CartItem({ item }: { item: CartItemType }) {
  const dispatch = useAppDispatch();
  return (
    <div className="card-surface flex gap-4 p-4 animate-fade-in-up">
      <ProductImage
        src={item.image}
        alt={item.name}
        seed={item.id}
        className="size-24 shrink-0 rounded-lg object-cover"
      />

      <div className="flex flex-1 flex-col">
        <div className="flex items-start justify-between gap-3">
          <h4 className="font-semibold leading-snug">{item.name}</h4>
          <button
            onClick={() => dispatch(removeFromCart(item.id))}
            className="text-muted-foreground hover:text-destructive"
            aria-label="Remove item"
          >
            <Trash2 className="size-4" />
          </button>
        </div>
        <Price usd={item.price} className="mt-1 text-sm text-muted-foreground" />
        <div className="mt-auto flex items-center justify-between">
          <div className="inline-flex items-center rounded-lg border border-border">
            <button
              onClick={() => dispatch(decreaseQuantity(item.id))}
              className="p-2 hover:bg-muted"
              aria-label="Decrease quantity"
            >
              <Minus className="size-3.5" />
            </button>
            <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
            <button
              onClick={() => dispatch(increaseQuantity(item.id))}
              className="p-2 hover:bg-muted"
              aria-label="Increase quantity"
            >
              <Plus className="size-3.5" />
            </button>
          </div>
          <Price usd={item.price * item.quantity} className="font-display text-lg font-bold" />
        </div>
      </div>
    </div>
  );
}
