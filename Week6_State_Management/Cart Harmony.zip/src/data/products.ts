export type Product = {
  id: string;
  name: string;
  image: string;
  category: "Electronics" | "Clothing" | "Shoes" | "Accessories" | "Home Decor";
  description: string;
  price: number; // USD
  rating: number;
  stock: number;
};

// Verified Unsplash photo IDs. If any fail at runtime, ProductImage falls
// back to a deterministic picsum image keyed by the product id.
const img = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=800&q=70`;

export const products: Product[] = [
  { id: "p1", name: "Aurora Wireless Headphones", image: img("photo-1505740420928-5e560c06d30e"), category: "Electronics", description: "Studio-grade over-ear headphones with active noise cancellation and 40-hour battery.", price: 199, rating: 4.7, stock: 24 },
  { id: "p2", name: "Nimbus Smartwatch S3", image: img("photo-1523275335684-37898b6baf30"), category: "Electronics", description: "Track health, runs, and notifications with a vivid AMOLED display.", price: 249, rating: 4.5, stock: 18 },
  { id: "p3", name: "Echo Bluetooth Speaker", image: img("photo-1608043152269-423dbba4e7e1"), category: "Electronics", description: "Pocket-sized speaker with deep bass and IPX7 waterproofing.", price: 79, rating: 4.4, stock: 50 },
  { id: "p4", name: "Pulse 4K Action Cam", image: img("photo-1516035069371-29a1b244cc32"), category: "Electronics", description: "Rugged 4K60 action camera with built-in stabilization.", price: 329, rating: 4.6, stock: 12 },
  { id: "p5", name: "Linen Oversized Shirt", image: img("photo-1521572163474-6864f9cf17ab"), category: "Clothing", description: "Breathable European linen with a relaxed silhouette.", price: 65, rating: 4.3, stock: 40 },
  { id: "p6", name: "Heritage Denim Jacket", image: img("photo-1551028719-00167b16eac5"), category: "Clothing", description: "Selvedge denim jacket that ages beautifully.", price: 120, rating: 4.6, stock: 22 },
  { id: "p7", name: "Merino Crew Sweater", image: img("photo-1576566588028-4147f3842f27"), category: "Clothing", description: "Soft 100% merino wool, warm yet lightweight.", price: 95, rating: 4.5, stock: 35 },
  { id: "p8", name: "Performance Joggers", image: img("photo-1552902865-b72c031ac5ea"), category: "Clothing", description: "Four-way stretch joggers built for movement.", price: 58, rating: 4.2, stock: 60 },
  { id: "p9", name: "Trailblazer Runners", image: img("photo-1542291026-7eec264c27ff"), category: "Shoes", description: "Cushioned trail runners with grippy outsole.", price: 140, rating: 4.7, stock: 30 },
  { id: "p10", name: "Classic Leather Sneakers", image: img("photo-1600185365926-3a2ce3cdb9eb"), category: "Shoes", description: "Minimal leather sneakers that pair with anything.", price: 110, rating: 4.4, stock: 45 },
  { id: "p11", name: "Cloudwalk Loafers", image: img("photo-1533867617858-e7b97e060509"), category: "Shoes", description: "All-day comfort loafers in suede.", price: 130, rating: 4.3, stock: 18 },
  { id: "p12", name: "Storm Hiking Boots", image: img("photo-1520639888713-7851133b1ed0"), category: "Shoes", description: "Waterproof boots for serious terrain.", price: 180, rating: 4.6, stock: 14 },
  { id: "p13", name: "Eclipse Aviator Sunglasses", image: img("photo-1572635196237-14b3f281503f"), category: "Accessories", description: "Polarized lenses, lightweight titanium frame.", price: 145, rating: 4.5, stock: 28 },
  { id: "p14", name: "Voyager Leather Wallet", image: img("photo-1627123424574-724758594e93"), category: "Accessories", description: "Slim bifold in full-grain Italian leather.", price: 75, rating: 4.6, stock: 50 },
  { id: "p15", name: "Atlas Canvas Backpack", image: img("photo-1553062407-98eeb64c6a62"), category: "Accessories", description: "Water-resistant 22L backpack with laptop sleeve.", price: 89, rating: 4.5, stock: 36 },
  { id: "p16", name: "Chrono Mechanical Watch", image: img("photo-1524592094714-0f0654e20314"), category: "Accessories", description: "Automatic movement, sapphire crystal, 100m WR.", price: 420, rating: 4.8, stock: 8 },
  { id: "p17", name: "Lumen Ceramic Table Lamp", image: img("photo-1513506003901-1e6a229e2d15"), category: "Home Decor", description: "Hand-thrown ceramic base with linen shade.", price: 110, rating: 4.4, stock: 20 },
  { id: "p18", name: "Loom Woven Throw Blanket", image: img("photo-1600369671236-e74521d4b6ad"), category: "Home Decor", description: "Cozy throw woven from recycled cotton.", price: 60, rating: 4.5, stock: 40 },
  { id: "p19", name: "Verde Monstera Planter", image: img("photo-1485955900006-10f4d324d411"), category: "Home Decor", description: "Matte stoneware planter, drainage included.", price: 38, rating: 4.3, stock: 55 },
  { id: "p20", name: "Aurora Scented Candle", image: img("photo-1602874801006-e26c1f0b9b04"), category: "Home Decor", description: "Hand-poured soy candle, 60-hour burn.", price: 32, rating: 4.7, stock: 80 },
];

export const categories = ["All", "Electronics", "Clothing", "Shoes", "Accessories", "Home Decor"] as const;
