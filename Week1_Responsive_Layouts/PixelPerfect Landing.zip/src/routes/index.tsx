import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, Check, Sparkles, Zap, Shield, BarChart3, Workflow, Globe, Menu, X } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nimbus — Ship faster with a calm, modern workspace" },
      { name: "description", content: "Nimbus is the all-in-one SaaS platform for product teams to plan, build, and launch with premium polish." },
      { property: "og:title", content: "Nimbus — Calm, modern workspace for product teams" },
      { property: "og:description", content: "Plan, build, and launch with Nimbus — the all-in-one SaaS platform built for speed." },
    ],
  }),
  component: Index,
});

const features = [
  { icon: Zap, title: "Lightning fast", desc: "Sub-50ms interactions and instant page loads, everywhere." },
  { icon: Shield, title: "Secure by default", desc: "SOC 2 Type II, SSO, and end-to-end encryption at rest." },
  { icon: BarChart3, title: "Real-time insights", desc: "Dashboards that update the moment your data changes." },
  { icon: Workflow, title: "Automations", desc: "Visual workflows that connect every tool your team uses." },
  { icon: Globe, title: "Global edge", desc: "Deployed across 300+ cities for low-latency access." },
  { icon: Sparkles, title: "AI assist", desc: "Smart suggestions and summaries baked into every view." },
];

const plans = [
  { name: "Starter", price: "$0", cadence: "/mo", features: ["Up to 3 projects", "Community support", "Basic analytics"], cta: "Start free" },
  { name: "Pro", price: "$24", cadence: "/mo", features: ["Unlimited projects", "Priority support", "Advanced analytics", "Automations"], cta: "Start free trial", featured: true },
  { name: "Scale", price: "Custom", cadence: "", features: ["SSO + SCIM", "Dedicated CSM", "Custom SLAs", "Audit logs"], cta: "Talk to sales" },
];

function useReveal() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    const els = document.querySelectorAll<HTMLElement>("[data-reveal]");
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      els.forEach((el) => el.classList.add("is-visible"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function Index() {
  useReveal();
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-dvh bg-background text-foreground antialiased">
      {/* NAV */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <a href="#top" className="flex items-center gap-2 font-semibold tracking-tight">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground shadow-sm">
              <Sparkles className="h-4 w-4" aria-hidden />
            </span>
            <span>Nimbus</span>
          </a>
          <ul className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
            {["Features", "Pricing", "FAQ"].map((l) => (
              <li key={l}>
                <a href={`#${l.toLowerCase()}`} className="link-underline transition-colors hover:text-foreground">
                  {l}
                </a>
              </li>
            ))}
          </ul>
          <div className="hidden items-center gap-3 md:flex">
            <a href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">Sign in</a>
            <a href="#pricing" className="press inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-sm hover:bg-primary/90">
              Get started <ArrowRight className="h-3.5 w-3.5" aria-hidden />
            </a>
          </div>
          <button
            onClick={() => setOpen((v) => !v)}
            className="md:hidden rounded-md p-2 text-foreground hover:bg-accent"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </nav>
        {open && (
          <div className="border-t border-border/60 px-5 py-4 md:hidden">
            <ul className="flex flex-col gap-3 text-sm">
              {["Features", "Pricing", "FAQ"].map((l) => (
                <li key={l}>
                  <a href={`#${l.toLowerCase()}`} onClick={() => setOpen(false)} className="block py-1 text-muted-foreground hover:text-foreground">
                    {l}
                  </a>
                </li>
              ))}
              <li>
                <a href="#pricing" onClick={() => setOpen(false)} className="press mt-2 inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
                  Get started <ArrowRight className="h-3.5 w-3.5" />
                </a>
              </li>
            </ul>
          </div>
        )}
      </header>

      <main id="top">
        {/* HERO */}
        <section className="relative overflow-hidden">
          {/* ambient orbs */}
          <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
            <div className="orb absolute -top-24 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-primary/20 blur-3xl" />
            <div className="orb orb-slow absolute right-0 top-40 h-[320px] w-[320px] rounded-full bg-chart-2/20 blur-3xl" />
          </div>

          <div className="mx-auto max-w-6xl px-5 pb-24 pt-20 text-center md:pt-28">
            <div data-reveal className="inline-flex">
              <span className="shimmer inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs font-medium text-muted-foreground backdrop-blur">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" /> New · v3.0 with AI assist
              </span>
            </div>
            <h1
              data-reveal
              style={{ ["--reveal-delay" as any]: "80ms" }}
              className="mx-auto mt-6 max-w-3xl text-balance text-5xl font-semibold leading-[1.05] tracking-tight md:text-6xl"
            >
              <span className="text-sheen">Ship faster</span> with a calm, modern workspace.
            </h1>
            <p
              data-reveal
              style={{ ["--reveal-delay" as any]: "160ms" }}
              className="mx-auto mt-6 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground md:text-lg"
            >
              Nimbus brings planning, building, and launching into one beautifully fast platform — designed for teams that care about craft.
            </p>
            <div
              data-reveal
              style={{ ["--reveal-delay" as any]: "240ms" }}
              className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row"
            >
              <a href="#pricing" className="press inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-lg shadow-primary/20 hover:bg-primary/90">
                Start free <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
              <a href="#features" className="press inline-flex items-center gap-2 rounded-full border border-border bg-card px-6 py-3 text-sm font-medium text-foreground hover:bg-accent">
                See features
              </a>
            </div>

            {/* Product mock */}
            <div data-reveal style={{ ["--reveal-delay" as any]: "360ms" }} className="mx-auto mt-16 max-w-5xl">
              <div className="lift-card rounded-2xl border border-border bg-card p-2 shadow-2xl shadow-primary/5">
                <div className="rounded-xl bg-gradient-to-br from-muted/60 to-background p-6">
                  <div className="mb-4 flex gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-destructive/60" />
                    <span className="h-2.5 w-2.5 rounded-full bg-chart-4/70" />
                    <span className="h-2.5 w-2.5 rounded-full bg-chart-2/70" />
                  </div>
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="rounded-lg border border-border bg-background/60 p-4 text-left">
                        <div className="h-2 w-16 rounded bg-muted-foreground/30" />
                        <div className="mt-3 h-6 w-24 rounded bg-foreground/80" />
                        <div className="mt-4 h-20 rounded bg-gradient-to-tr from-primary/20 to-chart-2/20" />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FEATURES */}
        <section id="features" className="border-t border-border/60 py-24">
          <div className="mx-auto max-w-6xl px-5">
            <div className="mx-auto max-w-2xl text-center">
              <h2 data-reveal className="text-3xl font-semibold tracking-tight md:text-4xl">
                Everything you need. Nothing you don't.
              </h2>
              <p data-reveal style={{ ["--reveal-delay" as any]: "80ms" }} className="mt-4 text-muted-foreground">
                A focused toolkit that gets out of your way so you can ship what matters.
              </p>
            </div>

            <ul className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {features.map(({ icon: Icon, title, desc }, i) => (
                <li
                  key={title}
                  data-reveal
                  style={{ ["--reveal-delay" as any]: `${i * 70}ms` }}
                  className="lift-card glow-border rounded-2xl border border-border bg-card p-6"
                >
                  <div className="mb-4 inline-grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" aria-hidden />
                  </div>
                  <h3 className="text-base font-semibold">{title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{desc}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* STATS */}
        <section className="border-t border-border/60 py-20">
          <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-5 text-center md:grid-cols-4">
            {[
              ["10M+", "Tasks shipped"],
              ["99.99%", "Uptime"],
              ["180+", "Countries"],
              ["4.9★", "G2 rating"],
            ].map(([v, l], i) => (
              <div key={l} data-reveal style={{ ["--reveal-delay" as any]: `${i * 60}ms` }}>
                <div className="text-3xl font-semibold tracking-tight md:text-4xl">{v}</div>
                <div className="mt-1 text-sm text-muted-foreground">{l}</div>
              </div>
            ))}
          </div>
        </section>

        {/* PRICING */}
        <section id="pricing" className="border-t border-border/60 py-24">
          <div className="mx-auto max-w-6xl px-5">
            <div className="mx-auto max-w-2xl text-center">
              <h2 data-reveal className="text-3xl font-semibold tracking-tight md:text-4xl">
                Simple, transparent pricing
              </h2>
              <p data-reveal style={{ ["--reveal-delay" as any]: "80ms" }} className="mt-4 text-muted-foreground">
                Start free. Upgrade when you need more power.
              </p>
            </div>

            <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-3">
              {plans.map((p, i) => (
                <div
                  key={p.name}
                  data-reveal
                  style={{ ["--reveal-delay" as any]: `${i * 90}ms` }}
                  className={
                    "lift-card relative rounded-2xl border bg-card p-7 " +
                    (p.featured ? "border-primary shadow-xl shadow-primary/10" : "border-border")
                  }
                >
                  {p.featured && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground shadow">
                      Most popular
                    </span>
                  )}
                  <h3 className="text-sm font-medium text-muted-foreground">{p.name}</h3>
                  <div className="mt-3 flex items-baseline gap-1">
                    <span className="text-4xl font-semibold tracking-tight">{p.price}</span>
                    <span className="text-sm text-muted-foreground">{p.cadence}</span>
                  </div>
                  <ul className="mt-6 space-y-2.5 text-sm">
                    {p.features.map((f) => (
                      <li key={f} className="flex items-start gap-2">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <a
                    href="#"
                    className={
                      "press mt-7 inline-flex w-full items-center justify-center rounded-full px-4 py-2.5 text-sm font-medium " +
                      (p.featured
                        ? "bg-primary text-primary-foreground hover:bg-primary/90"
                        : "border border-border bg-background hover:bg-accent")
                    }
                  >
                    {p.cta}
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="border-t border-border/60 py-24">
          <div data-reveal className="mx-auto max-w-3xl px-5 text-center">
            <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">
              Ready to feel the difference?
            </h2>
            <p className="mt-4 text-muted-foreground">
              Join thousands of teams shipping calmer, faster work with Nimbus.
            </p>
            <a href="#" className="press mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-lg shadow-primary/20 hover:bg-primary/90">
              Start free <ArrowRight className="h-4 w-4" aria-hidden />
            </a>
          </div>
        </section>
      </main>

      <footer className="border-t border-border/60 py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 text-sm text-muted-foreground md:flex-row">
          <div className="flex items-center gap-2">
            <span className="grid h-6 w-6 place-items-center rounded-md bg-primary text-primary-foreground">
              <Sparkles className="h-3 w-3" aria-hidden />
            </span>
            <span>© {new Date().getFullYear()} Nimbus, Inc.</span>
          </div>
          <ul className="flex gap-6">
            <li><a href="#" className="link-underline hover:text-foreground">Privacy</a></li>
            <li><a href="#" className="link-underline hover:text-foreground">Terms</a></li>
            <li><a href="#" className="link-underline hover:text-foreground">Contact</a></li>
          </ul>
        </div>
      </footer>
    </div>
  );
}
