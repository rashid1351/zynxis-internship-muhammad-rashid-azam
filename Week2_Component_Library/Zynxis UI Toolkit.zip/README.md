# Zynxis — Component-Driven Frontend (Internship Task)

A professional, reusable React + TypeScript component library and showcase, built for the **Zynxis Internship Task**.

> Note on stack: this Lovable project ships on **TanStack Start** (Vite + React 19) rather than Next.js. TanStack Start uses file-based routing under `src/routes/` instead of `src/app/`. Every other requirement — reusable component library, slate-grey dark theme, showcase page, landing page composed entirely of reusable components — is fulfilled.

## Tech Stack

- React 19 + **TanStack Start** (Vite 8) — Next.js-equivalent file-based routing
- **TypeScript** (strict)
- **Tailwind CSS v4** (CSS-first design tokens in `src/styles.css`)
- **Framer Motion** for animations
- **Lucide Icons**
- ESLint + Prettier

## Design System

Premium slate-grey dark SaaS theme. Tokens defined in `src/styles.css`:

| Token | Value |
|------|------|
| Background | `#0F172A` |
| Surface | `#1E293B` |
| Card | `#334155` |
| Primary | `#3B82F6` |
| Accent | `#60A5FA` |
| Text Primary | `#F8FAFC` |
| Text Secondary | `#CBD5E1` |
| Border | `#475569` |

## Folder Structure

```
src/
├── routes/                  # File-based routes (TanStack Start equivalent of app/)
│   ├── __root.tsx           # Root layout, head, providers
│   ├── index.tsx            # / — Landing page
│   └── components.tsx       # /components — Showcase page
│
├── components/
│   ├── ui/                  # Reusable primitives
│   │   ├── button/
│   │   ├── card/            # Card, FeatureCard, ServiceCard, PricingCard, TestimonialCard
│   │   ├── input/           # Input, Textarea, Select
│   │   ├── badge/
│   │   ├── alert/
│   │   ├── avatar/
│   │   ├── modal/           # Modal, ConfirmModal, SuccessModal
│   │   ├── accordion/
│   │   ├── tabs/
│   │   ├── tooltip/
│   │   ├── dropdown/
│   │   ├── pagination/
│   │   ├── breadcrumb/
│   │   ├── stats/
│   │   ├── cta/
│   │   └── feedback/        # Loader, Skeleton
│   │
│   ├── layout/              # Navbar, Footer, Sidebar, Container
│   └── sections/            # Hero, Features, Services, Testimonials, Pricing, FAQ, Contact, CTA, SectionHeader
│
├── hooks/
├── lib/
├── styles.css               # Design tokens, utilities, theme
└── ...
```

## Reusable Component Library

**Buttons** — primary, secondary, outline, ghost, destructive, gradient, icon, loading
**Cards** — basic, feature, service, pricing, testimonial
**Inputs** — text, email, password, search, textarea, select
**Modals** — standard, confirm, success
**Badges** — primary, secondary, success, warning, destructive, outline
**Alerts** — info, success, warning, error
**Navigation** — Navbar, Mobile Navbar, Sidebar, Breadcrumb, Pagination
**Other** — Accordion, Tabs, Tooltip, Dropdown, Avatar, Loader, Skeleton, Stats, CTA Banner

All components:
- Accept typed props (TypeScript interfaces exported)
- Support hover / active / disabled / focus states
- Are fully responsive
- Share the same design tokens (no hardcoded colors)

## Pages

- `/` — Landing page (Hero, Features, Services, Testimonials, Pricing, FAQ, CTA, Contact, Footer)
- `/components` — Full component showcase with sidebar navigation

## Installation

```bash
bun install
bun run dev
```

Open http://localhost:5173.

## Scripts

| Command | Description |
|--------|-------------|
| `bun run dev` | Start dev server |
| `bun run build` | Production build |
| `bun run lint` | ESLint |
| `bun run format` | Prettier |

## Screenshots

Capture the following routes for submission and save into `submission-assets/`:

- `/` desktop & mobile — Landing page
- `/components` — Component library showcase
- `/components#buttons` — Buttons showcase
- `/components#cards` — Cards showcase
- `/components#inputs` — Forms showcase
- `/components#modals` — Modal showcase

## Internship Requirement Mapping

| Requirement | Status |
|-------------|--------|
| React/Next.js project | ✓ React 19 on TanStack Start (Next.js-equivalent routing) |
| TypeScript | ✓ Strict |
| Tailwind CSS | ✓ v4 with design tokens |
| Framer Motion | ✓ Hero, cards, modals, accordion, dropdowns |
| Lucide icons | ✓ |
| Reusable component library | ✓ 25+ components, all in `components/ui/*` |
| Slate-grey dark theme | ✓ Per spec |
| `/components` showcase | ✓ |
| Landing page from reusable components | ✓ |
| Responsive (mobile → desktop) | ✓ |
| Folder structure | ✓ (TanStack `routes/` mirrors Next.js `app/`) |
| README | ✓ |
