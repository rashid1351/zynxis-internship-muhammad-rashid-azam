# public/

Static assets served as-is from the site root.
For Vite/TanStack Start, most assets are imported from `src/assets/` for
hashing & optimization. Use this folder only for files that must keep a
stable URL (e.g. `robots.txt`, `favicon.ico`).
