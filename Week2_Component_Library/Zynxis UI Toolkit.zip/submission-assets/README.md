# Submission Assets

Place screenshots here for the internship submission:

- `landing-desktop.png` — `/` at 1440×900
- `landing-mobile.png` — `/` at 390×844
- `components-library.png` — `/components`
- `buttons.png` — `/components#buttons`
- `cards.png` — `/components#cards`
- `forms.png` — `/components#inputs`
- `modal.png` — `/components#modals` (with modal open)
