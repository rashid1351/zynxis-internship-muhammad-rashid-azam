import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  Bell, Download, Heart, Mail, Plus, Search, Settings, Trash2, Users, Activity,
} from "lucide-react";

import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Container } from "@/components/layout/Container";
import { Sidebar } from "@/components/layout/Sidebar";

import { Button } from "@/components/ui/button";
import { Card, CardTitle, CardDescription, FeatureCard, ServiceCard, PricingCard, TestimonialCard } from "@/components/ui/card";
import { Input, Textarea, Select } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert } from "@/components/ui/alert";
import { Avatar } from "@/components/ui/avatar";
import { Modal, ConfirmModal, SuccessModal } from "@/components/ui/modal";
import { Accordion } from "@/components/ui/accordion";
import { Tabs } from "@/components/ui/tabs";
import { Tooltip } from "@/components/ui/tooltip";
import { DropdownMenu } from "@/components/ui/dropdown";
import { Pagination } from "@/components/ui/pagination";
import { Breadcrumb } from "@/components/ui/breadcrumb";
import { StatsCard } from "@/components/ui/stats";
import { CTABanner } from "@/components/ui/cta";
import { Loader, Skeleton } from "@/components/ui/feedback";
import { SectionHeader } from "@/components/sections/SectionHeader";

export const Route = createFileRoute("/components")({
  head: () => ({
    meta: [
      { title: "Components — Zynxis UI Library" },
      { name: "description", content: "Showcase of every reusable component, variant and state in the Zynxis UI library." },
      { property: "og:title", content: "Components — Zynxis UI Library" },
      { property: "og:description", content: "Browse 50+ reusable React components: buttons, cards, inputs, modals, badges, alerts and more." },
    ],
  }),
  component: ComponentsPage,
});

const SECTIONS = [
  { id: "buttons", label: "Buttons", icon: Plus },
  { id: "cards", label: "Cards", icon: Activity },
  { id: "inputs", label: "Inputs", icon: Mail },
  { id: "badges", label: "Badges", icon: Heart },
  { id: "alerts", label: "Alerts", icon: Bell },
  { id: "avatars", label: "Avatars", icon: Users },
  { id: "modals", label: "Modals", icon: Settings },
  { id: "accordion", label: "Accordion", icon: Plus },
  { id: "tabs", label: "Tabs", icon: Plus },
  { id: "tooltip", label: "Tooltip", icon: Plus },
  { id: "dropdown", label: "Dropdown", icon: Plus },
  { id: "navigation", label: "Navigation", icon: Plus },
  { id: "stats", label: "Stats", icon: Activity },
  { id: "feedback", label: "Loaders", icon: Download },
  { id: "cta", label: "CTA Banner", icon: Plus },
];

function ComponentsPage() {
  const [active, setActive] = React.useState("buttons");
  const [openModal, setOpenModal] = React.useState(false);
  const [openConfirm, setOpenConfirm] = React.useState(false);
  const [openSuccess, setOpenSuccess] = React.useState(false);
  const [page, setPage] = React.useState(2);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Container className="py-12">
        <Breadcrumb items={[{ label: "Home", href: "/" }, { label: "Components" }]} />
        <div className="mt-4">
          <SectionHeader
            align="left"
            eyebrow="Library"
            title="Component Showcase"
            description="Every reusable primitive, every variant, every state — one source of truth."
          />
        </div>

        <div className="mt-10 flex flex-col gap-8 md:flex-row">
          <div className="md:sticky md:top-20 md:h-fit">
            <Sidebar
              title="Sections"
              items={SECTIONS}
              active={active}
              onSelect={(id) => {
                setActive(id);
                document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
            />
          </div>

          <div className="flex-1 space-y-16">
            <Showcase id="buttons" title="Buttons" description="6 variants × 4 sizes, with icons and loading state.">
              <Row>
                <Button variant="primary">Primary</Button>
                <Button variant="secondary">Secondary</Button>
                <Button variant="outline">Outline</Button>
                <Button variant="ghost">Ghost</Button>
                <Button variant="destructive">Destructive</Button>
                <Button variant="gradient">Gradient</Button>
              </Row>
              <Row>
                <Button size="sm">Small</Button>
                <Button size="md">Medium</Button>
                <Button size="lg">Large</Button>
                <Button size="icon" aria-label="settings"><Settings className="h-4 w-4" /></Button>
              </Row>
              <Row>
                <Button leftIcon={<Download className="h-4 w-4" />}>Download</Button>
                <Button rightIcon={<Plus className="h-4 w-4" />}>Add new</Button>
                <Button loading>Loading…</Button>
                <Button disabled>Disabled</Button>
              </Row>
            </Showcase>

            <Showcase id="cards" title="Cards">
              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardTitle>Basic Card</CardTitle>
                  <CardDescription className="mt-2">A simple container with title and description.</CardDescription>
                </Card>
                <Card variant="surface" hoverable>
                  <CardTitle>Hoverable Surface</CardTitle>
                  <CardDescription className="mt-2">Lifts on hover with subtle motion.</CardDescription>
                </Card>
                <FeatureCard icon={Activity} title="Feature Card" description="Highlights a single capability." />
                <ServiceCard icon={Users} title="Service Card" description="Describes an offering with a CTA link." />
              </div>
              <div className="grid gap-4 md:grid-cols-3">
                <PricingCard name="Starter" price="$0" description="Free forever" features={["1 project", "Community"]} />
                <PricingCard highlighted name="Pro" price="$29" description="Most popular" features={["Unlimited", "Priority support"]} />
                <PricingCard name="Enterprise" price="$99" description="Advanced controls" features={["SSO", "Audit logs"]} />
              </div>
              <TestimonialCard quote="The best component library I've worked with." name="Aria Patel" role="CTO, Northwind" />
            </Showcase>

            <Showcase id="inputs" title="Inputs">
              <div className="grid gap-4 md:grid-cols-2">
                <Input label="Text" placeholder="Your name" />
                <Input label="Email" type="email" placeholder="you@example.com" leftIcon={<Mail className="h-4 w-4" />} />
                <Input label="Password" type="password" placeholder="••••••••" />
                <Input label="Search" placeholder="Search…" leftIcon={<Search className="h-4 w-4" />} />
                <Input label="With error" placeholder="invalid" error="This field is required" />
                <Input label="Disabled" placeholder="Disabled" disabled />
                <Select label="Country" options={[{label:"United States",value:"us"},{label:"India",value:"in"},{label:"Germany",value:"de"}]} />
                <Textarea label="Message" placeholder="Type something…" />
              </div>
            </Showcase>

            <Showcase id="badges" title="Badges">
              <Row>
                <Badge variant="primary">Primary</Badge>
                <Badge variant="secondary">Secondary</Badge>
                <Badge variant="success">Active</Badge>
                <Badge variant="warning">Pending</Badge>
                <Badge variant="destructive">Failed</Badge>
                <Badge variant="outline">Outline</Badge>
                <Badge variant="primary">v1.0</Badge>
                <Badge variant="success">New</Badge>
              </Row>
            </Showcase>

            <Showcase id="alerts" title="Alerts">
              <div className="grid gap-3">
                <Alert variant="info" title="Heads up">This is an informational message.</Alert>
                <Alert variant="success" title="Saved">Your changes have been saved.</Alert>
                <Alert variant="warning" title="Careful">This action may be slow.</Alert>
                <Alert variant="error" title="Something went wrong">Please try again later.</Alert>
              </div>
            </Showcase>

            <Showcase id="avatars" title="Avatars">
              <Row>
                <Avatar name="Aria Patel" size="sm" />
                <Avatar name="Marcus Lee" />
                <Avatar name="Sara Okafor" size="lg" />
                <Avatar src="https://i.pravatar.cc/100?img=12" name="Photo" size="lg" />
              </Row>
            </Showcase>

            <Showcase id="modals" title="Modals">
              <Row>
                <Button onClick={() => setOpenModal(true)}>Standard modal</Button>
                <Button variant="destructive" onClick={() => setOpenConfirm(true)}>Confirm delete</Button>
                <Button variant="gradient" onClick={() => setOpenSuccess(true)}>Success modal</Button>
              </Row>
              <Modal
                open={openModal}
                onClose={() => setOpenModal(false)}
                title="Edit profile"
                description="Update your account information."
                footer={
                  <>
                    <Button variant="ghost" onClick={() => setOpenModal(false)}>Cancel</Button>
                    <Button onClick={() => setOpenModal(false)}>Save</Button>
                  </>
                }
              >
                <div className="flex flex-col gap-3">
                  <Input label="Name" defaultValue="Jane Doe" />
                  <Input label="Email" defaultValue="jane@example.com" />
                </div>
              </Modal>
              <ConfirmModal
                open={openConfirm}
                onClose={() => setOpenConfirm(false)}
                onConfirm={() => {}}
                title="Delete project?"
                description="This will permanently remove the project and all its data."
                destructive
                confirmText="Delete"
              />
              <SuccessModal
                open={openSuccess}
                onClose={() => setOpenSuccess(false)}
                title="All set!"
                description="Your workspace is ready."
              />
            </Showcase>

            <Showcase id="accordion" title="Accordion">
              <Accordion
                items={[
                  { id: "a", title: "What is Zynxis?", content: "A modern reusable component system." },
                  { id: "b", title: "Is it free?", content: "Yes, the showcase is open." },
                  { id: "c", title: "Can I customise it?", content: "Every token can be themed via CSS variables." },
                ]}
                defaultOpen="a"
              />
            </Showcase>

            <Showcase id="tabs" title="Tabs">
              <Tabs
                items={[
                  { id: "overview", label: "Overview", content: <p className="text-muted-foreground">Overview content.</p> },
                  { id: "usage", label: "Usage", content: <p className="text-muted-foreground">Usage examples and props.</p> },
                  { id: "code", label: "Code", content: <pre className="rounded-md bg-surface p-3 text-xs text-foreground">{`<Button variant="primary">Click</Button>`}</pre> },
                ]}
              />
            </Showcase>

            <Showcase id="tooltip" title="Tooltip">
              <Row>
                <Tooltip content="Save changes"><Button variant="outline" size="icon"><Plus className="h-4 w-4" /></Button></Tooltip>
                <Tooltip content="Delete item"><Button variant="outline" size="icon"><Trash2 className="h-4 w-4" /></Button></Tooltip>
                <Tooltip content="Settings"><Button variant="outline" size="icon"><Settings className="h-4 w-4" /></Button></Tooltip>
              </Row>
            </Showcase>

            <Showcase id="dropdown" title="Dropdown Menu">
              <DropdownMenu
                trigger={<Button variant="outline">Open menu</Button>}
                items={[
                  { label: "Profile" },
                  { label: "Settings" },
                  { label: "Sign out" },
                ]}
              />
            </Showcase>

            <Showcase id="navigation" title="Navigation">
              <Breadcrumb items={[{label:"Home",href:"/"},{label:"Library",href:"#"},{label:"Buttons"}]} />
              <div className="mt-4">
                <Pagination page={page} totalPages={5} onChange={setPage} />
              </div>
            </Showcase>

            <Showcase id="stats" title="Stats Cards">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <StatsCard label="Active users" value="12,540" icon={Users} change={12} />
                <StatsCard label="Revenue" value="$48.2k" icon={Activity} change={-3} />
                <StatsCard label="Conversion" value="4.8%" icon={Heart} change={6} />
                <StatsCard label="Sessions" value="92,310" icon={Activity} change={18} />
              </div>
            </Showcase>

            <Showcase id="feedback" title="Loaders & Skeletons">
              <Row>
                <Loader />
                <Loader className="h-8 w-8" />
              </Row>
              <div className="space-y-2">
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-24 w-full" />
              </div>
            </Showcase>

            <Showcase id="cta" title="CTA Banner">
              <CTABanner
                title="Start building today"
                description="Use the entire Zynxis library in your next project."
                primaryAction={{ label: "Get started" }}
                secondaryAction={{ label: "Docs" }}
              />
            </Showcase>
          </div>
        </div>
      </Container>
      <Footer />
    </div>
  );
}

function Row({ children }: { children: React.ReactNode }) {
  return <div className="flex flex-wrap items-center gap-3">{children}</div>;
}

function Showcase({
  id, title, description, children,
}: { id: string; title: string; description?: string; children: React.ReactNode }) {
  return (
    <section id={id} className="scroll-mt-20">
      <div className="mb-5 border-b border-border pb-3">
        <h2 className="text-2xl font-bold text-foreground">{title}</h2>
        {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      </div>
      <div className="space-y-6 rounded-xl border border-border bg-card/40 p-6">{children}</div>
    </section>
  );
}
