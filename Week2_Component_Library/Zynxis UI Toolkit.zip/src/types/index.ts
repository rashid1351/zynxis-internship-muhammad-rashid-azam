// Shared TypeScript types for the Zynxis component library.

export interface NavLink {
  label: string;
  href: string;
}

export interface Feature {
  id: string;
  title: string;
  description: string;
  icon?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  avatar?: string;
  quote: string;
  rating?: number;
}

export interface PricingPlan {
  id: string;
  name: string;
  price: string;
  period?: string;
  features: string[];
  highlighted?: boolean;
  cta?: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon?: string;
}

export type ButtonVariant = "default" | "secondary" | "outline" | "ghost" | "link" | "destructive";
export type Size = "sm" | "md" | "lg";
