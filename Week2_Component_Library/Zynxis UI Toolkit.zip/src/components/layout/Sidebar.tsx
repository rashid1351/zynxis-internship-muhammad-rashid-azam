import * as React from "react";
import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

export interface SidebarItem { id: string; label: string; icon?: LucideIcon }
export interface SidebarProps {
  items: SidebarItem[];
  active?: string;
  onSelect?: (id: string) => void;
  title?: string;
}

export function Sidebar({ items, active, onSelect, title }: SidebarProps) {
  return (
    <aside className="flex w-full flex-col gap-1 rounded-xl border border-border bg-surface p-3 md:w-60">
      {title && (
        <p className="px-2 py-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</p>
      )}
      {items.map((it) => {
        const Icon = it.icon;
        const isActive = active === it.id;
        return (
          <button
            key={it.id}
            onClick={() => onSelect?.(it.id)}
            className={cn(
              "flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
              isActive
                ? "bg-primary/15 text-primary"
                : "text-muted-foreground hover:bg-card hover:text-foreground",
            )}
          >
            {Icon && <Icon className="h-4 w-4 shrink-0" />}
            <span className="truncate">{it.label}</span>
          </button>
        );
      })}
    </aside>
  );
}
