import { Github, Twitter, Linkedin } from "lucide-react";
import { Container } from "./Container";
import zynxisLogo from "@/assets/zynxis-logo.png.asset.json";

const COLS = [
  { title: "Product", links: ["Features", "Pricing", "Changelog", "Roadmap"] },
  { title: "Company", links: ["About", "Blog", "Careers", "Contact"] },
  { title: "Resources", links: ["Documentation", "Help center", "API", "Status"] },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-surface/40">
      <Container className="py-12">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2 text-foreground">
              <img src={zynxisLogo.url} alt="Zynxis" className="h-8 w-auto rounded-full" />
              <span className="text-lg font-bold">Zynxis</span>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">
              Modern frontend infrastructure for ambitious teams.
            </p>
            <div className="mt-4 flex gap-2">
              {[Github, Twitter, Linkedin].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="grid h-9 w-9 place-items-center rounded-md border border-border bg-surface text-muted-foreground transition-colors hover:bg-card hover:text-foreground"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          {COLS.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold text-foreground">{col.title}</h4>
              <ul className="mt-3 space-y-2">
                {col.links.map((l) => (
                  <li key={l}>
                    <a href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 flex flex-col items-center justify-between gap-2 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row">
          <p>© {new Date().getFullYear()} Zynxis. All rights reserved.</p>
          <p>Built for the Zynxis internship task.</p>
        </div>
      </Container>
    </footer>
  );
}
