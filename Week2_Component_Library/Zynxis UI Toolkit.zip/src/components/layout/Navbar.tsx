import * as React from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Menu, X, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container } from "./Container";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import zynxisLogo from "@/assets/zynxis-logo.png.asset.json";

const NAV_LINKS = [
  { to: "/", label: "Home" },
  { to: "/#features", label: "Features" },
  { to: "/#services", label: "Services" },
  { to: "/#pricing", label: "Pricing" },
  { to: "/components", label: "Components" },
];

export function Navbar() {
  const [open, setOpen] = React.useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate({ to: "/" });
  };

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-md">
      <Container className="flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 text-foreground">
          <img src={zynxisLogo.url} alt="Zynxis" className="h-8 w-auto rounded-full" />
          <span className="text-xl font-bold tracking-tight">Zynxis</span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((l) => (
            <a
              key={l.to + l.label}
              href={l.to}
              className="rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-surface hover:text-foreground"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          {user ? (
            <>
              <span className="hidden text-sm text-muted-foreground lg:inline">
                {user.email}
              </span>
              <Button variant="ghost" size="sm" onClick={handleSignOut} leftIcon={<LogOut className="h-4 w-4" />}>
                Sign out
              </Button>
            </>
          ) : (
            <>
              <Link to="/auth">
                <Button variant="ghost" size="sm">Sign in</Button>
              </Link>
              <Link to="/auth">
                <Button variant="primary" size="sm">Get started</Button>
              </Link>
            </>
          )}
        </div>

        <button
          className="rounded-md p-2 text-foreground hover:bg-surface md:hidden"
          onClick={() => setOpen((s) => !s)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </Container>

      <div className={cn("md:hidden", open ? "block" : "hidden")}>
        <Container className="flex flex-col gap-1 pb-4">
          {NAV_LINKS.map((l) => (
            <a
              key={l.to + l.label}
              href={l.to}
              onClick={() => setOpen(false)}
              className="rounded-md px-3 py-2 text-sm text-foreground hover:bg-surface"
            >
              {l.label}
            </a>
          ))}
          <div className="mt-2 flex gap-2">
            {user ? (
              <Button variant="outline" size="sm" className="flex-1" onClick={handleSignOut}>
                Sign out
              </Button>
            ) : (
              <>
                <Link to="/auth" className="flex-1">
                  <Button variant="outline" size="sm" className="w-full">Sign in</Button>
                </Link>
                <Link to="/auth" className="flex-1">
                  <Button variant="primary" size="sm" className="w-full">Get started</Button>
                </Link>
              </>
            )}
          </div>
        </Container>
      </div>
    </header>
  );
}
