import { Container } from "../layout/Container";
import { Accordion } from "../ui/accordion";
import { SectionHeader } from "./SectionHeader";

const ITEMS = [
  { id: "1", title: "What is included in the component library?", content: "50+ reusable primitives — buttons, cards, inputs, modals, navigation, alerts, badges, and more — all written in TypeScript." },
  { id: "2", title: "Is the design system customisable?", content: "Yes. Every token (color, radius, spacing, shadow) lives in CSS variables and can be re-themed in seconds." },
  { id: "3", title: "Does it support responsive layouts?", content: "All components are mobile-first and tested from 320px up to ultrawide displays." },
  { id: "4", title: "What about accessibility?", content: "We follow WAI-ARIA patterns, manage focus correctly, and keep contrast within WCAG AA." },
];

export function FAQ() {
  return (
    <section className="py-20 sm:py-28">
      <Container className="max-w-3xl">
        <SectionHeader eyebrow="FAQ" title="Questions, answered" />
        <div className="mt-10">
          <Accordion items={ITEMS} defaultOpen="1" />
        </div>
      </Container>
    </section>
  );
}
