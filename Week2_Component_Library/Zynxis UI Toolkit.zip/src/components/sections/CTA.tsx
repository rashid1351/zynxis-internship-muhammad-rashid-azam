import { Container } from "../layout/Container";
import { CTABanner } from "../ui/cta";

export function CTA() {
  return (
    <section className="py-20">
      <Container>
        <CTABanner
          title="Ready to ship faster?"
          description="Start with our component library and ship production-ready UIs today."
          primaryAction={{ label: "Get started" }}
          secondaryAction={{ label: "Talk to us" }}
        />
      </Container>
    </section>
  );
}
