import { Container } from "../layout/Container";
import { PricingCard } from "../ui/card";
import { SectionHeader } from "./SectionHeader";

const PLANS = [
  { name: "Starter", price: "$0", description: "For experiments and side projects.",
    features: ["Up to 3 projects", "Community support", "Basic components"] },
  { name: "Pro", price: "$29", description: "For growing teams that ship fast.",
    features: ["Unlimited projects", "All components", "Priority support", "Team workspace"], highlighted: true },
  { name: "Enterprise", price: "$99", description: "Advanced controls and security.",
    features: ["SSO + SAML", "Audit logs", "Dedicated manager", "Custom SLAs"] },
];

export function Pricing() {
  return (
    <section id="pricing" className="bg-surface/40 py-20 sm:py-28">
      <Container>
        <SectionHeader eyebrow="Pricing" title="Plans for every stage" description="Start free, scale when you're ready." />
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {PLANS.map((p) => <PricingCard key={p.name} {...p} />)}
        </div>
      </Container>
    </section>
  );
}
