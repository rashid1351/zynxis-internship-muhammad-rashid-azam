import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { Container } from "../layout/Container";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";

export function Hero() {
  return (
    <section className="bg-hero relative overflow-hidden">
      <Container className="relative py-20 sm:py-28 lg:py-36">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-3xl text-center"
        >
          <Badge variant="primary" className="mb-6">
            <Sparkles className="h-3 w-3" /> Built with reusable components
          </Badge>
          <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Build modern interfaces
            <span className="text-gradient block">faster than ever</span>
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
            Zynxis is a professional component-driven frontend system designed for
            ambitious SaaS products. Ship beautiful UIs with confidence.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button variant="primary" size="lg" rightIcon={<ArrowRight className="h-4 w-4" />}>
              Start building
            </Button>
            <Button variant="outline" size="lg">
              Browse components
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mx-auto mt-16 grid max-w-4xl grid-cols-2 gap-4 sm:grid-cols-4"
        >
          {[
            { v: "50+", l: "Components" },
            { v: "100%", l: "TypeScript" },
            { v: "A11y", l: "Accessible" },
            { v: "1.0", l: "Responsive" },
          ].map((s) => (
            <div
              key={s.l}
              className="rounded-xl border border-border bg-surface/60 p-4 text-center backdrop-blur"
            >
              <div className="text-2xl font-bold text-foreground">{s.v}</div>
              <div className="text-xs text-muted-foreground">{s.l}</div>
            </div>
          ))}
        </motion.div>
      </Container>
    </section>
  );
}
