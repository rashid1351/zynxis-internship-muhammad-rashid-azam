import { Briefcase, Cpu, Globe, LineChart } from "lucide-react";
import { Container } from "../layout/Container";
import { ServiceCard } from "../ui/card";
import { SectionHeader } from "./SectionHeader";

const SERVICES = [
  { icon: Briefcase, title: "Product strategy", description: "Translate ideas into product roadmaps and shipping plans." },
  { icon: Cpu, title: "Engineering", description: "Modern, scalable architectures designed for long-term velocity." },
  { icon: Globe, title: "Web platforms", description: "Marketing sites, dashboards and apps that perform on every device." },
  { icon: LineChart, title: "Analytics", description: "Instrument what matters and turn raw data into insight." },
];

export function Services() {
  return (
    <section id="services" className="bg-surface/40 py-20 sm:py-28">
      <Container>
        <SectionHeader eyebrow="Services" title="What we deliver" description="End-to-end services for teams who care about craft." />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((s) => <ServiceCard key={s.title} {...s} />)}
        </div>
      </Container>
    </section>
  );
}
