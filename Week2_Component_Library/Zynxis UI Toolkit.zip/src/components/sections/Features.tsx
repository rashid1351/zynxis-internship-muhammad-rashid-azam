import { Zap, Shield, Layers, Code2, Sparkles, Boxes } from "lucide-react";
import { Container } from "../layout/Container";
import { FeatureCard } from "../ui/card";
import { SectionHeader } from "./SectionHeader";

const FEATURES = [
  { icon: Zap, title: "Lightning fast", description: "Optimized for performance with smart code-splitting and minimal runtime." },
  { icon: Shield, title: "Type-safe", description: "End-to-end TypeScript with strict mode and zero implicit any." },
  { icon: Layers, title: "Composable", description: "Every primitive is built to compose into larger, custom interfaces." },
  { icon: Code2, title: "Developer-first", description: "Clean APIs, excellent IntelliSense, and intuitive prop names." },
  { icon: Sparkles, title: "Beautifully animated", description: "Tasteful motion powered by Framer Motion, never distracting." },
  { icon: Boxes, title: "Design tokens", description: "A coherent system of color, spacing, radius and typography tokens." },
];

export function Features() {
  return (
    <section id="features" className="py-20 sm:py-28">
      <Container>
        <SectionHeader
          eyebrow="Features"
          title="Everything you need to ship"
          description="A complete toolkit of reusable primitives, ready for production."
        />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => <FeatureCard key={f.title} {...f} />)}
        </div>
      </Container>
    </section>
  );
}
