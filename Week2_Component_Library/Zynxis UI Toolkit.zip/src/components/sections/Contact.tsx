import * as React from "react";
import { Mail } from "lucide-react";
import { Container } from "../layout/Container";
import { Input, Textarea } from "../ui/input";
import { Button } from "../ui/button";
import { Alert } from "../ui/alert";
import { SectionHeader } from "./SectionHeader";

export function Contact() {
  const [submitted, setSubmitted] = React.useState(false);
  return (
    <section id="contact" className="bg-surface/40 py-20 sm:py-28">
      <Container className="max-w-2xl">
        <SectionHeader eyebrow="Contact" title="Let's build something" description="Tell us about your project and we'll be in touch." />
        <form
          onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}
          className="mt-10 flex flex-col gap-4 rounded-xl border border-border bg-card p-6 shadow-card"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Name" placeholder="Jane Doe" required />
            <Input label="Email" type="email" placeholder="jane@company.com" leftIcon={<Mail className="h-4 w-4" />} required />
          </div>
          <Input label="Subject" placeholder="How can we help?" />
          <Textarea label="Message" placeholder="Share a few details…" rows={5} />
          {submitted && <Alert variant="success" title="Message sent">We'll get back to you within 24 hours.</Alert>}
          <Button type="submit" variant="primary" size="lg">Send message</Button>
        </form>
      </Container>
    </section>
  );
}
