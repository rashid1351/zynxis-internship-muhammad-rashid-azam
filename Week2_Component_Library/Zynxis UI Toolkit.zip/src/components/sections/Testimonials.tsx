import { Container } from "../layout/Container";
import { TestimonialCard } from "../ui/card";
import { SectionHeader } from "./SectionHeader";

const ITEMS = [
  { quote: "Zynxis cut our build time in half. The component library is best-in-class.", name: "Aria Patel", role: "CTO, Northwind" },
  { quote: "It feels like a senior engineer's design system distilled into a kit.", name: "Marcus Lee", role: "Founder, Stride" },
  { quote: "The polish, motion, and DX are exactly what our team needed.", name: "Sara Okafor", role: "Lead Designer, Vela" },
];

export function Testimonials() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionHeader eyebrow="Testimonials" title="Loved by modern teams" />
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {ITEMS.map((t) => <TestimonialCard key={t.name} {...t} />)}
        </div>
      </Container>
    </section>
  );
}
