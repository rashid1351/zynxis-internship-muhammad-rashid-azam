import type { LucideIcon } from "lucide-react";
import { TrendingUp, TrendingDown } from "lucide-react";
import { Card } from "../card/Card";
import { cn } from "@/lib/utils";

export interface StatsCardProps {
  label: string;
  value: string;
  icon?: LucideIcon;
  change?: number;
}

export function StatsCard({ label, value, icon: Icon, change }: StatsCardProps) {
  const positive = (change ?? 0) >= 0;
  return (
    <Card hoverable className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        {Icon && <Icon className="h-4 w-4 text-muted-foreground" />}
      </div>
      <div className="text-3xl font-bold text-foreground">{value}</div>
      {typeof change === "number" && (
        <div className={cn("flex items-center gap-1 text-xs", positive ? "text-success" : "text-destructive")}>
          {positive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
          {positive ? "+" : ""}{change}% from last month
        </div>
      )}
    </Card>
  );
}
