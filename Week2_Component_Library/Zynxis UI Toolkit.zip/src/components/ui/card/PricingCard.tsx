import { Check } from "lucide-react";
import { Button } from "../button";
import { Card, CardDescription, CardTitle } from "./Card";
import { Badge } from "../badge";

export interface PricingCardProps {
  name: string;
  price: string;
  period?: string;
  description: string;
  features: string[];
  cta?: string;
  highlighted?: boolean;
}

export function PricingCard({
  name, price, period = "/mo", description, features,
  cta = "Get started", highlighted,
}: PricingCardProps) {
  return (
    <Card
      hoverable
      className={highlighted ? "border-primary shadow-elegant relative" : "relative"}
    >
      {highlighted && (
        <Badge variant="primary" className="absolute -top-3 left-1/2 -translate-x-1/2">
          Most popular
        </Badge>
      )}
      <CardTitle className="text-base text-muted-foreground">{name}</CardTitle>
      <div className="mt-2 flex items-baseline gap-1">
        <span className="text-4xl font-bold text-foreground">{price}</span>
        <span className="text-sm text-muted-foreground">{period}</span>
      </div>
      <CardDescription className="mt-2">{description}</CardDescription>
      <ul className="mt-6 space-y-3 text-sm">
        {features.map((f) => (
          <li key={f} className="flex items-center gap-2 text-foreground">
            <Check className="h-4 w-4 text-primary" /> {f}
          </li>
        ))}
      </ul>
      <Button
        variant={highlighted ? "primary" : "outline"}
        className="mt-6 w-full"
      >
        {cta}
      </Button>
    </Card>
  );
}
