import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  hoverable?: boolean;
  variant?: "default" | "surface" | "outline" | "gradient";
}

export const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ className, hoverable = false, variant = "default", ...props }, ref) => {
    const variants = {
      default: "bg-card border border-border shadow-card",
      surface: "bg-surface border border-border",
      outline: "bg-transparent border border-border",
      gradient: "bg-gradient-primary text-primary-foreground",
    };
    const Comp = hoverable ? motion.div : "div";
    const motionProps = hoverable
      ? { whileHover: { y: -4 }, transition: { duration: 0.2 } }
      : {};
    return (
      <Comp
        ref={ref as never}
        className={cn(
          "rounded-xl p-6 transition-colors",
          variants[variant],
          hoverable && "hover:border-primary/40",
          className,
        )}
        {...motionProps}
        {...(props as object)}
      />
    );
  },
);
Card.displayName = "Card";

export const CardHeader = ({ className, ...p }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("mb-4 flex flex-col gap-1.5", className)} {...p} />
);
export const CardTitle = ({ className, ...p }: React.HTMLAttributes<HTMLHeadingElement>) => (
  <h3 className={cn("text-lg font-semibold text-foreground", className)} {...p} />
);
export const CardDescription = ({ className, ...p }: React.HTMLAttributes<HTMLParagraphElement>) => (
  <p className={cn("text-sm text-muted-foreground", className)} {...p} />
);
export const CardContent = ({ className, ...p }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("text-sm text-muted-foreground", className)} {...p} />
);
export const CardFooter = ({ className, ...p }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("mt-6 flex items-center gap-2", className)} {...p} />
);
