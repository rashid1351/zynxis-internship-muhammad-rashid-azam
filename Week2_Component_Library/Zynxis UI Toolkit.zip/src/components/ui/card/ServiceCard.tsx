import type { LucideIcon } from "lucide-react";
import { ArrowRight } from "lucide-react";
import { Card, CardDescription, CardTitle } from "./Card";

export interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href?: string;
}

export function ServiceCard({ icon: Icon, title, description, href = "#" }: ServiceCardProps) {
  return (
    <Card hoverable className="group flex flex-col">
      <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-lg bg-surface text-accent">
        <Icon className="h-5 w-5" />
      </div>
      <CardTitle>{title}</CardTitle>
      <CardDescription className="mt-2 flex-1">{description}</CardDescription>
      <a
        href={href}
        className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary transition-transform group-hover:translate-x-1"
      >
        Learn more <ArrowRight className="h-3.5 w-3.5" />
      </a>
    </Card>
  );
}
