import * as React from "react";
import { cn } from "@/lib/utils";

export interface TabItem { id: string; label: string; content: React.ReactNode }
export interface TabsProps {
  items: TabItem[];
  defaultTab?: string;
  className?: string;
}

export function Tabs({ items, defaultTab, className }: TabsProps) {
  const [active, setActive] = React.useState(defaultTab ?? items[0]?.id);
  const current = items.find((i) => i.id === active);
  return (
    <div className={cn("w-full", className)}>
      <div className="flex gap-1 rounded-lg bg-surface p-1">
        {items.map((it) => (
          <button
            key={it.id}
            onClick={() => setActive(it.id)}
            className={cn(
              "flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
              active === it.id
                ? "bg-card text-foreground shadow-card"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            {it.label}
          </button>
        ))}
      </div>
      <div className="mt-4">{current?.content}</div>
    </div>
  );
}
