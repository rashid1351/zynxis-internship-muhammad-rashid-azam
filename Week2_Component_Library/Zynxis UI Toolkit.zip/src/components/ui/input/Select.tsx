import * as React from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

export interface SelectOption { label: string; value: string }
export interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "children"> {
  label?: string;
  options: SelectOption[];
}

export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
  ({ className, label, options, id, ...props }, ref) => {
    const sId = id ?? React.useId();
    return (
      <div className="flex w-full flex-col gap-1.5">
        {label && <label htmlFor={sId} className="text-sm font-medium text-foreground">{label}</label>}
        <div className="relative">
          <select
            ref={ref}
            id={sId}
            className={cn(
              "h-10 w-full appearance-none rounded-lg border border-input bg-surface pl-3 pr-9 text-sm text-foreground",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              "disabled:cursor-not-allowed disabled:opacity-50",
              className,
            )}
            {...props}
          >
            {options.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        </div>
      </div>
    );
  },
);
Select.displayName = "Select";
