import { Button } from "../button";

export interface CTABannerProps {
  title: string;
  description?: string;
  primaryAction?: { label: string; onClick?: () => void };
  secondaryAction?: { label: string; onClick?: () => void };
}

export function CTABanner({ title, description, primaryAction, secondaryAction }: CTABannerProps) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-gradient-primary p-8 sm:p-12 shadow-elegant">
      <div className="relative z-10 flex flex-col items-start gap-4 md:flex-row md:items-center md:justify-between">
        <div className="max-w-2xl">
          <h2 className="text-2xl font-bold text-primary-foreground sm:text-3xl">{title}</h2>
          {description && (
            <p className="mt-2 text-primary-foreground/90">{description}</p>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          {primaryAction && (
            <Button variant="secondary" onClick={primaryAction.onClick}>
              {primaryAction.label}
            </Button>
          )}
          {secondaryAction && (
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary-foreground/10" onClick={secondaryAction.onClick}>
              {secondaryAction.label}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
