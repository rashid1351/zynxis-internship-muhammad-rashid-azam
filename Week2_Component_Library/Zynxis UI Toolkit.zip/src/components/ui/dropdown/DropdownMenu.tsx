import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface DropdownItem { label: string; onClick?: () => void; href?: string }
export interface DropdownMenuProps {
  trigger: React.ReactNode;
  items: DropdownItem[];
  align?: "left" | "right";
}

export function DropdownMenu({ trigger, items, align = "right" }: DropdownMenuProps) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef<HTMLDivElement>(null);
  React.useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  return (
    <div ref={ref} className="relative inline-block">
      <div onClick={() => setOpen((s) => !s)}>{trigger}</div>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.15 }}
            className={cn(
              "absolute z-50 mt-2 min-w-[180px] rounded-lg border border-border bg-card p-1 shadow-elegant",
              align === "right" ? "right-0" : "left-0",
            )}
          >
            {items.map((it, i) => {
              const Comp = it.href ? "a" : "button";
              return (
                <Comp
                  key={i}
                  href={it.href}
                  onClick={() => { it.onClick?.(); setOpen(false); }}
                  className="block w-full rounded-md px-3 py-1.5 text-left text-sm text-foreground hover:bg-surface"
                >
                  {it.label}
                </Comp>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
