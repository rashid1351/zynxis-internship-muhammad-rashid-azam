// Global site-wide constants for the Zynxis project.

export const SITE = {
  name: "Zynxis",
  tagline: "Modern Component-Based Frontend",
  description:
    "A professional, reusable React component library built for the Zynxis Internship Task.",
  url: "https://zynxis.app",
  email: "hello@zynxis.app",
} as const;

export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Components", href: "/components" },
] as const;

export const FOOTER_LINKS = {
  product: [
    { label: "Features", href: "/#features" },
    { label: "Pricing", href: "/#pricing" },
    { label: "Components", href: "/components" },
  ],
  company: [
    { label: "About", href: "/#about" },
    { label: "Contact", href: "/#contact" },
  ],
} as const;
