# Styles

Global styles live in `src/styles.css` (Tailwind v4 entry + design tokens).
This folder is reserved for any additional shared style modules
(e.g. animation keyframes, print styles) as the project grows.
