import axios from "axios";

const API_BASE = "https://fakestoreapi.com";

const client = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
});

export async function fetchProducts() {
  try {
    const { data } = await client.get("/products");
    if (!Array.isArray(data)) {
      throw new Error("Unexpected response format from server.");
    }
    return data;
  } catch (err) {
    if (err.code === "ECONNABORTED") {
      throw new Error("The request timed out. Please try again.");
    }
    if (err.message === "Network Error") {
      throw new Error("No internet connection. Check your network and retry.");
    }
    if (err.response) {
      throw new Error(`Server error (${err.response.status}). Please try again later.`);
    }
    throw new Error(err.message || "Something went wrong while loading products.");
  }
}

export async function fetchCategories() {
  const { data } = await client.get("/products/categories");
  return data;
}