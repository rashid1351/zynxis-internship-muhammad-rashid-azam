export function formatPrice(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(value ?? 0);
}

export function formatDate(date = new Date()) {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(date);
}

export function getStats(products) {
  if (!products.length) {
    return { total: 0, categories: 0, highest: null, average: 0 };
  }
  const categories = new Set(products.map((p) => p.category));
  const highest = products.reduce((a, b) => (a.price > b.price ? a : b));
  const average =
    products.reduce((sum, p) => sum + p.price, 0) / products.length;
  return {
    total: products.length,
    categories: categories.size,
    highest,
    average,
  };
}

export function filterProducts(products, { search, category }) {
  const q = search.trim().toLowerCase();
  return products.filter((p) => {
    const matchesCat = category === "all" || p.category === category;
    const matchesSearch =
      !q ||
      p.title.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });
}

export function sortProducts(products, sort) {
  const arr = [...products];
  switch (sort) {
    case "price-asc":
      return arr.sort((a, b) => a.price - b.price);
    case "price-desc":
      return arr.sort((a, b) => b.price - a.price);
    case "az":
      return arr.sort((a, b) => a.title.localeCompare(b.title));
    case "za":
      return arr.sort((a, b) => b.title.localeCompare(a.title));
    default:
      return arr;
  }
}

export function truncate(text, n = 100) {
  if (!text) return "";
  return text.length > n ? text.slice(0, n).trim() + "…" : text;
}