import { createFileRoute } from "@tanstack/react-router";
import Dashboard from "../pages/Dashboard.jsx";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Live Data Dashboard" },
      { name: "description", content: "Responsive React dashboard with live product data, search, filtering, sorting, and full API state handling." },
      { property: "og:title", content: "Live Data Dashboard" },
      { property: "og:description", content: "Responsive React dashboard powered by the Fake Store API." },
    ],
  }),
  component: Index,
});

function Index() {
  return <Dashboard />;
}
