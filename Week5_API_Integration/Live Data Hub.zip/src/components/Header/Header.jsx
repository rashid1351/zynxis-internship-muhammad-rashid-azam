import { useEffect, useState } from "react";
import { formatDate } from "../../utils/helpers";

export default function Header({ totalProducts, onRefresh, refreshing }) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <header className="dash-header">
      <div>
        <h1>Live Data Dashboard</h1>
        <p>{formatDate(now)}</p>
      </div>
      <div className="dash-header-meta">
        <span className="dash-pill">
          {totalProducts} {totalProducts === 1 ? "Product" : "Products"}
        </span>
        <button
          className="dash-btn dash-btn-white"
          onClick={onRefresh}
          disabled={refreshing}
          aria-label="Refresh dashboard data"
        >
          {refreshing ? "Refreshing…" : "↻ Refresh"}
        </button>
      </div>
    </header>
  );
}