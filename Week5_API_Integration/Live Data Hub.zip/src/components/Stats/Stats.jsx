import { formatPrice, truncate } from "../../utils/helpers";

export default function Stats({ stats }) {
  const items = [
    { label: "Total Products", value: stats.total, icon: "📦" },
    { label: "Categories", value: stats.categories, icon: "🗂️" },
    {
      label: "Highest Price",
      value: stats.highest ? formatPrice(stats.highest.price) : "—",
      sub: stats.highest ? truncate(stats.highest.title, 36) : null,
      icon: "💎",
    },
    { label: "Average Price", value: formatPrice(stats.average), icon: "📊" },
  ];
  return (
    <section className="dash-stats" aria-label="Dashboard statistics">
      {items.map((it) => (
        <article className="dash-stat-card" key={it.label}>
          <div className="dash-stat-icon" aria-hidden="true">{it.icon}</div>
          <div className="dash-stat-label">{it.label}</div>
          <div className="dash-stat-value">{it.value}</div>
          {it.sub && <div className="dash-stat-sub">{it.sub}</div>}
        </article>
      ))}
    </section>
  );
}