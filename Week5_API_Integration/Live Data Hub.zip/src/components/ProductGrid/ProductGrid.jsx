import ProductCard from "../ProductCard/ProductCard";

export default function ProductGrid({ products, onView }) {
  return (
    <section className="dash-grid" aria-label="Product catalog">
      {products.map((p) => (
        <ProductCard key={p.id} product={p} onView={onView} />
      ))}
    </section>
  );
}