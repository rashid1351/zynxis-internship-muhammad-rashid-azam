const OPTIONS = [
  { value: "default", label: "Sort: Default" },
  { value: "price-asc", label: "Price: Low → High" },
  { value: "price-desc", label: "Price: High → Low" },
  { value: "az", label: "Name: A → Z" },
  { value: "za", label: "Name: Z → A" },
];

export default function SortDropdown({ value, onChange }) {
  return (
    <select
      className="dash-select"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      aria-label="Sort products"
    >
      {OPTIONS.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}