export default function EmptyState({ onReload, title, message }) {
  return (
    <div className="dash-state">
      <div className="dash-state-icon" aria-hidden="true">📭</div>
      <h2>{title || "No Products Found"}</h2>
      <p>{message || "We couldn't find any products matching your criteria."}</p>
      {onReload && (
        <button className="dash-btn dash-btn-primary" onClick={onReload}>
          ↻ Reload
        </button>
      )}
    </div>
  );
}