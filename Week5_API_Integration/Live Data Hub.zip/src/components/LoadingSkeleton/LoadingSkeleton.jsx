export function SkeletonStats() {
  return (
    <div className="dash-stats" aria-hidden="true">
      {Array.from({ length: 4 }).map((_, i) => (
        <div className="dash-stat-card" key={i}>
          <div className="dash-skel dash-skel-line sm" />
          <div className="dash-skel dash-skel-line lg" style={{ height: 22, marginTop: 12 }} />
        </div>
      ))}
    </div>
  );
}

export function SkeletonGrid({ count = 8 }) {
  return (
    <div className="dash-grid" aria-hidden="true" aria-busy="true">
      {Array.from({ length: count }).map((_, i) => (
        <div className="dash-skel-card" key={i}>
          <div className="dash-skel dash-skel-img" />
          <div className="dash-skel dash-skel-line sm" />
          <div className="dash-skel dash-skel-line lg" />
          <div className="dash-skel dash-skel-line md" />
        </div>
      ))}
    </div>
  );
}