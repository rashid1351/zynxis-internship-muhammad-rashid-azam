export default function SearchBar({ value, onChange }) {
  return (
    <div className="dash-search">
      <label htmlFor="dash-search-input" style={{ position: "absolute", left: -9999 }}>
        Search products
      </label>
      <input
        id="dash-search-input"
        className="dash-input"
        type="search"
        placeholder="Search by name or category…"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-label="Search products"
      />
    </div>
  );
}