import { formatPrice, truncate } from "../../utils/helpers";

export default function ProductCard({ product, onView }) {
  return (
    <article className="dash-card">
      <div className="dash-card-img">
        <img src={product.image} alt={product.title} loading="lazy" />
      </div>
      <div className="dash-card-body">
        <span className="dash-card-cat">{product.category}</span>
        <h3 className="dash-card-title">{product.title}</h3>
        <p className="dash-card-desc">{truncate(product.description, 90)}</p>
        <div className="dash-card-row">
          <span className="dash-card-price">{formatPrice(product.price)}</span>
          <span className="dash-card-rating" aria-label={`Rated ${product.rating?.rate} of 5`}>
            ★ {product.rating?.rate ?? "—"}
          </span>
        </div>
      </div>
      <button
        className="dash-btn dash-btn-primary dash-card-btn"
        onClick={() => onView(product)}
      >
        View Details
      </button>
    </article>
  );
}