import { useEffect, useRef } from "react";
import { formatPrice } from "../../utils/helpers";

export default function ProductModal({ product, onClose }) {
  const closeRef = useRef(null);

  useEffect(() => {
    if (!product) return;
    closeRef.current?.focus();
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [product, onClose]);

  if (!product) return null;

  return (
    <div
      className="dash-modal-backdrop"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="dash-modal-title"
    >
      <div className="dash-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dash-modal-head">
          <strong>Product Details</strong>
          <button
            ref={closeRef}
            className="dash-modal-close"
            onClick={onClose}
            aria-label="Close product details"
          >
            ×
          </button>
        </div>
        <div className="dash-modal-body">
          <div className="dash-modal-img">
            <img src={product.image} alt={product.title} />
          </div>
          <div>
            <h2 id="dash-modal-title">{product.title}</h2>
            <div className="dash-modal-meta">
              <span className="dash-tag">{product.category}</span>
              <span className="dash-tag" style={{ background: "#fef3c7", color: "#92400e" }}>
                ★ {product.rating?.rate ?? "—"} ({product.rating?.count ?? 0})
              </span>
            </div>
            <div className="dash-modal-price">{formatPrice(product.price)}</div>
            <p className="dash-modal-desc">{product.description}</p>
          </div>
        </div>
      </div>
    </div>
  );
}