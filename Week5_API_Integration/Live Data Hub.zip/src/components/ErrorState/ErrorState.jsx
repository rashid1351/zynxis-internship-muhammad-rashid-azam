export default function ErrorState({ message, onRetry }) {
  return (
    <div className="dash-state" role="alert">
      <div className="dash-state-icon" aria-hidden="true">⚠️</div>
      <h2>Something went wrong</h2>
      <p>{message || "We couldn't load the data. Please try again."}</p>
      <button className="dash-btn dash-btn-primary" onClick={onRetry}>
        ↻ Retry
      </button>
    </div>
  );
}