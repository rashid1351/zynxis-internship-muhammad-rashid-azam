import { useMemo, useState } from "react";
import Header from "../components/Header/Header";
import Stats from "../components/Stats/Stats";
import SearchBar from "../components/SearchBar/SearchBar";
import CategoryFilter from "../components/CategoryFilter/CategoryFilter";
import SortDropdown from "../components/SortDropdown/SortDropdown";
import ProductGrid from "../components/ProductGrid/ProductGrid";
import { SkeletonStats, SkeletonGrid } from "../components/LoadingSkeleton/LoadingSkeleton";
import ErrorState from "../components/ErrorState/ErrorState";
import EmptyState from "../components/EmptyState/EmptyState";
import ProductModal from "../components/ProductModal/ProductModal";
import { useProducts } from "../hooks/useProducts";
import { filterProducts, sortProducts, getStats } from "../utils/helpers";
import "./dashboard.css";

export default function Dashboard() {
  const { products, loading, error, refresh, retry } = useProducts();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [sort, setSort] = useState("default");
  const [selected, setSelected] = useState(null);

  const visible = useMemo(() => {
    const filtered = filterProducts(products, { search, category });
    return sortProducts(filtered, sort);
  }, [products, search, category, sort]);

  const stats = useMemo(() => getStats(products), [products]);

  return (
    <div className="dash-app">
      <main className="dash-container">
        <Header
          totalProducts={products.length}
          onRefresh={refresh}
          refreshing={loading}
        />

        {loading ? <SkeletonStats /> : <Stats stats={stats} />}

        <section className="dash-controls" aria-label="Product filters">
          <SearchBar value={search} onChange={setSearch} />
          <CategoryFilter value={category} onChange={setCategory} />
          <SortDropdown value={sort} onChange={setSort} />
        </section>

        {loading && <SkeletonGrid />}

        {!loading && error && <ErrorState message={error} onRetry={retry} />}

        {!loading && !error && products.length === 0 && (
          <EmptyState onReload={refresh} />
        )}

        {!loading && !error && products.length > 0 && visible.length === 0 && (
          <EmptyState
            title="No matches"
            message="Try adjusting your search or filters."
          />
        )}

        {!loading && !error && visible.length > 0 && (
          <ProductGrid products={visible} onView={setSelected} />
        )}
      </main>

      <ProductModal product={selected} onClose={() => setSelected(null)} />

      <footer className="dash-footer">
        <div className="dash-footer-inner">
          <div className="dash-footer-brand">
            <h3>Live Data Dashboard</h3>
            <p>Real-time product insights powered by the Fake Store API.</p>
          </div>
          <div className="dash-footer-col">
            <h4>Resources</h4>
            <ul>
              <li><a href="https://fakestoreapi.com/" target="_blank" rel="noreferrer">Fake Store API</a></li>
              <li><a href="https://react.dev/" target="_blank" rel="noreferrer">React Docs</a></li>
              <li><a href="https://vitejs.dev/" target="_blank" rel="noreferrer">Vite</a></li>
            </ul>
          </div>
          <div className="dash-footer-col">
            <h4>Project</h4>
            <ul>
              <li>Week 5 Internship Task</li>
              <li>API Consumption & Handling</li>
            </ul>
          </div>
        </div>
        <div className="dash-footer-bottom">
          © {new Date().getFullYear()} Live Data Dashboard. All rights reserved.
        </div>
      </footer>
    </div>
  );
}