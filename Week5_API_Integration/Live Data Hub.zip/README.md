# Live Data Dashboard

A production-ready, responsive dashboard built with React + Vite that
consumes the public Fake Store API. Demonstrates clean API integration,
loading skeletons, empty/error states, search, filtering, sorting, custom
hooks, and a layered service architecture.

## Features

- Live data fetching from a public REST API on load
- Dashboard header with title, current date, total products, refresh button
- Statistics cards (total products, categories, highest price, average price)
- Responsive product catalog grid
- Real-time search by product name and category
- Category dropdown filter (Electronics, Jewelery, Men's & Women's Clothing)
- Sorting (price asc/desc, A→Z, Z→A)
- Loading skeletons for stats and product grid
- Empty state with illustration and reload button
- Robust error state (network / timeout / API failure / unexpected response) with retry
- Accessible product details modal (keyboard + ESC to close)
- Refresh button that re-fetches data and restores loading state
- Fully responsive (mobile / tablet / desktop)

## Tech Stack

- React 18+ (Hooks)
- Vite
- JavaScript (ES6+)
- Axios
- Clean CSS (responsive, custom design tokens)

## Folder Structure

```
src/
├── components/
│   ├── Header/
│   ├── Stats/
│   ├── ProductCard/
│   ├── ProductGrid/
│   ├── SearchBar/
│   ├── CategoryFilter/
│   ├── SortDropdown/
│   ├── LoadingSkeleton/
│   ├── ErrorState/
│   ├── EmptyState/
│   └── ProductModal/
├── hooks/
│   └── useProducts.js
├── services/
│   └── api.js
├── pages/
│   └── Dashboard.jsx
├── utils/
│   └── helpers.js
├── App.jsx
└── main.jsx
```

## Installation

```bash
bun install      # or: npm install
bun run dev      # or: npm run dev
bun run build    # production build
```

## API Used

- **Fake Store API** — https://fakestoreapi.com/products
- All HTTP requests are centralised in `src/services/api.js`. Components never
  call the API directly — they consume the `useProducts()` custom hook.

## Screenshots

> Add screenshots of the dashboard, modal, and mobile view here.

- `./screenshots/dashboard.png`
- `./screenshots/modal.png`
- `./screenshots/mobile.png`

## Deployment

The app is a static SPA and deploys with zero configuration.

### Vercel
1. Push the repo to GitHub.
2. Import the project on https://vercel.com.
3. Framework preset: **Vite**. Build command: `vite build`. Output: `dist/`.

### Netlify
1. Push the repo to GitHub.
2. New site from Git on https://netlify.com.
3. Build command: `vite build`. Publish directory: `dist/`.

See `ERROR_LOGIC_NOTE.md` for a breakdown of the loading / success / empty /
error / retry strategy.