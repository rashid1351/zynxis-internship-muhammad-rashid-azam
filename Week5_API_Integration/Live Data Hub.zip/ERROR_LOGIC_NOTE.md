# Error Handling Strategy

## Loading State
On mount and on every refresh/retry, `useProducts` sets `loading = true`. The
Dashboard renders `SkeletonStats` and `SkeletonGrid` instead of a blank page,
giving users immediate visual feedback that data is being fetched.

## Success State
When the API responds with a valid product array, the products are stored in
state, `loading` flips to false, and the Dashboard renders the Stats section,
filter controls, and `ProductGrid` of `ProductCard` components.

## Empty State
If the API returns an empty array, or filters/search produce no matches, the
`EmptyState` component is rendered with an icon, a friendly message, and
(when applicable) a Reload button that triggers a fresh API fetch.

## Error State
The service layer (`src/services/api.js`) normalises all error categories —
network failure, timeout (`ECONNABORTED`), unexpected response shape, and
non-2xx HTTP responses — into a clean error message. The hook stores it in
`error` state and the Dashboard renders the `ErrorState` component (icon,
friendly message, Retry button).

## Retry Logic
`useProducts` exposes a `retry`/`refresh` function that increments an internal
counter. The fetch effect depends on that counter, so calling it re-runs the
request, resets `error`, re-triggers skeleton loaders, and updates the
dashboard with fresh data.