import { motion } from "framer-motion";
import { Mail, ArrowRight, Check } from "lucide-react";
import { useState } from "react";
import { fadeInUp, stagger } from "@/animations/variants";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setDone(true);
    setTimeout(() => {
      setEmail("");
      setDone(false);
    }, 2500);
  };

  return (
    <section className="relative py-20">
      <div className="mx-auto max-w-5xl px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={stagger(0.1)}
          className="relative overflow-hidden rounded-3xl glass p-8 md:p-12"
        >
          {/* animated background blobs */}
          <motion.div
            aria-hidden
            className="pointer-events-none absolute -left-20 -top-20 h-64 w-64 rounded-full bg-brand-gradient opacity-30 blur-3xl"
            animate={{ x: [0, 40, 0], y: [0, 20, 0] }}
            transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            aria-hidden
            className="pointer-events-none absolute -bottom-24 -right-10 h-72 w-72 rounded-full bg-accent opacity-25 blur-3xl"
            animate={{ x: [0, -30, 0], y: [0, -20, 0] }}
            transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
          />

          <div className="relative grid items-center gap-8 md:grid-cols-2">
            <div>
              <motion.span variants={fadeInUp} className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 text-xs font-medium text-muted-foreground">
                <Mail className="h-3.5 w-3.5" /> Newsletter
              </motion.span>
              <motion.h3 variants={fadeInUp} className="mt-4 text-3xl font-bold sm:text-4xl">
                Stay in the <span className="text-gradient">loop</span>
              </motion.h3>
              <motion.p variants={fadeInUp} className="mt-3 text-sm text-muted-foreground sm:text-base">
                Fresh sections, motion recipes and product updates — once a month, no spam.
              </motion.p>
            </div>

            <motion.form
              variants={fadeInUp}
              onSubmit={submit}
              className="flex flex-col gap-3 sm:flex-row"
            >
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="flex-1 rounded-xl border border-white/10 bg-background/40 px-4 py-3 text-sm outline-none transition-all focus:border-white/30 focus:bg-background/60 focus:ring-2 focus:ring-[color:var(--ring)]/40"
              />
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.97 }}
                type="submit"
                disabled={done}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-brand-gradient px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow disabled:opacity-80"
              >
                {done ? (
                  <>
                    <Check className="h-4 w-4" /> Subscribed
                  </>
                ) : (
                  <>
                    Subscribe <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </motion.button>
            </motion.form>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
