import logoAsset from "@/assets/nebula-logo.png.asset.json";

type Props = {
  className?: string;
  showWordmark?: boolean;
};

export default function Logo({ className = "h-9 w-9", showWordmark = false }: Props) {
  return (
    <span className="inline-flex items-center gap-2">
      <img
        src={logoAsset.url}
        alt="Nebula logo"
        className={`${className} rounded-xl shadow-glow object-cover`}
        loading="eager"
      />
      {showWordmark && <span className="font-display text-lg font-bold text-gradient">Nebula</span>}
    </span>
  );
}
