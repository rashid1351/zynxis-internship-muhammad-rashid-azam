import { motion, useScroll, useTransform } from "framer-motion";
import { useState } from "react";
import Logo from "./Logo";

const links = [
  { href: "#features", label: "Features" },
  { href: "#stats", label: "Stats" },
  { href: "#testimonials", label: "Testimonials" },
  { href: "#pricing", label: "Pricing" },
  { href: "#contact", label: "Contact" },
];

export function smoothScrollTo(hash: string) {
  const id = hash.replace("#", "");
  if (!id) {
    window.scrollTo({ top: 0, behavior: "smooth" });
    return;
  }
  const el = document.getElementById(id);
  if (!el) return;
  const top = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top, behavior: "smooth" });
}

export default function Navbar() {
  const { scrollY } = useScroll();
  const bgOpacity = useTransform(scrollY, [0, 200], [0.4, 0.85]);
  const [active, setActive] = useState<string>("");

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setActive(href);
    smoothScrollTo(href);
    history.replaceState(null, "", href);
  };

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-4 left-1/2 z-50 w-[min(1100px,92%)] -translate-x-1/2 overflow-hidden rounded-2xl border border-white/10"
    >
      {/* Animated dark background */}
      <motion.div
        aria-hidden
        style={{ opacity: bgOpacity }}
        className="absolute inset-0 -z-10 bg-[oklch(0.13_0.03_270)] backdrop-blur-xl"
      />
      <div aria-hidden className="absolute inset-0 -z-10 overflow-hidden">
        <motion.div
          className="absolute -top-16 -left-10 h-40 w-40 rounded-full bg-brand-gradient opacity-30 blur-3xl"
          animate={{ x: [0, 60, 0], y: [0, 10, 0] }}
          transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute -top-20 right-0 h-40 w-56 rounded-full bg-accent opacity-25 blur-3xl"
          animate={{ x: [0, -50, 0], y: [0, 14, 0] }}
          transition={{ duration: 11, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute inset-0 opacity-[0.08]"
          style={{
            backgroundImage:
              "linear-gradient(90deg, transparent 0, transparent 24px, rgba(255,255,255,0.5) 25px), linear-gradient(0deg, transparent 0, transparent 24px, rgba(255,255,255,0.5) 25px)",
            backgroundSize: "25px 25px",
          }}
          animate={{ backgroundPositionX: ["0px", "25px"] }}
          transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
        />
      </div>

      <nav className="relative flex items-center justify-between px-5 py-3">
        <a
          href="#"
          onClick={(e) => handleClick(e, "#")}
          className="flex items-center gap-2 font-display text-lg font-bold"
        >
          <Logo className="h-9 w-9" />
          <span className="text-gradient">Nebula</span>
        </a>
        <ul className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={(e) => handleClick(e, l.href)}
                className={`relative transition-colors hover:text-foreground ${
                  active === l.href ? "text-foreground" : ""
                }`}
              >
                {l.label}
                {active === l.href && (
                  <motion.span
                    layoutId="nav-underline"
                    className="absolute -bottom-1 left-0 h-0.5 w-full rounded-full bg-brand-gradient"
                  />
                )}
              </a>
            </li>
          ))}
        </ul>
        <a
          href="#contact"
          onClick={(e) => handleClick(e, "#contact")}
          className="rounded-xl bg-brand-gradient px-4 py-2 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-105"
        >
          Get Started
        </a>
      </nav>
    </motion.header>
  );
}
