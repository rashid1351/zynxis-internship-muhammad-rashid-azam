import { motion } from "framer-motion";
import { Quote, Star } from "lucide-react";
import { fadeInUp, stagger } from "@/animations/variants";

const items = [
  {
    name: "Aisha Khan",
    role: "Product Designer, Linear",
    review:
      "Nebula raised the bar for our landing pages. The animations feel premium without ever getting in the way.",
    img: "https://i.pravatar.cc/120?img=47",
  },
  {
    name: "Marcus Lee",
    role: "Founder, Vault",
    review:
      "Shipped a polished marketing site in a weekend. The motion system alone was worth it.",
    img: "https://i.pravatar.cc/120?img=12",
  },
  {
    name: "Priya Sharma",
    role: "Engineering Lead, Orbit",
    review:
      "Clean code, sensible defaults, and the responsive grid just works. Our team adopted it instantly.",
    img: "https://i.pravatar.cc/120?img=32",
  },
  {
    name: "Diego Alvarez",
    role: "CTO, Pulse",
    review:
      "The attention to micro-interactions is unreal. It made our product feel ten times more polished overnight.",
    img: "https://i.pravatar.cc/120?img=15",
  },
  {
    name: "Hana Tanaka",
    role: "Designer, Mode",
    review:
      "Beautifully crafted. Every spacing, color and easing curve feels deliberate — exactly what we needed.",
    img: "https://i.pravatar.cc/120?img=49",
  },
  {
    name: "Leo Bauer",
    role: "Indie Hacker",
    review:
      "I launched my SaaS landing page in a single evening. Conversions doubled the first week.",
    img: "https://i.pravatar.cc/120?img=7",
  },
  {
    name: "Naomi Park",
    role: "Head of Growth, Drift",
    review:
      "Smooth scroll, motion, and a clean design system. The whole experience just feels expensive.",
    img: "https://i.pravatar.cc/120?img=44",
  },
  {
    name: "Omar Haddad",
    role: "Engineer, Forge",
    review:
      "Code quality is excellent. Tailwind tokens plus Framer Motion variants — exactly the patterns I’d pick.",
    img: "https://i.pravatar.cc/120?img=53",
  },
];

function Card({ t }: { t: (typeof items)[number] }) {
  return (
    <article className="mx-3 w-[340px] shrink-0 rounded-2xl glass p-6 transition-shadow hover:shadow-glow">
      <div className="flex items-center justify-between">
        <Quote className="h-7 w-7 text-accent" />
        <div className="flex gap-0.5 text-[hsl(45_100%_60%)]">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} className="h-3.5 w-3.5 fill-current" />
          ))}
        </div>
      </div>
      <p className="mt-4 text-sm leading-relaxed text-foreground/90">"{t.review}"</p>
      <div className="mt-6 flex items-center gap-3">
        <img
          src={t.img}
          alt={t.name}
          loading="lazy"
          className="h-11 w-11 rounded-full ring-2 ring-white/10"
        />
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold">{t.name}</div>
          <div className="truncate text-xs text-muted-foreground">{t.role}</div>
        </div>
      </div>
    </article>
  );
}

function Row({ reverse = false, duration = 40 }: { reverse?: boolean; duration?: number }) {
  const loop = [...items, ...items];
  return (
    <div className="group relative overflow-hidden">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-background to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-background to-transparent" />
      <motion.div
        className="flex w-max"
        animate={{ x: reverse ? ["-50%", "0%"] : ["0%", "-50%"] }}
        transition={{ duration, repeat: Infinity, ease: "linear" }}
      >
        {loop.map((t, i) => (
          <Card key={`${t.name}-${i}`} t={t} />
        ))}
      </motion.div>
    </div>
  );
}

export default function Testimonials() {
  return (
    <section id="testimonials" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.4 }}
          variants={stagger(0.1)}
          className="mx-auto max-w-2xl text-center"
        >
          <motion.span variants={fadeInUp} className="text-sm font-semibold uppercase tracking-widest text-accent">
            Loved by teams
          </motion.span>
          <motion.h2 variants={fadeInUp} className="mt-3 text-4xl font-bold sm:text-5xl">
            What people <span className="text-gradient">are saying</span>
          </motion.h2>
        </motion.div>
      </div>

      <div className="mt-14 space-y-5">
        <Row duration={45} />
        <Row reverse duration={55} />
      </div>
    </section>
  );
}
