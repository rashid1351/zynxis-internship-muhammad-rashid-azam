import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { fadeInUp, stagger } from "@/animations/variants";

const plans = [
  {
    name: "Basic",
    price: "$9",
    desc: "For individuals getting started.",
    features: ["1 project", "Community support", "Basic analytics", "10k requests / mo"],
  },
  {
    name: "Pro",
    price: "$29",
    desc: "For growing teams that ship fast.",
    features: ["Unlimited projects", "Priority support", "Advanced analytics", "1M requests / mo", "Custom domains"],
    highlight: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    desc: "Tailored to your organization.",
    features: ["SLA & SSO", "Dedicated CSM", "Audit logs", "Unlimited everything"],
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.4 }}
          variants={stagger(0.1)}
          className="mx-auto max-w-2xl text-center"
        >
          <motion.span variants={fadeInUp} className="text-sm font-semibold uppercase tracking-widest text-accent">
            Pricing
          </motion.span>
          <motion.h2 variants={fadeInUp} className="mt-3 text-4xl font-bold sm:text-5xl">
            Simple, <span className="text-gradient">scalable</span> plans
          </motion.h2>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
          variants={stagger(0.12)}
          className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-3"
        >
          {plans.map((p) => (
            <motion.div
              key={p.name}
              variants={fadeInUp}
              whileHover={{ y: -10, scale: 1.02 }}
              transition={{ type: "spring", stiffness: 260, damping: 20 }}
              className={`relative rounded-2xl p-7 transition-shadow hover:shadow-glow ${
                p.highlight
                  ? "bg-brand-gradient text-primary-foreground shadow-glow"
                  : "glass"
              }`}
            >
              {p.highlight && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-background px-3 py-1 text-xs font-semibold text-accent">
                  Most popular
                </span>
              )}
              <h3 className="font-display text-xl font-bold">{p.name}</h3>
              <p className={`mt-1 text-sm ${p.highlight ? "opacity-80" : "text-muted-foreground"}`}>{p.desc}</p>
              <div className="mt-5 flex items-baseline gap-1">
                <span className="font-display text-5xl font-bold">{p.price}</span>
                {p.price !== "Custom" && <span className="text-sm opacity-70">/mo</span>}
              </div>
              <ul className="mt-6 space-y-3 text-sm">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2">
                    <Check className="h-4 w-4 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                className={`mt-7 w-full rounded-xl px-4 py-3 text-sm font-semibold transition-transform hover:scale-[1.02] ${
                  p.highlight ? "bg-background text-foreground" : "bg-brand-gradient text-primary-foreground"
                }`}
              >
                Choose {p.name}
              </button>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
