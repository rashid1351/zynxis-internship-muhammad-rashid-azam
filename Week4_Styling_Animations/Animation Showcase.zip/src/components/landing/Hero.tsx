import { motion } from "framer-motion";
import { ArrowRight, Play } from "lucide-react";
import { fadeInDown, fadeInUp, stagger } from "@/animations/variants";

export default function Hero() {
  return (
    <section className="relative isolate overflow-hidden bg-hero pt-36 pb-24 md:pt-44 md:pb-32">
      {/* floating blobs */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -top-24 -left-24 h-80 w-80 rounded-full bg-brand-gradient opacity-30 blur-3xl"
        animate={{ y: [0, 30, 0], x: [0, 20, 0] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -bottom-32 -right-24 h-96 w-96 rounded-full bg-accent opacity-20 blur-3xl"
        animate={{ y: [0, -30, 0], x: [0, -20, 0] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        variants={stagger(0.18, 0.1)}
        initial="hidden"
        animate="visible"
        className="mx-auto max-w-5xl px-6 text-center"
      >
        <motion.span
          variants={fadeInDown}
          className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium text-muted-foreground"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-brand-gradient" />
          New • Animations powered by Framer Motion
        </motion.span>

        <motion.h1
          variants={fadeInDown}
          className="mt-6 text-5xl font-bold leading-[1.05] sm:text-6xl md:text-7xl"
        >
          Build interfaces that <br className="hidden sm:block" />
          <span className="text-gradient">feel alive.</span>
        </motion.h1>

        <motion.p
          variants={fadeInUp}
          className="mx-auto mt-6 max-w-2xl text-base text-muted-foreground sm:text-lg"
        >
          Nebula is the premium toolkit for crafting modern landing pages with smooth motion,
          responsive layouts, and a design system that ships production-ready.
        </motion.p>

        <motion.div variants={fadeInUp} className="mt-9 flex flex-wrap items-center justify-center gap-3">
          <motion.a
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
            href="#pricing"
            className="inline-flex items-center gap-2 rounded-xl bg-brand-gradient px-6 py-3 text-sm font-semibold text-primary-foreground shadow-glow"
          >
            Start Building <ArrowRight className="h-4 w-4" />
          </motion.a>
          <motion.a
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
            href="#features"
            className="inline-flex items-center gap-2 rounded-xl glass px-6 py-3 text-sm font-semibold"
          >
            <Play className="h-4 w-4" /> Watch demo
          </motion.a>
        </motion.div>

        <motion.div
          variants={fadeInUp}
          className="mx-auto mt-16 max-w-4xl rounded-3xl glass p-2 shadow-glow"
        >
          <div className="rounded-2xl bg-card p-6">
            <div className="grid grid-cols-3 gap-4 text-left">
              {["Performance", "Accessibility", "Design"].map((k) => (
                <div key={k} className="rounded-xl bg-secondary/60 p-4">
                  <div className="text-xs text-muted-foreground">{k}</div>
                  <div className="mt-1 font-display text-2xl font-bold text-gradient">99+</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
