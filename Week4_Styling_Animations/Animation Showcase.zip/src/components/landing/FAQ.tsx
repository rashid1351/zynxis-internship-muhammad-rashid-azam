import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";
import { useState } from "react";
import { fadeInUp, stagger } from "@/animations/variants";

const faqs = [
  {
    q: "Is Nebula free to use?",
    a: "Nebula offers a generous free tier for personal projects. Upgrade to Pro or Studio for unlimited projects, premium sections and priority support.",
  },
  {
    q: "Which frameworks does it support?",
    a: "Nebula ships clean React + Tailwind code that drops into any modern React stack — Vite, Next.js, Remix or TanStack Start.",
  },
  {
    q: "Are the animations accessible?",
    a: "Yes. Every motion preset respects prefers-reduced-motion and falls back to subtle opacity transitions for users who need it.",
  },
  {
    q: "Can I use my own design tokens?",
    a: "Absolutely. Swap our CSS variables for your own brand tokens and every component updates automatically.",
  },
  {
    q: "Do you offer team licensing?",
    a: "Our Studio plan covers entire teams, including shared component libraries and unlimited seats.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-3xl px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.4 }}
          variants={stagger(0.1)}
          className="text-center"
        >
          <motion.span variants={fadeInUp} className="text-sm font-semibold uppercase tracking-widest text-accent">
            FAQ
          </motion.span>
          <motion.h2 variants={fadeInUp} className="mt-3 text-4xl font-bold sm:text-5xl">
            Questions, <span className="text-gradient">answered</span>
          </motion.h2>
          <motion.p variants={fadeInUp} className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Everything you need to know before you start building with Nebula.
          </motion.p>
        </motion.div>

        <motion.ul
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={stagger(0.08)}
          className="mt-12 space-y-3"
        >
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <motion.li
                key={f.q}
                variants={fadeInUp}
                className="rounded-2xl glass overflow-hidden"
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition-colors hover:bg-white/5"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm font-semibold sm:text-base">{f.q}</span>
                  <motion.span
                    animate={{ rotate: isOpen ? 45 : 0 }}
                    transition={{ duration: 0.25 }}
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand-gradient text-primary-foreground shadow-glow"
                  >
                    <Plus className="h-4 w-4" />
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      key="content"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="px-5 pb-5 text-sm leading-relaxed text-muted-foreground">
                        {f.a}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.li>
            );
          })}
        </motion.ul>
      </div>
    </section>
  );
}
