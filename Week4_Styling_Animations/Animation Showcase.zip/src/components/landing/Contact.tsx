import { motion } from "framer-motion";
import { useState } from "react";
import { Send } from "lucide-react";
import { fadeInUp, stagger } from "@/animations/variants";

export default function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-3xl px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={stagger(0.1)}
          className="rounded-3xl glass p-8 shadow-glow md:p-12"
        >
          <motion.div variants={fadeInUp} className="text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-accent">Contact</span>
            <h2 className="mt-3 text-4xl font-bold sm:text-5xl">
              Let's <span className="text-gradient">build together</span>
            </h2>
            <p className="mt-3 text-muted-foreground">Have a question or project? Drop us a message.</p>
          </motion.div>

          <motion.form
            variants={fadeInUp}
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
              setTimeout(() => setSent(false), 2500);
            }}
            className="mt-8 space-y-4"
          >
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Name" name="name" type="text" placeholder="Jane Doe" />
              <Field label="Email" name="email" type="email" placeholder="jane@company.com" />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Message</label>
              <textarea
                required
                rows={5}
                placeholder="Tell us about your project..."
                className="w-full resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none transition-all focus:border-transparent focus:ring-2 focus:ring-accent focus:bg-white/10"
              />
            </div>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-brand-gradient px-6 py-3 text-sm font-semibold text-primary-foreground shadow-glow"
            >
              {sent ? "Sent! ✨" : (<>Send message <Send className="h-4 w-4" /></>)}
            </motion.button>
          </motion.form>
        </motion.div>
      </div>
    </section>
  );
}

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</label>
      <input
        required
        {...props}
        className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none transition-all focus:border-transparent focus:ring-2 focus:ring-accent focus:bg-white/10"
      />
    </div>
  );
}
