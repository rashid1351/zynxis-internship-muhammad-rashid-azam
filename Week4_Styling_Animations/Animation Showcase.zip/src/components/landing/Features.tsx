import { motion } from "framer-motion";
import { Zap, Shield, Palette, Rocket, Layers, Smartphone } from "lucide-react";
import { fadeInUp, stagger } from "@/animations/variants";

const features = [
  { icon: Zap, title: "Lightning Fast", desc: "Optimized animations and code-splitting keep your pages instant." },
  { icon: Palette, title: "Beautiful Design", desc: "A cohesive design system with gradients, glassmorphism and motion." },
  { icon: Shield, title: "Production Ready", desc: "Type-safe components, accessible defaults, battle-tested in prod." },
  { icon: Rocket, title: "Framer Motion", desc: "Stagger, scroll, hover and entrance animations baked in." },
  { icon: Layers, title: "Composable", desc: "Modular sections you can rearrange or extend in minutes." },
  { icon: Smartphone, title: "Fully Responsive", desc: "Mobile-first layouts that scale gracefully to any breakpoint." },
];

export default function Features() {
  return (
    <section id="features" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.4 }}
          variants={stagger(0.1)}
          className="mx-auto max-w-2xl text-center"
        >
          <motion.span variants={fadeInUp} className="text-sm font-semibold uppercase tracking-widest text-accent">
            Features
          </motion.span>
          <motion.h2 variants={fadeInUp} className="mt-3 text-4xl font-bold sm:text-5xl">
            Everything you need <span className="text-gradient">to launch.</span>
          </motion.h2>
          <motion.p variants={fadeInUp} className="mt-4 text-muted-foreground">
            Built-in animation system, responsive primitives, and modern styling utilities.
          </motion.p>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
          variants={stagger(0.1)}
          className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          {features.map(({ icon: Icon, title, desc }) => (
            <motion.div
              key={title}
              variants={fadeInUp}
              whileHover={{ y: -6, scale: 1.02 }}
              transition={{ type: "spring", stiffness: 260, damping: 20 }}
              className="group relative rounded-2xl glass p-6 transition-shadow hover:shadow-glow"
            >
              <motion.div
                whileHover={{ rotate: 8, scale: 1.1 }}
                className="grid h-12 w-12 place-items-center rounded-xl bg-brand-gradient shadow-glow"
              >
                <Icon className="h-6 w-6 text-primary-foreground" />
              </motion.div>
              <h3 className="mt-5 text-lg font-semibold">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
