import { motion } from "framer-motion";

const logos = [
  "Linear", "Vercel", "Stripe", "Notion", "Figma", "Loom", "Framer", "Raycast",
];

export default function LogoCloud() {
  const loop = [...logos, ...logos];
  return (
    <section className="relative border-y border-white/5 py-12">
      <div className="mx-auto max-w-6xl px-6 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-muted-foreground">
          Trusted by ambitious teams worldwide
        </p>
      </div>
      <div className="relative mt-8 overflow-hidden">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-32 bg-gradient-to-r from-background to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-32 bg-gradient-to-l from-background to-transparent" />
        <motion.div
          className="flex w-max items-center gap-16 px-6"
          animate={{ x: ["0%", "-50%"] }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
        >
          {loop.map((name, i) => (
            <span
              key={`${name}-${i}`}
              className="font-display text-2xl font-semibold tracking-tight text-muted-foreground/70 transition-colors hover:text-foreground"
            >
              {name}
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
