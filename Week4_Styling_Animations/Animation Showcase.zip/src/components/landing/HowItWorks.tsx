import { motion } from "framer-motion";
import { Wand2, Layers, Rocket, Sparkles } from "lucide-react";
import { fadeInUp, stagger } from "@/animations/variants";

const steps = [
  {
    icon: Wand2,
    title: "Choose a starting point",
    body: "Pick from curated sections, layouts and animation presets crafted for modern SaaS.",
  },
  {
    icon: Layers,
    title: "Compose your page",
    body: "Drag in components, tweak tokens, and let the design system keep everything cohesive.",
  },
  {
    icon: Sparkles,
    title: "Add motion that matters",
    body: "Apply scroll, hover and stagger variants in a click — accessible by default.",
  },
  {
    icon: Rocket,
    title: "Ship to the world",
    body: "Export production-grade React + Tailwind code and deploy in minutes.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.4 }}
          variants={stagger(0.1)}
          className="mx-auto max-w-2xl text-center"
        >
          <motion.span variants={fadeInUp} className="text-sm font-semibold uppercase tracking-widest text-accent">
            How it works
          </motion.span>
          <motion.h2 variants={fadeInUp} className="mt-3 text-4xl font-bold sm:text-5xl">
            From idea to launch in <span className="text-gradient">four steps</span>
          </motion.h2>
        </motion.div>

        <div className="relative mt-16">
          {/* connecting line */}
          <div
            aria-hidden
            className="pointer-events-none absolute left-0 right-0 top-9 hidden h-px bg-gradient-to-r from-transparent via-white/20 to-transparent md:block"
          />
          <motion.ol
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            variants={stagger(0.15)}
            className="grid grid-cols-1 gap-8 md:grid-cols-4"
          >
            {steps.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.li
                  key={s.title}
                  variants={fadeInUp}
                  whileHover={{ y: -6 }}
                  className="relative rounded-2xl glass p-6"
                >
                  <div className="relative z-10 grid h-14 w-14 place-items-center rounded-2xl bg-brand-gradient shadow-glow">
                    <Icon className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <div className="mt-5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    Step {String(i + 1).padStart(2, "0")}
                  </div>
                  <h3 className="mt-1 text-lg font-semibold">{s.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{s.body}</p>
                </motion.li>
              );
            })}
          </motion.ol>
        </div>
      </div>
    </section>
  );
}
