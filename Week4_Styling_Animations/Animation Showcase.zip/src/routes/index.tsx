import { createFileRoute } from "@tanstack/react-router";
import Navbar from "@/components/landing/Navbar";
import Hero from "@/components/landing/Hero";
import LogoCloud from "@/components/landing/LogoCloud";
import Features from "@/components/landing/Features";
import HowItWorks from "@/components/landing/HowItWorks";
import Statistics from "@/components/landing/Statistics";
import Testimonials from "@/components/landing/Testimonials";
import Pricing from "@/components/landing/Pricing";
import FAQ from "@/components/landing/FAQ";
import Newsletter from "@/components/landing/Newsletter";
import Contact from "@/components/landing/Contact";
import Footer from "@/components/landing/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nebula — Premium Landing Page Toolkit" },
      {
        name: "description",
        content:
          "Nebula is a premium landing page toolkit with Framer Motion animations, responsive design, and a modern design system.",
      },
      { property: "og:title", content: "Nebula — Premium Landing Page Toolkit" },
      {
        property: "og:description",
        content:
          "Build modern, animated, responsive landing pages with Framer Motion and Tailwind CSS.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="relative min-h-screen overflow-x-hidden">
      <Navbar />
      <Hero />
      <LogoCloud />
      <Features />
      <HowItWorks />
      <Statistics />
      <Testimonials />
      <Pricing />
      <FAQ />
      <Newsletter />
      <Contact />
      <Footer />
    </main>
  );
}
