# Nebula — Week 4 Internship Project

A premium, fully responsive React landing page showcasing advanced styling and smooth Framer Motion animations.

## Overview
Nebula is a modern SaaS-style landing page built to demonstrate advanced frontend techniques: a custom design system, glassmorphism, gradient effects, and a complete suite of entrance, hover and scroll-triggered animations.

## Features
- Animated hero with staggered entrance and floating gradient blobs
- 6 feature cards with hover scale, glow and icon animations
- Animated statistics counters that trigger when in view
- Testimonials with slide-in-left/right animations
- Pricing section with highlighted Pro plan
- Glassmorphism contact form with input focus animations
- Responsive navbar and footer with social icons
- Fully mobile-first responsive (mobile, tablet, desktop)

## Technologies
- React 19
- TanStack Start + Vite
- Tailwind CSS v4
- Framer Motion
- Lucide React (icons)

## Installation
```bash
bun install
bun run dev
```
Then open the printed local URL.

## Project Structure
```
src/
├── components/landing/   # Navbar, Hero, Features, Statistics, Testimonials, Pricing, Contact, Footer
├── animations/variants.js
├── routes/index.tsx      # Landing page route
└── styles.css            # Design system tokens
```

## Animations Implemented
- Entrance: fade in, slide up/down/left/right
- Hover: scale, lift, glow, icon rotate
- Scroll: viewport-triggered with `whileInView`
- Counters: animated count-up on view

## Screenshots
_Add screenshots of each section here._

## Author
**Muhammad Rashid Azam**
