import { Link, useRouterState } from "@tanstack/react-router";
import { memo, useState, type ReactNode } from "react";
import {
  Activity,
  BarChart3,
  Bell,
  Command,
  Github,
  Home,
  Menu,
  Moon,
  Package,
  Search,
  Settings,
  Sparkles,
  Sun,
  X,
} from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import logoAsset from "@/assets/performancepro-logo.png.asset.json";


const nav = [
  { to: "/", label: "Home", icon: Home },
  { to: "/products", label: "Products", icon: Package },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const { theme, toggle } = useTheme();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="flex min-h-dvh bg-background text-foreground">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground">
        Skip to content
      </a>

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 border-r border-border bg-card transition-transform lg:static lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}
        aria-label="Primary navigation"
      >
        <div className="flex h-16 items-center gap-3 border-b border-border px-6">
          <img
            src={logoAsset.url}
            alt="PerformancePro"
            width={32}
            height={32}
            loading="eager"
            decoding="async"
            className="h-8 w-8 rounded-md bg-white object-contain shadow-sm"
          />
          <span className="text-sm font-semibold tracking-tight">PerformancePro</span>
        </div>
        <nav id="primary-navigation" className="space-y-1 p-3">
          {nav.map(({ to, label, icon: Icon }) => {
            const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
            return (
              <Link
                key={to}
                to={to}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors ${active ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"}`}
                aria-current={active ? "page" : undefined}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
                {label}
              </Link>
            );
          })}
        </nav>
        <div className="absolute inset-x-3 bottom-3 rounded-md border border-border bg-muted/50 p-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-2 font-medium text-foreground">
            <Activity className="h-3.5 w-3.5" aria-hidden="true" /> Web Vitals: 98
          </div>
          <p className="mt-1">LCP 1.4s · CLS 0.02 · INP 84ms</p>
        </div>
      </aside>

      {open && (
        <button
          aria-label="Close menu"
          onClick={() => setOpen(false)}
          className="fixed inset-0 z-30 bg-foreground/30 backdrop-blur-sm lg:hidden"
        />
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <TopHeader
          open={open}
          onToggleMenu={() => setOpen((p) => !p)}
          theme={theme}
          onToggleTheme={toggle}
        />
        <main id="main" className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}

interface TopHeaderProps {
  open: boolean;
  onToggleMenu: () => void;
  theme: "light" | "dark";
  onToggleTheme: () => void;
}

const TopHeader = memo(function TopHeader({
  open,
  onToggleMenu,
  theme,
  onToggleTheme,
}: TopHeaderProps) {
  return (
    <header
      role="banner"
      className="sticky top-0 z-20 border-b border-border bg-background/70 backdrop-blur supports-[backdrop-filter]:bg-background/60"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent"
      />
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
        <button
          onClick={onToggleMenu}
          className="rounded-md p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground lg:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          aria-controls="primary-navigation"
        >
          {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
        </button>

        <Link
          to="/"
          className="group flex items-center gap-3 lg:hidden"
          aria-label="PerformancePro home"
        >
          <img
            src={logoAsset.url}
            alt=""
            width={32}
            height={32}
            loading="eager"
            decoding="async"
            className="h-8 w-8 rounded-md bg-white object-contain shadow-[var(--shadow-glow)]"
          />
          <span className="text-sm font-semibold tracking-tight">PerformancePro</span>
        </Link>

        {/* Search */}
        <form
          role="search"
          onSubmit={(e) => e.preventDefault()}
          className="ml-1 hidden min-w-0 max-w-md flex-1 md:flex"
        >
          <label htmlFor="global-search" className="sr-only">
            Search the dashboard
          </label>
          <div className="group relative flex w-full items-center">
            <Search
              className="pointer-events-none absolute left-3 h-4 w-4 text-muted-foreground transition-colors group-focus-within:text-primary"
              aria-hidden="true"
            />
            <input
              id="global-search"
              type="search"
              placeholder="Search products, pages, metrics…"
              autoComplete="off"
              className="h-10 w-full rounded-md border border-border bg-muted/40 pl-9 pr-16 text-sm text-foreground placeholder:text-muted-foreground transition-colors hover:bg-muted/60 focus:border-ring focus:bg-background focus:outline-none"
            />
            <kbd className="pointer-events-none absolute right-2 hidden items-center gap-1 rounded border border-border bg-background px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground sm:inline-flex">
              <Command className="h-3 w-3" aria-hidden="true" />K
            </kbd>
          </div>
        </form>

        {/* Status pill */}
        <div
          className="ml-auto hidden items-center gap-2 rounded-full border border-border bg-muted/50 px-3 py-1.5 text-xs font-medium text-muted-foreground xl:inline-flex"
          aria-label="Live performance status"
        >
          <span className="relative flex h-2 w-2" aria-hidden="true">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary/60 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
          </span>
          <Activity className="h-3.5 w-3.5" aria-hidden="true" />
          <span className="text-foreground">98</span>
          <span aria-hidden="true">·</span>
          <span>LCP 1.4s</span>
          <span aria-hidden="true">·</span>
          <span>CLS 0.02</span>
        </div>

        <div className="ml-auto flex items-center gap-1.5 xl:ml-3">
          <Link
            to="/analytics"
            className="hidden items-center gap-1.5 rounded-md bg-primary/10 px-3 py-2 text-xs font-semibold text-primary ring-1 ring-inset ring-primary/20 transition-colors hover:bg-primary/15 sm:inline-flex"
          >
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            Upgrade
          </Link>

          <button
            type="button"
            className="relative rounded-md border border-border p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            aria-label="View notifications (3 unread)"
          >
            <Bell className="h-4 w-4" aria-hidden="true" />
            <span
              className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-primary ring-2 ring-background"
              aria-hidden="true"
            />
          </button>

          <a
            href="https://github.com"
            target="_blank"
            rel="noreferrer noopener"
            className="hidden rounded-md border border-border p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground sm:inline-flex"
            aria-label="Open repository on GitHub"
          >
            <Github className="h-4 w-4" aria-hidden="true" />
          </a>

          <button
            onClick={onToggleTheme}
            className="rounded-md border border-border p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4" aria-hidden="true" />
            ) : (
              <Moon className="h-4 w-4" aria-hidden="true" />
            )}
          </button>

          <div
            className="ml-1 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary to-primary/60 text-xs font-semibold text-primary-foreground shadow-[var(--shadow-glow)]"
            aria-label="Signed in as Priya"
            title="Priya"
          >
            PR
          </div>
        </div>
      </div>
    </header>
  );
});