import { Link } from "@tanstack/react-router";
import { memo } from "react";
import { Star } from "lucide-react";
import type { Product } from "@/data/products";

function ProductCardImpl({ product }: { product: Product }) {
  return (
    <Link
      to="/products/$id"
      params={{ id: product.id }}
      className="surface-card group block overflow-hidden transition-transform hover:-translate-y-0.5 hover:shadow-[var(--shadow-glow)]"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        <img
          src={product.image}
          alt={product.name}
          width={600}
          height={450}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <span className="absolute left-3 top-3 rounded-full bg-background/85 px-2 py-0.5 text-xs font-medium text-foreground backdrop-blur">
          {product.category}
        </span>
      </div>
      <div className="space-y-2 p-4">
        <h3 className="line-clamp-1 text-sm font-semibold">{product.name}</h3>
        <p className="line-clamp-2 text-xs text-muted-foreground">{product.description}</p>
        <div className="flex items-center justify-between pt-1">
          <span className="text-base font-bold">${product.price}</span>
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3.5 w-3.5 fill-primary text-primary" aria-hidden="true" />
            {product.rating}
            <span className="sr-only">out of 5</span>
            <span aria-hidden="true">· {product.reviews}</span>
          </span>
        </div>
      </div>
    </Link>
  );
}

export const ProductCard = memo(ProductCardImpl);