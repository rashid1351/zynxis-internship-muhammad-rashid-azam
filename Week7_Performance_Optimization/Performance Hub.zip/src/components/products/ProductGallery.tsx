import { useMemo, useState } from "react";

interface Props {
  productId: string;
  productName: string;
  primaryImage: string;
}

export default function ProductGallery({ productId, productName, primaryImage }: Props) {
  const [active, setActive] = useState(0);

  const gallery = useMemo(
    () => [
      primaryImage,
      `https://picsum.photos/seed/perfpro-${productId}-b/600/450.webp`,
      `https://picsum.photos/seed/perfpro-${productId}-c/600/450.webp`,
    ],
    [productId, primaryImage],
  );

  return (
    <div>
      <div className="surface-card overflow-hidden">
        <img
          src={gallery[active]}
          alt={`${productName} – view ${active + 1}`}
          width={600}
          height={450}
          decoding="async"
          fetchPriority="high"
          className="aspect-[4/3] w-full object-cover"
        />
      </div>
      <div className="mt-3 grid grid-cols-3 gap-3">
        {gallery.map((src, i) => (
          <button
            key={src}
            type="button"
            onClick={() => setActive(i)}
            aria-label={`Show image ${i + 1}`}
            aria-pressed={active === i}
            className={`overflow-hidden rounded-md border-2 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${active === i ? "border-primary" : "border-border"}`}
          >
            <img
              src={src}
              alt=""
              width={200}
              height={150}
              loading="lazy"
              decoding="async"
              className="aspect-[4/3] w-full object-cover"
            />
          </button>
        ))}
      </div>
    </div>
  );
}