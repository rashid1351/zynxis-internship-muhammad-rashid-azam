import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useMemo } from "react";

const palette = ["#38BDF8", "#94A3B8", "#0EA5E9", "#64748B", "#7DD3FC", "#475569"];

const tooltipStyle = {
  background: "var(--color-popover)",
  border: "1px solid var(--color-border)",
  borderRadius: 8,
  color: "var(--color-popover-foreground)",
  fontSize: 12,
};

function Card({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <section className="surface-card p-5">
      <header className="mb-4">
        <h3 className="text-sm font-semibold">{title}</h3>
        {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
      </header>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">{children as any}</ResponsiveContainer>
      </div>
    </section>
  );
}

export default function Charts() {
  const sales = useMemo(
    () => ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].map((m, i) => ({
      month: m,
      sales: Math.round(8000 + Math.sin(i) * 2000 + i * 600),
      orders: Math.round(120 + Math.cos(i) * 30 + i * 8),
    })),
    [],
  );

  const vitals = useMemo(
    () => Array.from({ length: 14 }).map((_, i) => ({
      day: `D${i + 1}`,
      LCP: 1.4 + Math.sin(i / 2) * 0.3,
      INP: 80 + Math.cos(i / 2) * 20,
      CLS: 0.02 + Math.sin(i / 3) * 0.01,
    })),
    [],
  );

  const categoryShare = useMemo(
    () => [
      { name: "Audio", value: 28 },
      { name: "Laptops", value: 22 },
      { name: "Cameras", value: 14 },
      { name: "Wearables", value: 18 },
      { name: "Displays", value: 10 },
      { name: "Accessories", value: 8 },
    ],
    [],
  );

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Sales over time" subtitle="Revenue, last 12 months">
        <AreaChart data={sales}>
          <defs>
            <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#38BDF8" stopOpacity={0.5} />
              <stop offset="100%" stopColor="#38BDF8" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
          <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
          <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
          <Tooltip contentStyle={tooltipStyle} />
          <Area type="monotone" dataKey="sales" stroke="#38BDF8" strokeWidth={2} fill="url(#g1)" />
        </AreaChart>
      </Card>

      <Card title="Orders by month" subtitle="Total orders fulfilled">
        <BarChart data={sales}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
          <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
          <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
          <Tooltip contentStyle={tooltipStyle} />
          <Bar dataKey="orders" fill="#38BDF8" radius={[4, 4, 0, 0]} />
        </BarChart>
      </Card>

      <Card title="Core Web Vitals" subtitle="LCP & INP trend, last 14 days">
        <LineChart data={vitals}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
          <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={12} />
          <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Line type="monotone" dataKey="LCP" stroke="#38BDF8" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="INP" stroke="#94A3B8" strokeWidth={2} dot={false} />
        </LineChart>
      </Card>

      <Card title="Sales by category" subtitle="Share of total revenue">
        <PieChart>
          <Tooltip contentStyle={tooltipStyle} />
          <Pie data={categoryShare} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>
            {categoryShare.map((_, i) => (
              <Cell key={i} fill={palette[i % palette.length]} />
            ))}
          </Pie>
          <Legend wrapperStyle={{ fontSize: 12 }} />
        </PieChart>
      </Card>
    </div>
  );
}