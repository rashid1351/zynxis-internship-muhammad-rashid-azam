export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  rating: number;
  reviews: number;
  image: string;
  description: string;
  specs: { label: string; value: string }[];
  stock: number;
}

const categories = ["Audio", "Laptops", "Cameras", "Wearables", "Displays", "Accessories"] as const;

const names: Record<(typeof categories)[number], string[]> = {
  Audio: ["Aurora Wireless Headphones", "Pulse Studio Monitors", "Echo Buds Pro", "Sonic Boom Speaker", "Halo Noise-Cancel ANC"],
  Laptops: ["Nimbus 14 Pro", "Quantum Book X1", "Vector Studio 16", "Lumen Air 13", "Apex Workstation 17"],
  Cameras: ["Lyra Mirrorless M2", "Optix Action 4K", "Spectra Cinema A1", "Beacon Compact RX"],
  Wearables: ["Pulse Fit Band 5", "Orbit Smartwatch S3", "Atlas GPS Tracker", "Loom Sleep Ring"],
  Displays: ["Vista 27\" 4K", "Glow OLED 32\"", "Lumen Curved 34\"", "Pixel Pro 5K"],
  Accessories: ["Forge Mechanical KB", "Glide Precision Mouse", "Anchor USB-C Hub", "Helix Cable Pack", "Stratus Laptop Stand", "Mantle Desk Mat", "Beam Webcam 1080", "Quill Stylus Pen"],
};

const adjectives = ["Pro", "Ultra", "Max", "Lite", "Plus", "Edge"];

function seededRandom(seed: number) {
  let x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

export const products: Product[] = (() => {
  const out: Product[] = [];
  let i = 1;
  for (const cat of categories) {
    for (const base of names[cat]) {
      const variants = 1 + (i % 2);
      for (let v = 0; v < variants && out.length < 36; v++) {
        const adj = v === 0 ? "" : ` ${adjectives[(i + v) % adjectives.length]}`;
        const r = seededRandom(i);
        const price = Math.round(49 + r * 1950);
        const rating = Math.round((3.5 + seededRandom(i * 2) * 1.5) * 10) / 10;
        const reviews = Math.round(20 + seededRandom(i * 3) * 4800);
        out.push({
          id: `${i}`,
          name: base + adj,
          category: cat,
          price,
          rating,
          reviews,
          image: `https://picsum.photos/seed/perfpro-${i}/600/450.webp`,
          description: `The ${base}${adj} delivers premium ${cat.toLowerCase()} performance with a refined industrial design, engineered for daily reliability and long-term value.`,
          specs: [
            { label: "Warranty", value: "2 years" },
            { label: "Weight", value: `${(0.2 + r * 2.8).toFixed(2)} kg` },
            { label: "Material", value: r > 0.5 ? "Aluminum" : "Polycarbonate" },
            { label: "Color", value: ["Graphite", "Silver", "Midnight"][i % 3] },
          ],
          stock: Math.round(seededRandom(i * 5) * 200),
        });
        i++;
      }
    }
  }
  return out;
})();

export const allCategories = ["All", ...categories] as const;