import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { lazy, Suspense, useMemo } from "react";
import { ArrowLeft, Star } from "lucide-react";
import { Shell } from "@/components/layout/Shell";
import { ProductCard } from "@/components/products/ProductCard";
import { Skeleton } from "@/components/common/Skeleton";
import { products, type Product } from "@/data/products";

// Lazy-load the product gallery (image-heavy, only needed on detail page).
const ProductGallery = lazy(() => import("@/components/products/ProductGallery"));

export const Route = createFileRoute("/products/$id")({
  loader: ({ params }) => {
    const product = products.find((p) => p.id === params.id);
    if (!product) throw notFound();
    return product;
  },
  head: ({ loaderData }) => {
    const p = loaderData;
    if (!p) return { meta: [] };
    return {
      meta: [
        { title: `${p.name} — PerformancePro` },
        { name: "description", content: p.description },
        { property: "og:title", content: p.name },
        { property: "og:description", content: p.description },
        { property: "og:type", content: "product" },
        { property: "og:image", content: p.image },
        { property: "og:url", content: `/products/${p.id}` },
      ],
      links: [{ rel: "canonical", href: `/products/${p.id}` }],
      scripts: [{
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Product",
          name: p.name,
          description: p.description,
          image: p.image,
          category: p.category,
          offers: { "@type": "Offer", price: p.price, priceCurrency: "USD", availability: p.stock > 0 ? "InStock" : "OutOfStock" },
          aggregateRating: { "@type": "AggregateRating", ratingValue: p.rating, reviewCount: p.reviews },
        }),
      }],
    };
  },
  notFoundComponent: () => (
    <Shell>
      <div className="surface-card p-12 text-center">
        <h1 className="text-xl font-semibold">Product not found</h1>
        <Link to="/products" className="mt-4 inline-block text-sm text-primary underline">Back to products</Link>
      </div>
    </Shell>
  ),
  component: ProductDetail,
});

function ProductDetail() {
  const product = Route.useLoaderData() as Product;

  const related = useMemo(
    () => products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4),
    [product],
  );

  return (
    <Shell>
      <Link to="/products" className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> All products
      </Link>

      <article className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
        <Suspense fallback={<Skeleton className="aspect-[4/3] w-full" />}>
          <ProductGallery productId={product.id} productName={product.name} primaryImage={product.image} />
        </Suspense>

        <div>
          <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{product.category}</span>
          <h1 className="mt-1 text-3xl font-bold tracking-tight">{product.name}</h1>
          <div className="mt-3 flex items-center gap-3 text-sm">
            <span className="inline-flex items-center gap-1">
              <Star className="h-4 w-4 fill-primary text-primary" aria-hidden="true" />
              <strong>{product.rating}</strong>
              <span className="text-muted-foreground">({product.reviews} reviews)</span>
            </span>
            <span className="text-muted-foreground">·</span>
            <span className="text-muted-foreground">{product.stock > 0 ? `${product.stock} in stock` : "Out of stock"}</span>
          </div>
          <p className="mt-5 text-3xl font-bold">${product.price}</p>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{product.description}</p>

          <div className="mt-6 flex gap-3">
            <button className="rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-[var(--shadow-glow)]">
              Add to cart
            </button>
            <button className="rounded-md border border-border bg-background px-5 py-2.5 text-sm font-medium hover:bg-accent">
              Save
            </button>
          </div>

          <dl className="surface-card mt-6 grid grid-cols-2 gap-x-6 gap-y-3 p-5 text-sm">
            {product.specs.map((s) => (
              <div key={s.label}>
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">{s.label}</dt>
                <dd className="mt-0.5 font-medium">{s.value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </article>

      {related.length > 0 && (
        <section className="mt-12" aria-labelledby="related">
          <h2 id="related" className="mb-4 text-lg font-semibold">Related products</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </Shell>
  );
}