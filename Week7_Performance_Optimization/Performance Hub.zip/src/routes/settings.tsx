import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Moon, Sun } from "lucide-react";
import { Shell } from "@/components/layout/Shell";
import { useTheme } from "@/context/ThemeContext";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — PerformancePro" },
      { name: "description", content: "Customize theme, notifications, and preferences." },
      { property: "og:title", content: "Settings — PerformancePro" },
      { property: "og:description", content: "Customize theme, notifications, and preferences." },
      { property: "og:url", content: "/settings" },
    ],
    links: [{ rel: "canonical", href: "/settings" }],
  }),
  component: SettingsPage,
});

function Row({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-3 border-b border-border py-5 last:border-0 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h3 className="text-sm font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      <div>{children}</div>
    </div>
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 rounded-full transition-colors ${checked ? "bg-primary" : "bg-muted"}`}
    >
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-background shadow transition-transform ${checked ? "translate-x-5" : "translate-x-0.5"}`} />
    </button>
  );
}

function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const [emails, setEmails] = useState(true);
  const [push, setPush] = useState(false);
  const [marketing, setMarketing] = useState(false);
  const [name, setName] = useState("Alex Patel");

  return (
    <Shell>
      <header className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">Manage appearance, profile, and notifications.</p>
      </header>

      <div className="space-y-6">
        <section className="surface-card p-6" aria-labelledby="appearance">
          <h2 id="appearance" className="mb-2 text-base font-semibold">Appearance</h2>
          <Row title="Theme" description="Choose between light and dark mode. Your choice is saved.">
            <div className="inline-flex rounded-md border border-border p-1">
              <button
                onClick={() => setTheme("light")}
                aria-pressed={theme === "light"}
                className={`inline-flex items-center gap-1.5 rounded px-3 py-1.5 text-sm ${theme === "light" ? "bg-accent text-accent-foreground" : "text-muted-foreground"}`}
              >
                <Sun className="h-4 w-4" aria-hidden="true" /> Light
              </button>
              <button
                onClick={() => setTheme("dark")}
                aria-pressed={theme === "dark"}
                className={`inline-flex items-center gap-1.5 rounded px-3 py-1.5 text-sm ${theme === "dark" ? "bg-accent text-accent-foreground" : "text-muted-foreground"}`}
              >
                <Moon className="h-4 w-4" aria-hidden="true" /> Dark
              </button>
            </div>
          </Row>
        </section>

        <section className="surface-card p-6" aria-labelledby="profile">
          <h2 id="profile" className="mb-2 text-base font-semibold">Profile</h2>
          <Row title="Display name" description="Shown across the dashboard.">
            <label className="block">
              <span className="sr-only">Display name</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-10 w-64 max-w-full rounded-md border border-input bg-background px-3 text-sm focus:border-ring focus:outline-none"
              />
            </label>
          </Row>
        </section>

        <section className="surface-card p-6" aria-labelledby="notifications">
          <h2 id="notifications" className="mb-2 text-base font-semibold">Notifications</h2>
          <Row title="Email notifications" description="Performance regression alerts and weekly reports.">
            <Toggle checked={emails} onChange={setEmails} label="Email notifications" />
          </Row>
          <Row title="Push notifications" description="Browser alerts for real-time incidents.">
            <Toggle checked={push} onChange={setPush} label="Push notifications" />
          </Row>
          <Row title="Product updates" description="Occasional updates about new features.">
            <Toggle checked={marketing} onChange={setMarketing} label="Product updates" />
          </Row>
        </section>
      </div>
    </Shell>
  );
}