import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useDeferredValue, useEffect, useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Shell } from "@/components/layout/Shell";
import { ProductCard } from "@/components/products/ProductCard";
import { ProductSkeleton } from "@/components/common/Skeleton";
import { allCategories, products, type Product } from "@/data/products";
import { useDebounce } from "@/hooks/useDebounce";

type SortKey = "name" | "price-asc" | "price-desc" | "rating";

const PAGE_SIZE = 12;

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "Products — PerformancePro" },
      { name: "description", content: "Browse 30+ optimized product cards with search, filtering, sorting and pagination." },
      { property: "og:title", content: "Products — PerformancePro" },
      { property: "og:description", content: "Browse 30+ optimized product cards with search, filtering, sorting and pagination." },
      { property: "og:url", content: "/products" },
    ],
    links: [{ rel: "canonical", href: "/products" }],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("All");
  const [sort, setSort] = useState<SortKey>("name");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const debounced = useDebounce(query, 500);
  const deferred = useDeferredValue(debounced);

  useEffect(() => {
    const t = window.setTimeout(() => setLoading(false), 350);
    return () => window.clearTimeout(t);
  }, []);

  useEffect(() => setPage(1), [deferred, category, sort]);

  const filtered = useMemo<Product[]>(() => {
    const q = deferred.trim().toLowerCase();
    const list = products.filter((p) => {
      if (category !== "All" && p.category !== category) return false;
      if (q && !p.name.toLowerCase().includes(q)) return false;
      return true;
    });
    switch (sort) {
      case "price-asc": list.sort((a, b) => a.price - b.price); break;
      case "price-desc": list.sort((a, b) => b.price - a.price); break;
      case "rating": list.sort((a, b) => b.rating - a.rating); break;
      default: list.sort((a, b) => a.name.localeCompare(b.name));
    }
    return list;
  }, [deferred, category, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = useMemo(
    () => filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    [filtered, page],
  );

  const onQuery = useCallback((e: React.ChangeEvent<HTMLInputElement>) => setQuery(e.target.value), []);

  return (
    <Shell>
      <header className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Products</h1>
        <p className="text-sm text-muted-foreground">
          {filtered.length} of {products.length} products
        </p>
      </header>

      <div className="surface-card mb-6 grid gap-3 p-4 sm:grid-cols-[1fr_auto_auto]">
        <label className="relative block">
          <span className="sr-only">Search products</span>
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <input
            type="search"
            value={query}
            onChange={onQuery}
            placeholder="Search products…"
            className="h-10 w-full rounded-md border border-input bg-background pl-9 pr-3 text-sm placeholder:text-muted-foreground focus:border-ring focus:outline-none"
          />
        </label>
        <label className="block">
          <span className="sr-only">Filter by category</span>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="h-10 rounded-md border border-input bg-background px-3 text-sm focus:border-ring focus:outline-none"
          >
            {allCategories.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="sr-only">Sort by</span>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="h-10 rounded-md border border-input bg-background px-3 text-sm focus:border-ring focus:outline-none"
          >
            <option value="name">Name (A–Z)</option>
            <option value="price-asc">Price: low → high</option>
            <option value="price-desc">Price: high → low</option>
            <option value="rating">Rating</option>
          </select>
        </label>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => <ProductSkeleton key={i} />)}
        </div>
      ) : pageItems.length === 0 ? (
        <div className="surface-card p-12 text-center">
          <h2 className="text-base font-semibold">No products match your filters</h2>
          <p className="mt-1 text-sm text-muted-foreground">Try clearing the search or picking another category.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {pageItems.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}

      {totalPages > 1 && (
        <nav aria-label="Pagination" className="mt-8 flex items-center justify-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="rounded-md border border-border px-3 py-1.5 text-sm disabled:opacity-40"
          >
            Previous
          </button>
          <span className="text-sm text-muted-foreground" aria-live="polite">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="rounded-md border border-border px-3 py-1.5 text-sm disabled:opacity-40"
          >
            Next
          </button>
        </nav>
      )}

      <p className="mt-10 text-center text-xs text-muted-foreground">
        Need to ship a 10,000-row table? <Link to="/analytics" className="text-primary underline">See the analytics page</Link> for virtualization & lazy charts.
      </p>
    </Shell>
  );
}