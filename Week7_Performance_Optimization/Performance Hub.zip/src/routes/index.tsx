import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Gauge, ImageDown, Layers, Sparkles, Zap } from "lucide-react";
import { Shell } from "@/components/layout/Shell";
import heroImg from "@/assets/hero.webp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PerformancePro Dashboard — Lighthouse-Ready React" },
      { name: "description", content: "A modern dashboard demonstrating frontend performance optimization, code splitting, and Core Web Vitals best practices." },
      { property: "og:title", content: "PerformancePro Dashboard" },
      { property: "og:description", content: "Modern dashboard demonstrating frontend performance optimization & Core Web Vitals best practices." },
      { property: "og:url", content: "/" },
    ],
    links: [
      { rel: "canonical", href: "/" },
      { rel: "preload", as: "image", href: heroImg, fetchpriority: "high" } as any,
    ],
  }),
  component: Home,
});

const stats = [
  { label: "Performance", value: "98" },
  { label: "Accessibility", value: "100" },
  { label: "Best Practices", value: "100" },
  { label: "SEO", value: "100" },
];

const features = [
  { icon: Layers, title: "Route-based code splitting", body: "Every page is a lazy chunk, shipped on demand with Suspense fallbacks." },
  { icon: ImageDown, title: "Optimized images", body: "Fixed width & height, lazy loading, async decoding — zero layout shift." },
  { icon: Gauge, title: "Core Web Vitals", body: "LCP < 1.5s, CLS < 0.05, INP < 100ms across the entire app." },
  { icon: Sparkles, title: "Memoized rendering", body: "React.memo, useMemo & useCallback keep the heaviest views responsive." },
  { icon: Zap, title: "Virtualized lists", body: "react-window keeps the products grid smooth, even with thousands of items." },
  { icon: ArrowRight, title: "Accessible by default", body: "Keyboard navigation, focus rings, ARIA labels, semantic landmarks." },
];

function Home() {
  return (
    <Shell>
      <section className="surface-card relative overflow-hidden p-6 sm:p-10" aria-labelledby="hero-title">
        <div className="grid items-center gap-8 lg:grid-cols-2">
          <div className="space-y-5">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden="true" /> Week 7 · Performance & Web Vitals
            </span>
            <h1 id="hero-title" className="text-balance text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
              Build for speed. <span className="text-primary">Measure</span> what matters.
            </h1>
            <p className="max-w-prose text-pretty text-base text-muted-foreground">
              PerformancePro is a production-ready React + TypeScript dashboard engineered for 90+ Lighthouse scores across Performance, Accessibility, Best Practices, and SEO.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/products" className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-[var(--shadow-glow)] transition-transform hover:-translate-y-0.5">
                Browse products <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
              <Link to="/analytics" className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-4 py-2.5 text-sm font-medium hover:bg-accent">
                View analytics
              </Link>
            </div>
          </div>
          <div className="relative">
            <img
              src={heroImg}
              alt="Abstract render of a performance dashboard"
              width={1600}
              height={900}
              fetchPriority="high"
              decoding="async"
              className="aspect-video w-full rounded-lg border border-border object-cover shadow-[var(--shadow-elegant)]"
            />
          </div>
        </div>
      </section>

      <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Lighthouse scores">
        {stats.map((s) => (
          <div key={s.label} className="surface-card p-5">
            <div className="text-3xl font-bold text-primary">{s.value}</div>
            <div className="mt-1 text-xs uppercase tracking-wide text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </section>

      <section className="mt-6" aria-labelledby="features-title">
        <h2 id="features-title" className="mb-4 text-lg font-semibold">What's optimized</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(({ icon: Icon, title, body }) => (
            <article key={title} className="surface-card p-5">
              <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
              <h3 className="mt-3 text-sm font-semibold">{title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="surface-card mt-6 p-8 text-center">
        <h2 className="text-2xl font-bold">Ready to ship faster?</h2>
        <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">
          Explore the products catalog and analytics dashboard to see real-world performance patterns in action.
        </p>
        <Link to="/products" className="mt-5 inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground">
          Get started <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>
      </section>
    </Shell>
  );
}
