import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { ArrowDownRight, ArrowUpRight, DollarSign, ShoppingBag, TrendingUp, Users } from "lucide-react";
import { Shell } from "@/components/layout/Shell";
import { ChartSkeleton } from "@/components/common/Skeleton";

// Lazy-load the heavy recharts bundle.
const Charts = lazy(() => import("@/components/analytics/Charts"));

export const Route = createFileRoute("/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — PerformancePro" },
      { name: "description", content: "Lazy-loaded charts: sales trends, orders, Core Web Vitals, and category share." },
      { property: "og:title", content: "Analytics — PerformancePro" },
      { property: "og:description", content: "Lazy-loaded charts: sales trends, orders, Core Web Vitals, and category share." },
      { property: "og:url", content: "/analytics" },
    ],
    links: [{ rel: "canonical", href: "/analytics" }],
  }),
  component: AnalyticsPage,
});

const kpis = [
  { label: "Revenue", value: "$148,920", delta: "+12.4%", up: true, icon: DollarSign },
  { label: "Orders", value: "3,214", delta: "+8.1%", up: true, icon: ShoppingBag },
  { label: "Visitors", value: "82.6k", delta: "+3.2%", up: true, icon: Users },
  { label: "Bounce rate", value: "34.1%", delta: "−2.4%", up: false, icon: TrendingUp },
];

function AnalyticsPage() {
  return (
    <Shell>
      <header className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Analytics</h1>
        <p className="text-sm text-muted-foreground">Real-time KPIs and lazy-loaded charts.</p>
      </header>

      <section className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Key metrics">
        {kpis.map(({ label, value, delta, up, icon: Icon }) => (
          <article key={label} className="surface-card p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wide text-muted-foreground">{label}</span>
              <Icon className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            </div>
            <div className="mt-2 text-2xl font-bold">{value}</div>
            <div className={`mt-1 inline-flex items-center gap-1 text-xs font-medium ${up ? "text-primary" : "text-destructive"}`}>
              {up ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
              {delta}
            </div>
          </article>
        ))}
      </section>

      <Suspense fallback={<div className="grid gap-4 lg:grid-cols-2"><ChartSkeleton /><ChartSkeleton /><ChartSkeleton /><ChartSkeleton /></div>}>
        <Charts />
      </Suspense>
    </Shell>
  );
}