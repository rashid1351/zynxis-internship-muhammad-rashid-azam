# PerformancePro Dashboard

A production-ready React + TypeScript dashboard built on **TanStack Start**
(Vite 7, React 19) and **Tailwind CSS v4**. Engineered for **90+ Lighthouse
scores** across Performance, Accessibility, Best Practices and SEO — built as
the Week 7 *Performance & Web Vitals* internship deliverable.

## Features

- **Home** — hero, Lighthouse scorecard, feature highlights
- **Products** — 36 generic tech gadgets, debounced search, category filter,
  sort, pagination
- **Product Details** — dynamic route, lazy-loaded image gallery, specs,
  related products, JSON-LD `Product` schema
- **Analytics** — KPI cards plus lazy-loaded Recharts (Area, Bar, Line, Pie)
- **Settings** — dark / light theme toggle with system preference + persistence

## Tech stack

- React 19 + TypeScript (strict mode)
- TanStack Start / Router — file-based routing, SSR, automatic code splitting
- Vite 7
- Tailwind CSS v4 (CSS-first design tokens in `src/styles.css`)
- Recharts 3 (lazy-loaded)
- lucide-react icons

## Build & run

```bash
bun install
bun run dev          # local dev server
bun run build        # production build
bun run start        # preview production build
```

## Project structure

```
src/
├── assets/                # hero image, logo
├── components/
│   ├── analytics/Charts   # lazy-loaded Recharts bundle
│   ├── common/Skeleton    # Product / Chart / Dashboard skeletons
│   ├── layout/Shell       # sidebar + topbar shell
│   ├── products/          # ProductCard (memo), ProductGallery (lazy)
│   └── ui/                # shadcn primitives
├── context/ThemeContext   # dark / light theme provider
├── data/products          # generic tech-gadget catalog
├── hooks/useDebounce      # 500ms debounce hook
├── routes/                # file-based routes (auto code-split)
│   ├── index.tsx          # /
│   ├── products.tsx       # /products
│   ├── products.$id.tsx   # /products/$id
│   ├── analytics.tsx      # /analytics
│   ├── settings.tsx       # /settings
│   └── sitemap[.]xml.ts   # /sitemap.xml (server route)
└── styles.css             # Mono Slate design system tokens
```

## Performance Optimization

This project applies every optimization required for Week 7. See
[`PERFORMANCE.md`](./PERFORMANCE.md) for full detail.

### Lazy Loading

- `Charts` (Recharts ~100 KB) — `React.lazy()` + `<Suspense>` on `/analytics`
- `ProductGallery` — `React.lazy()` + `<Suspense>` on `/products/$id`
- All product images use `loading="lazy"` + `decoding="async"`
- LCP hero image is preloaded with `<link rel="preload" fetchpriority="high">`

### Code Splitting

- TanStack Router's Vite plugin auto-splits every route component into its own
  chunk (`autoCodeSplitting: true`)
- Heavy dependencies (Recharts, gallery) are kept out of the entry bundle
- Tree-shakable `lucide-react` icon imports; no lodash / moment

### Memoization

- `ProductCard` wrapped in `React.memo`
- `useMemo` for product filtering, sorting, pagination slicing, related
  products, gallery URLs, and chart datasets
- `useCallback` for input change handlers
- `useDeferredValue` for non-urgent rendering of filtered lists

### Web Vitals Improvements

| Metric | Target | How |
| --- | --- | --- |
| **LCP** | < 2.5 s | Preloaded hero with `fetchpriority="high"`, SSR HTML |
| **CLS** | < 0.1   | Explicit `width`/`height` on every `<img>`, skeleton placeholders |
| **INP** | Excellent | Debounced search (500 ms), `useDeferredValue`, memoization |
| **FCP** | < 1.8 s | Tailwind v4 critical CSS, SSR, no render-blocking JS |
| **TBT** | Low | Route + component splitting, no heavy work on main thread |

### Lighthouse Optimization

- **Performance** — code splitting, lazy loading, image dimensions,
  preloaded LCP, memoization, debounced input
- **Accessibility** — semantic landmarks (`<main>`, `<nav>`, `<header>`,
  `<article>`, `<section>`), `aria-label` on icon-only buttons,
  `aria-current="page"`, `aria-live="polite"` on pagination, focus-visible
  outlines, skip-to-content link, WCAG AA contrast via design tokens
- **Best Practices** — HTTPS-only assets, no `console.error`, modern
  TypeScript, error boundaries, no deprecated APIs
- **SEO** — per-route `<title>` / `description` / Open Graph / Twitter /
  canonical, JSON-LD (`WebSite`, `Product`), dynamic `/sitemap.xml`,
  `public/robots.txt`, mobile viewport, semantic HTML

### Bundle Optimization

- Dynamic imports for non-critical UI (charts, gallery)
- ES modules + Vite tree shaking
- Per-route chunks via TanStack Router auto-splitting
- No unused dependencies; icons imported individually from `lucide-react`

## Lighthouse readiness checklist

- [x] Route-based code splitting
- [x] Component lazy loading (charts, gallery)
- [x] `React.memo`, `useMemo`, `useCallback`
- [x] 500 ms debounced search
- [x] Lazy-loaded images with fixed dimensions
- [x] Product / Chart / Dashboard skeletons
- [x] LCP preload + `fetchpriority`
- [x] ARIA labels, keyboard navigation, focus rings
- [x] Meta tags, Open Graph, Twitter, canonical, JSON-LD
- [x] `robots.txt` + dynamic `sitemap.xml`
- [x] Product Details page reachable from every product card

## License

MIT