# PerformancePro Dashboard — Performance Notes

Production-ready React + TypeScript dashboard built on TanStack Start (Vite 7,
React 19). Engineered for 90+ Lighthouse scores across Performance,
Accessibility, Best Practices and SEO.

## Stack

- React 19 + TypeScript (strict)
- TanStack Start / Router (SSR, file-based routing, automatic code splitting)
- Vite 7
- Tailwind CSS v4 (CSS-first design tokens in `src/styles.css`)
- Recharts 3 (lazy-loaded)
- Framer Motion (available for animations)
- React Window (available for virtualization of large lists)
- lucide-react icons

> Note: TanStack Router replaces `react-router-dom`. TanStack's per-route
> `head()` replaces `react-helmet-async`. Both give the same outcome with
> first-class SSR support.

## Pages

| Route | File |
| --- | --- |
| `/` Home — hero, stats, features, CTA | `src/routes/index.tsx` |
| `/products` Catalog — search / filter / sort / pagination | `src/routes/products.tsx` |
| `/products/$id` Product detail — gallery, specs, related | `src/routes/products.$id.tsx` |
| `/analytics` KPIs + lazy-loaded charts | `src/routes/analytics.tsx` |
| `/settings` Theme + preferences | `src/routes/settings.tsx` |
| `/sitemap.xml` Dynamic sitemap | `src/routes/sitemap[.]xml.ts` |

## Performance Optimizations Applied

1. **Route-based code splitting** — TanStack Router's Vite plugin splits every
   route component into its own chunk automatically (`autoCodeSplitting`).
2. **Component lazy loading** — `Charts` (recharts bundle, ~100KB) loaded via
   `lazy()` + `<Suspense fallback={<ChartSkeleton />}>` on `/analytics`.
3. **Image optimization** — every `<img>` has explicit `width` / `height`
   (zero CLS), `loading="lazy"` and `decoding="async"`. Hero image uses
   `fetchPriority="high"` and is preloaded via `<link rel="preload">` in
   `__root.tsx`.
4. **Memoization** — `React.memo` on `ProductCard`, `useMemo` on filtering /
   sorting / pagination / related products / chart datasets, `useCallback` on
   event handlers.
5. **Debounced search** — 500ms debounce via `useDebounce` + React's
   `useDeferredValue` for non-urgent rendering.
6. **Skeleton loaders** — `ProductSkeleton`, `ChartSkeleton`,
   `DashboardSkeleton` with shimmer animation in `src/components/common/Skeleton.tsx`.
7. **Bundle size** — tree-shakable lucide imports, no moment.js / lodash,
   recharts split out of the main bundle.
8. **Virtualization-ready** — `react-window` installed and ready for any list
   that grows beyond a few hundred rows.
9. **Preload critical resources** — hero image preloaded; stylesheet linked at
   the root.
10. **Caching** — sitemap response sets `Cache-Control: public, max-age=3600`;
    static assets cached by Vite's hashed filenames.

## Core Web Vitals

- **LCP** — preloaded hero image with `fetchpriority=high`, SSR'd HTML, no
  client-only render blocking. Target < 2.5s.
- **CLS** — every image has explicit dimensions, skeletons reserve layout
  space, no layout-shifting fonts. Target < 0.1.
- **INP / FID** — memoized expensive computations, debounced input, deferred
  rendering of filtered lists. Target excellent.
- **FCP** — automatic critical CSS via Tailwind v4 + SSR. Target < 1.8s.

## SEO

- Per-route `<title>`, `description`, `og:*`, `twitter:*`, `canonical`
- JSON-LD: `WebSite` at root, `Product` on detail pages
- Dynamic `/sitemap.xml` server route with every static + dynamic URL
- `public/robots.txt` allowing all crawlers
- Semantic landmarks: `<main>`, `<header>`, `<nav>`, `<aside>`, `<article>`,
  `<section>` with `aria-labelledby`

## Accessibility

- Skip-to-content link
- Keyboard-reachable nav, focus-visible outline tokens
- `aria-label` on all icon-only buttons
- `aria-current="page"` on active nav links
- `role="switch"` + `aria-checked` on toggles
- `aria-live="polite"` on pagination status
- Alt text on every meaningful image; decorative thumbnails use `alt=""`
- WCAG AA contrast via semantic design tokens

## Build

```bash
bun install
bun run dev        # local dev
bun run build      # production build
```

## Project Structure

```
src/
├── assets/                # hero image
├── components/
│   ├── common/            # Skeleton variants
│   ├── layout/            # Shell (sidebar + topbar)
│   ├── products/          # ProductCard (memoized)
│   ├── analytics/         # Charts (lazy)
│   └── ui/                # shadcn primitives
├── context/               # ThemeProvider (dark/light + persistence)
├── data/                  # 30+ generated products
├── hooks/                 # useDebounce, useTheme
├── lib/                   # utils, error reporting
├── routes/                # file-based routes (auto code-split)
└── styles.css             # Mono Slate design system tokens
```