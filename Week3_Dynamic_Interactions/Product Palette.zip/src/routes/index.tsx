import { createFileRoute } from "@tanstack/react-router";
import ProductCatalog from "../pages/ProductCatalog";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Interactive Product Catalog" },
      { name: "description", content: "Searchable, filterable, sortable product catalog built with React hooks." },
      { property: "og:title", content: "Interactive Product Catalog" },
      { property: "og:description", content: "Search, filter, sort and explore products with a beautiful React UI." },
    ],
  }),
  component: ProductCatalog,
});
