import { Star } from "lucide-react";
import FavoriteButton from "./FavoriteButton";

function Stars({ rating }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={14}
          className={i <= Math.round(rating) ? "text-yellow-400" : "text-muted"}
          fill={i <= Math.round(rating) ? "currentColor" : "none"}
        />
      ))}
      <span className="ml-1 text-xs font-medium text-muted-foreground">{rating.toFixed(1)}</span>
    </div>
  );
}

export default function ProductCard({ product, isFavorite, onToggleFavorite, onView }) {
  return (
    <div className="product-card group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <span className="absolute left-3 top-3 rounded-full bg-primary/90 px-3 py-1 text-xs font-semibold text-primary-foreground backdrop-blur">
          {product.category}
        </span>
        <div className="absolute right-3 top-3">
          <FavoriteButton active={isFavorite} onToggle={onToggleFavorite} size="sm" />
        </div>
      </div>
      <div className="flex flex-1 flex-col p-4">
        <h3 className="truncate text-base font-semibold text-foreground">{product.name}</h3>
        <div className="mt-1"><Stars rating={product.rating} /></div>
        <div className="mt-3 flex items-end justify-between">
          <span className="text-xl font-bold text-foreground">₹{product.price.toLocaleString()}</span>
        </div>
        <button
          onClick={() => onView(product)}
          className="mt-4 h-10 w-full rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition hover:opacity-90 active:scale-[0.98]"
        >
          View Details
        </button>
      </div>
    </div>
  );
}
