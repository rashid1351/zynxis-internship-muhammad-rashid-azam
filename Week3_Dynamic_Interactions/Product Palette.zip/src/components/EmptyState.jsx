import { PackageSearch } from "lucide-react";

export default function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="grid h-24 w-24 place-items-center rounded-full bg-muted">
        <PackageSearch className="h-12 w-12 text-muted-foreground" />
      </div>
      <h3 className="mt-6 text-2xl font-bold text-foreground">No Products Found</h3>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">
        Try adjusting your search or filter to discover more products.
      </p>
    </div>
  );
}
