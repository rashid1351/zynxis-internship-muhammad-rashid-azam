import { useEffect } from "react";
import { Star, X } from "lucide-react";
import FavoriteButton from "./FavoriteButton";

export default function ProductModal({ product, isFavorite, onToggleFavorite, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  if (!product) return null;

  return (
    <div
      className="modal-backdrop fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      onClick={onClose}
    >
      <div
        className="modal-panel relative max-h-[90vh] w-full max-w-3xl overflow-hidden overflow-y-auto rounded-3xl border border-border bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 grid h-10 w-10 place-items-center rounded-full bg-card/90 text-foreground shadow-md backdrop-blur transition hover:scale-110"
          aria-label="Close"
        >
          <X size={18} />
        </button>
        <div className="grid md:grid-cols-2">
          <div className="aspect-square bg-muted md:aspect-auto">
            <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
          </div>
          <div className="flex flex-col gap-4 p-6 md:p-8">
            <span className="w-fit rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
              {product.category}
            </span>
            <h2 className="text-2xl font-bold text-foreground md:text-3xl">{product.name}</h2>
            <div className="flex items-center gap-1">
              {[1,2,3,4,5].map((i) => (
                <Star key={i} size={18} className={i <= Math.round(product.rating) ? "text-yellow-400" : "text-muted"} fill={i <= Math.round(product.rating) ? "currentColor" : "none"} />
              ))}
              <span className="ml-2 text-sm font-medium text-muted-foreground">{product.rating.toFixed(1)}</span>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">{product.description}</p>
            <div className="mt-2 text-3xl font-bold text-foreground">₹{product.price.toLocaleString()}</div>
            <div className="mt-auto flex items-center gap-3 pt-4">
              <button
                onClick={onClose}
                className="h-12 flex-1 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition hover:opacity-90"
              >
                Continue Shopping
              </button>
              <FavoriteButton active={isFavorite} onToggle={onToggleFavorite} size="lg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
