export default function Loader() {
  return (
    <div className="flex flex-col items-center justify-center py-20">
      <div className="h-14 w-14 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
      <p className="mt-4 text-sm font-medium text-muted-foreground">Loading Products...</p>
      <div className="catalog-grid mt-10 w-full">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="rounded-2xl border border-border bg-card p-4">
            <div className="skeleton h-44 w-full rounded-xl" />
            <div className="skeleton mt-4 h-4 w-3/4 rounded" />
            <div className="skeleton mt-2 h-4 w-1/2 rounded" />
          </div>
        ))}
      </div>
    </div>
  );
}
