import { Heart } from "lucide-react";

export default function FavoriteButton({ active, onToggle, size = "md" }) {
  const sizes = { sm: "h-8 w-8", md: "h-10 w-10", lg: "h-12 w-12" };
  const icon = { sm: 16, md: 18, lg: 22 };
  return (
    <button
      type="button"
      onClick={(e) => { e.stopPropagation(); onToggle(); }}
      aria-label={active ? "Remove from favorites" : "Add to favorites"}
      className={`${sizes[size]} grid place-items-center rounded-full border border-border bg-card/90 backdrop-blur transition hover:scale-110 ${active ? "text-red-500" : "text-muted-foreground"}`}
    >
      <Heart size={icon[size]} fill={active ? "currentColor" : "none"} />
    </button>
  );
}
