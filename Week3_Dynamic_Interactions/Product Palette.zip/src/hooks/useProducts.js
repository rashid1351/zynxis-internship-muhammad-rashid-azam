import { useEffect, useMemo, useState } from "react";
import { products as productData } from "../data/products";

export function useProducts() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All Categories");
  const [sort, setSort] = useState("rating-desc");

  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => {
      setProducts(productData);
      setLoading(false);
    }, 1200);
    return () => clearTimeout(t);
  }, []);

  const filteredProducts = useMemo(() => {
    let list = products;
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q));
    }
    if (category !== "All Categories") {
      list = list.filter((p) => p.category === category);
    }
    const sorted = [...list];
    switch (sort) {
      case "price-asc": sorted.sort((a, b) => a.price - b.price); break;
      case "price-desc": sorted.sort((a, b) => b.price - a.price); break;
      case "rating-desc": sorted.sort((a, b) => b.rating - a.rating); break;
      case "name-asc": sorted.sort((a, b) => a.name.localeCompare(b.name)); break;
      case "name-desc": sorted.sort((a, b) => b.name.localeCompare(a.name)); break;
      default: break;
    }
    return sorted;
  }, [products, search, category, sort]);

  return { filteredProducts, loading, search, setSearch, category, setCategory, sort, setSort };
}
