import { useEffect, useState } from "react";
import { Heart, Moon, Sun, ShoppingBag } from "lucide-react";
import { useProducts } from "../hooks/useProducts";
import SearchBar from "../components/SearchBar";
import CategoryFilter from "../components/CategoryFilter";
import SortDropdown from "../components/SortDropdown";
import ProductCard from "../components/ProductCard";
import ProductModal from "../components/ProductModal";
import Loader from "../components/Loader";
import EmptyState from "../components/EmptyState";
import "../styles/catalog.css";

export default function ProductCatalog() {
  const { filteredProducts, loading, search, setSearch, category, setCategory, sort, setSort } = useProducts();
  const [favorites, setFavorites] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("catalog-theme");
    const prefersDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches;
    const useDark = saved ? saved === "dark" : !!prefersDark;
    setDarkMode(useDark);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
    localStorage.setItem("catalog-theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  useEffect(() => {
    const saved = localStorage.getItem("catalog-favorites");
    if (saved) {
      try { setFavorites(JSON.parse(saved)); } catch {}
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("catalog-favorites", JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (id) =>
    setFavorites((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
      <header className="glass sticky top-0 z-40 border-b border-border">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-md">
              <ShoppingBag size={22} />
            </div>
            <div className="min-w-0">
              <h1 className="truncate text-lg font-bold sm:text-xl">Interactive Product Catalog</h1>
              <p className="hidden text-xs text-muted-foreground sm:block">Search • Filter • Sort • Explore</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <div className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-2 text-sm font-medium shadow-sm">
              <Heart size={16} className="text-red-500" fill="currentColor" />
              <span className="hidden sm:inline">Favorites</span>
              <span>({favorites.length})</span>
            </div>
            <button
              onClick={() => setDarkMode((d) => !d)}
              className="grid h-10 w-10 place-items-center rounded-full border border-border bg-card text-foreground shadow-sm transition hover:scale-105"
              aria-label="Toggle theme"
            >
              {darkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <section className="mb-8">
          <h2 className="text-3xl font-black tracking-tight sm:text-4xl">Discover Products You'll Love</h2>
          <p className="mt-2 text-sm text-muted-foreground sm:text-base">
            Browse {filteredProducts.length} curated items across multiple categories.
          </p>
        </section>

        <section className="mb-8 grid gap-3 md:grid-cols-[1fr_auto_auto]">
          <SearchBar value={search} onChange={setSearch} />
          <CategoryFilter value={category} onChange={setCategory} />
          <SortDropdown value={sort} onChange={setSort} />
        </section>

        {loading ? (
          <Loader />
        ) : filteredProducts.length === 0 ? (
          <EmptyState />
        ) : (
          <section className="catalog-grid">
            {filteredProducts.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                isFavorite={favorites.includes(p.id)}
                onToggleFavorite={() => toggleFavorite(p.id)}
                onView={setSelectedProduct}
              />
            ))}
          </section>
        )}
      </main>

      <footer className="mt-16 border-t border-border py-8 text-center text-xs text-muted-foreground">
        Built with React • useState • useEffect • useMemo
      </footer>

      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          isFavorite={favorites.includes(selectedProduct.id)}
          onToggleFavorite={() => toggleFavorite(selectedProduct.id)}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}
