# Interactive Product Catalog

A searchable, filterable, sortable product catalog built with React hooks.

## Features
- Search Products (real-time, case-insensitive)
- Category Filtering
- Sorting (price, rating, name)
- Favorites with localStorage persistence
- Product Details Modal
- Dark Mode with persistence
- Loading & Empty States
- Fully Responsive (1 / 2 / 4 columns)

## Tech Stack
- React 19
- JavaScript (JSX)
- Vite
- Tailwind CSS + CSS Modules

## Hooks Used
- `useState` — products, search, category, sort, loading, favorites, selectedProduct, darkMode
- `useEffect` — simulated API loading, theme persistence, favorites persistence
- `useMemo` — optimized filter + sort pipeline (in `hooks/useProducts.js`)

## Installation

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Folder Structure

```
src/
├── components/      # ProductCard, SearchBar, CategoryFilter, SortDropdown,
│                    # ProductModal, FavoriteButton, Loader, EmptyState
├── data/products.js
├── hooks/useProducts.js
├── pages/ProductCatalog.jsx
├── styles/catalog.css
└── routes/index.tsx (mounts ProductCatalog)
```
