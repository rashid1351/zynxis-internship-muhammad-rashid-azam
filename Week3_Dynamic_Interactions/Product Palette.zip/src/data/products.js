export const products = [
  { id: 1, name: "Wireless Headphones", category: "Electronics", price: 4999, rating: 4.5, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80", description: "Premium wireless headphones with active noise cancellation and 30-hour battery life." },
  { id: 2, name: "Wireless Mouse", category: "Electronics", price: 899, rating: 4.3, image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600&q=80", description: "Ergonomic wireless mouse with silent clicks and precision tracking." },
  { id: 3, name: "Wireless Speaker", category: "Electronics", price: 2499, rating: 4.6, image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=600&q=80", description: "Portable Bluetooth speaker with deep bass and waterproof design." },
  { id: 4, name: "Smart Watch", category: "Electronics", price: 7999, rating: 4.7, image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=600&q=80", description: "Fitness tracking smart watch with heart-rate monitor and AMOLED display." },
  { id: 5, name: "Laptop Stand", category: "Electronics", price: 1499, rating: 4.4, image: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=600&q=80", description: "Aluminum laptop stand with adjustable height for better ergonomics." },
  { id: 6, name: "Denim Jacket", category: "Fashion", price: 2299, rating: 4.2, image: "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=600&q=80", description: "Classic blue denim jacket made from organic cotton." },
  { id: 7, name: "Running Shoes", category: "Fashion", price: 3499, rating: 4.6, image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80", description: "Lightweight running shoes with responsive cushioning." },
  { id: 8, name: "Leather Wallet", category: "Accessories", price: 1299, rating: 4.5, image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=600&q=80", description: "Handcrafted genuine leather wallet with RFID protection." },
  { id: 9, name: "Sunglasses", category: "Accessories", price: 1799, rating: 4.3, image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=600&q=80", description: "Polarized UV400 sunglasses with lightweight metal frame." },
  { id: 10, name: "Backpack", category: "Accessories", price: 2199, rating: 4.7, image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&q=80", description: "Water-resistant backpack with laptop compartment and USB port." },
  { id: 11, name: "Atomic Habits", category: "Books", price: 499, rating: 4.8, image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&q=80", description: "Best-selling book on building good habits and breaking bad ones." },
  { id: 12, name: "Deep Work", category: "Books", price: 549, rating: 4.7, image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600&q=80", description: "Rules for focused success in a distracted world." },
  { id: 13, name: "The Pragmatic Programmer", category: "Books", price: 899, rating: 4.9, image: "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=600&q=80", description: "Timeless classic for software engineers — practical advice for your craft." },
  { id: 14, name: "Yoga Mat", category: "Sports", price: 1199, rating: 4.4, image: "https://images.unsplash.com/photo-1592432678016-e910b452f9a2?w=600&q=80", description: "Non-slip eco-friendly yoga mat with carrying strap." },
  { id: 15, name: "Dumbbell Set", category: "Sports", price: 3299, rating: 4.5, image: "https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?w=600&q=80", description: "Adjustable rubber-coated dumbbell set for home workouts." },
  { id: 16, name: "Football", category: "Sports", price: 799, rating: 4.3, image: "https://images.unsplash.com/photo-1614632537190-23e4146777db?w=600&q=80", description: "Match-quality football with durable synthetic leather." },
  { id: 17, name: "Coffee Maker", category: "Home", price: 4599, rating: 4.6, image: "https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=600&q=80", description: "Programmable drip coffee maker with thermal carafe." },
  { id: 18, name: "Scented Candle", category: "Home", price: 599, rating: 4.4, image: "https://images.unsplash.com/photo-1602874801007-aa48b8f8c8c2?w=600&q=80", description: "Hand-poured soy wax candle with lavender essential oils." },
  { id: 19, name: "Throw Pillow", category: "Home", price: 799, rating: 4.2, image: "https://images.unsplash.com/photo-1592078615290-033ee584e267?w=600&q=80", description: "Soft velvet throw pillow to elevate any living space." },
  { id: 20, name: "Desk Lamp", category: "Home", price: 1899, rating: 4.5, image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=600&q=80", description: "LED desk lamp with adjustable brightness and color temperature." },
  { id: 21, name: "Mechanical Keyboard", category: "Electronics", price: 5499, rating: 4.8, image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600&q=80", description: "RGB mechanical keyboard with hot-swappable switches." },
  { id: 22, name: "Wrist Watch", category: "Accessories", price: 3999, rating: 4.6, image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=600&q=80", description: "Minimalist analog wrist watch with stainless steel band." },
];

export const categories = ["All Categories", "Electronics", "Fashion", "Books", "Sports", "Home", "Accessories"];

export const sortOptions = [
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating-desc", label: "Rating: High to Low" },
  { value: "name-asc", label: "Name: A-Z" },
  { value: "name-desc", label: "Name: Z-A" },
];
