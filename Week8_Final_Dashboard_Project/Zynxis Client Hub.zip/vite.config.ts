// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

// Outside Lovable's own sandbox build (e.g. on Vercel CI), force the Nitro
// preset to "vercel" so the build emits .vercel/output/ for zero-config
// Vercel deployment. The NITRO_PRESET env var (set automatically by Vercel
// for Nitro projects) still wins, which means the same source also builds
// cleanly on Netlify, Cloudflare Pages, Node, etc.
export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
  },
  nitro: {
    preset: process.env.NITRO_PRESET ?? "vercel",
  },
});
