# ZYNXIS CLIENT DASHBOARD — Build Plan

## Stack adaptation (important)

Your spec lists React Router DOM + Redux Toolkit + Redux Persist. This Lovable project runs on **TanStack Start + TanStack Router + TanStack Query** (React 19, TypeScript, Vite, Tailwind v4, shadcn/ui). Swapping that out would mean rebuilding the entire app shell and breaking the platform's SSR/routing.

I'll deliver the same product with equivalent (or better) tech:

| Spec'd                  | Will use instead                          | Why                                  |
| ----------------------- | ----------------------------------------- | ------------------------------------ |
| React Router DOM        | TanStack Router (file-based)              | Native to the stack, type-safe       |
| Redux Toolkit + Persist | Zustand + persist middleware              | Lighter, same DX, persists to localStorage |
| TanStack Query          | TanStack Query (kept)                     | Already wired                        |

Everything else (RHF, Zod, Recharts, Framer Motion, Lucide, Sonner, shadcn) stays exactly as specified.

## Scope for this first build

A request this large can't realistically ship every screen in one pass at production polish. I'll build a **complete, navigable, polished v1** covering all modules, then we iterate on depth.

### Design system (src/styles.css)
- Premium dark-first SaaS palette: indigo/blue primary on charcoal/slate surfaces, full light mode
- Inter (body) + Space Grotesk (display) via `<link>` in `__root.tsx`
- Semantic tokens for surfaces, borders, chart colors, status (success/warn/error/info)
- Custom shadcn variants (button: hero/premium; card: elevated/glass)
- Framer Motion presets for page/sidebar/modal transitions

### Layout
- `_authenticated` layout with collapsible sidebar (icon-mini collapse) + top bar
- Top bar: global search trigger (⌘K), theme toggle, notifications popover, profile menu
- Mobile: sheet-based sidebar, responsive grids

### Routes (all real, all polished)
- `/auth/login`, `/auth/register`, `/auth/forgot-password`, `/auth/reset-password` — RHF + Zod, mock auth into Zustand
- `/` Dashboard — 8 KPI cards, revenue line, client growth area, recent activity, top clients
- `/analytics` — 6 charts (line, area, pie, bar, stacked bar, multi-series) with time-range filter
- `/clients` — table: search/sort/filter/pagination, status badges, view/edit/delete, drawer details. Seeded from DummyJSON users
- `/projects` — card grid + table toggle, progress, priority, status, details modal
- `/tasks` — Kanban board (4 columns) + table view, drag-free status change via menu
- `/profile` — tabs: personal / security / preferences / activity timeline
- `/notifications` — list with filters, mark-read, bulk actions, counter in topbar
- `/settings` — appearance, language, timezone, security, account; persisted

### Cross-cutting
- **Command palette** (⌘K) — shadcn Command, global navigation + entity search
- **Export** — CSV + JSON utilities on clients/projects/analytics
- **API integration** — DummyJSON (users → clients), JSONPlaceholder (posts → activity), FakeStoreAPI (products → projects seed) via TanStack Query
- **Error boundaries** at root + per-route `errorComponent` / `notFoundComponent`
- **Empty/loading/error states** for every async surface; skeleton loaders
- **Accessibility** — semantic HTML, aria-labels on icon buttons, focus rings via tokens, keyboard nav, single `<main>`
- **SEO** — per-route `head()` metadata
- **Framer Motion** — page fades, sidebar collapse, modal scale-in, card hover, list stagger
- Strict TS, no `any`

### Folder structure
Will follow your spec, adapted to TanStack file-routing:
```
src/
  routes/        (TanStack file routes)
  components/    (ui, charts, tables, forms, feedback, layout)
  features/      (auth, dashboard, analytics, clients, projects, tasks, profile, notifications, settings)
  services/      (api clients, query options)
  hooks/  store/ (zustand)  types/  constants/  utils/  lib/
```

### Out of scope for v1 (call out honestly)
- Real backend / persistence beyond localStorage (no Lovable Cloud unless you ask)
- Real auth provider — mock session in Zustand
- Drag-and-drop on Kanban (status changes via menu instead) — can add later
- Lighthouse score guarantees depend on hosting; I'll follow all best practices (code-split, lazy charts, memoization, image sizing) but won't run audits in-sandbox

## Approval

Reply **"go"** to build, or tell me what to change (e.g. "keep Redux", "skip auth pages", "add Lovable Cloud for real auth", "prioritize Clients + Dashboard only").
