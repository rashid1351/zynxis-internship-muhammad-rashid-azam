import { queryOptions } from "@tanstack/react-query";

export interface ExternalUser {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  company: { name: string; department: string };
  image: string;
}

export interface ExternalPost {
  id: number;
  title: string;
  body: string;
  userId: number;
}

export interface ExternalProduct {
  id: number;
  title: string;
  price: number;
  category: string;
  image: string;
  rating: { rate: number; count: number };
}

async function jget<T>(url: string, signal?: AbortSignal): Promise<T> {
  const res = await fetch(url, { signal });
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  return res.json() as Promise<T>;
}

export const usersQueryOptions = queryOptions({
  queryKey: ["external", "users"],
  queryFn: ({ signal }) =>
    jget<{ users: ExternalUser[] }>("https://dummyjson.com/users?limit=20", signal).then((d) => d.users),
  staleTime: 5 * 60_000,
});

export const postsQueryOptions = queryOptions({
  queryKey: ["external", "posts"],
  queryFn: ({ signal }) => jget<ExternalPost[]>("https://jsonplaceholder.typicode.com/posts?_limit=12", signal),
  staleTime: 5 * 60_000,
});

export const productsQueryOptions = queryOptions({
  queryKey: ["external", "products"],
  queryFn: ({ signal }) => jget<ExternalProduct[]>("https://fakestoreapi.com/products?limit=8", signal),
  staleTime: 5 * 60_000,
});
