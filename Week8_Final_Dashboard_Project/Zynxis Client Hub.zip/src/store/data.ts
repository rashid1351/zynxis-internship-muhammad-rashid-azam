import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  seedClients,
  seedProjects,
  seedTasks,
  type Client,
  type Project,
  type Task,
} from "@/lib/mock-data";

const uid = (prefix: string) =>
  `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;

interface DataState {
  clients: Client[];
  projects: Project[];
  tasks: Task[];

  addClient: (c: Omit<Client, "id" | "joinDate" | "avatar"> & { joinDate?: string; avatar?: string }) => Client;
  updateClient: (id: string, patch: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  deleteClients: (ids: string[]) => void;

  addProject: (p: Omit<Project, "id" | "team"> & { team?: string[] }) => Project;
  updateProject: (id: string, patch: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  deleteProjects: (ids: string[]) => void;

  addTask: (t: Omit<Task, "id">) => Task;
  updateTask: (id: string, patch: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  deleteTasks: (ids: string[]) => void;

  resetData: () => void;
}

export const useDataStore = create<DataState>()(
  persist(
    (set) => ({
      clients: seedClients,
      projects: seedProjects,
      tasks: seedTasks,

      addClient: (c) => {
        const client: Client = {
          id: uid("cli"),
          joinDate: c.joinDate ?? new Date().toISOString(),
          avatar:
            c.avatar ??
            `https://api.dicebear.com/9.x/initials/svg?seed=${encodeURIComponent(c.name)}`,
          ...c,
        } as Client;
        set((s) => ({ clients: [client, ...s.clients] }));
        return client;
      },
      updateClient: (id, patch) =>
        set((s) => ({ clients: s.clients.map((c) => (c.id === id ? { ...c, ...patch } : c)) })),
      deleteClient: (id) => set((s) => ({ clients: s.clients.filter((c) => c.id !== id) })),
      deleteClients: (ids) =>
        set((s) => ({ clients: s.clients.filter((c) => !ids.includes(c.id)) })),

      addProject: (p) => {
        const project: Project = { id: uid("prj"), team: p.team ?? [], ...p } as Project;
        set((s) => ({ projects: [project, ...s.projects] }));
        return project;
      },
      updateProject: (id, patch) =>
        set((s) => ({
          projects: s.projects.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        })),
      deleteProject: (id) => set((s) => ({ projects: s.projects.filter((p) => p.id !== id) })),
      deleteProjects: (ids) =>
        set((s) => ({ projects: s.projects.filter((p) => !ids.includes(p.id)) })),

      addTask: (t) => {
        const task: Task = { id: uid("tsk"), ...t } as Task;
        set((s) => ({ tasks: [task, ...s.tasks] }));
        return task;
      },
      updateTask: (id, patch) =>
        set((s) => ({ tasks: s.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)) })),
      deleteTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),
      deleteTasks: (ids) => set((s) => ({ tasks: s.tasks.filter((t) => !ids.includes(t.id)) })),

      resetData: () =>
        set({ clients: seedClients, projects: seedProjects, tasks: seedTasks }),
    }),
    { name: "zynxis-data" },
  ),
);
