import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

// ============ Theme ============
type Theme = "light" | "dark" | "system";
interface ThemeState {
  theme: Theme;
  setTheme: (t: Theme) => void;
}
export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: "dark",
      setTheme: (theme) => set({ theme }),
    }),
    { name: "zynxis-theme", storage: createJSONStorage(() => (typeof window !== "undefined" ? localStorage : (undefined as unknown as Storage))) },
  ),
);

// ============ Auth ============
export interface AuthUser {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  phone?: string;
  role: "Admin" | "Manager" | "Member";
}
interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  login: (user: AuthUser) => void;
  logout: () => void;
  updateUser: (patch: Partial<AuthUser>) => void;
}
export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false }),
      updateUser: (patch) =>
        set((s) => (s.user ? { user: { ...s.user, ...patch } } : s)),
    }),
    { name: "zynxis-auth" },
  ),
);

// ============ UI (sidebar, command palette) ============
interface UIState {
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  commandOpen: boolean;
  setCommandOpen: (v: boolean) => void;
}
export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      commandOpen: false,
      setCommandOpen: (commandOpen) => set({ commandOpen }),
    }),
    { name: "zynxis-ui", partialize: (s) => ({ sidebarCollapsed: s.sidebarCollapsed }) },
  ),
);

// ============ Notifications ============
export type NotificationType = "success" | "warning" | "error" | "info";
export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string;
  read: boolean;
}
interface NotificationsState {
  items: Notification[];
  markRead: (id: string) => void;
  markAllRead: () => void;
  remove: (id: string) => void;
  clear: () => void;
  add: (n: Omit<Notification, "id" | "createdAt" | "read">) => void;
}

const seedNotifications: Notification[] = [
  { id: "n1", type: "success", title: "Payment received", message: "Invoice #INV-2042 paid by Helix Labs — $12,400.", createdAt: new Date(Date.now() - 1000 * 60 * 8).toISOString(), read: false },
  { id: "n2", type: "info", title: "New client onboarded", message: "Northwind Analytics added to your workspace.", createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(), read: false },
  { id: "n3", type: "warning", title: "Project deadline approaching", message: "Aurora Redesign is due in 3 days.", createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(), read: false },
  { id: "n4", type: "error", title: "Failed sync", message: "Slack integration token expired. Reconnect required.", createdAt: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(), read: true },
  { id: "n5", type: "info", title: "Weekly report ready", message: "Your performance digest for last week is available.", createdAt: new Date(Date.now() - 1000 * 60 * 60 * 50).toISOString(), read: true },
];

export const useNotificationsStore = create<NotificationsState>()(
  persist(
    (set) => ({
      items: seedNotifications,
      markRead: (id) => set((s) => ({ items: s.items.map((n) => (n.id === id ? { ...n, read: true } : n)) })),
      markAllRead: () => set((s) => ({ items: s.items.map((n) => ({ ...n, read: true })) })),
      remove: (id) => set((s) => ({ items: s.items.filter((n) => n.id !== id) })),
      clear: () => set({ items: [] }),
      add: (n) =>
        set((s) => ({
          items: [
            { ...n, id: crypto.randomUUID(), createdAt: new Date().toISOString(), read: false },
            ...s.items,
          ],
        })),
    }),
    { name: "zynxis-notifications" },
  ),
);

// ============ Settings ============
interface SettingsState {
  language: string;
  timezone: string;
  emailNotifications: boolean;
  pushNotifications: boolean;
  setLanguage: (v: string) => void;
  setTimezone: (v: string) => void;
  setEmailNotifications: (v: boolean) => void;
  setPushNotifications: (v: boolean) => void;
}
export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      language: "en-US",
      timezone: "UTC",
      emailNotifications: true,
      pushNotifications: false,
      setLanguage: (language) => set({ language }),
      setTimezone: (timezone) => set({ timezone }),
      setEmailNotifications: (emailNotifications) => set({ emailNotifications }),
      setPushNotifications: (pushNotifications) => set({ pushNotifications }),
    }),
    { name: "zynxis-settings" },
  ),
);
