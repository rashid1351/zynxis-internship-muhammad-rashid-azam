import { Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Logo } from "@/components/common/Logo";
import type { ReactNode } from "react";
import { useAuthStore } from "@/store";
import { useEffect } from "react";

export function AuthShell({
  title, subtitle, children, footer,
}: { title: string; subtitle: string; children: ReactNode; footer?: ReactNode }) {
  const isAuthed = useAuthStore((s) => s.isAuthenticated);
  const navigate = useNavigate();
  useEffect(() => { if (isAuthed) navigate({ to: "/" }); }, [isAuthed, navigate]);

  return (
    <div className="min-h-dvh w-full bg-background grid md:grid-cols-2">
      {/* Brand panel */}
      <div className="relative hidden md:flex items-end p-10 overflow-hidden bg-sidebar">
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
        <div className="absolute inset-0 opacity-50" style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, var(--border) 1px, transparent 0)",
          backgroundSize: "32px 32px",
        }} />
        <div className="relative z-10 max-w-md">
          <div className="flex items-center gap-3 mb-6">
            <Logo size={44} />
            <div className="font-display text-xl font-bold tracking-tight">ZYNXIS</div>
          </div>
          <blockquote className="text-2xl font-display font-semibold leading-snug">
            "Zynxis replaced four separate tools and gave our leadership the clarity we'd been missing for years."
          </blockquote>
          <div className="mt-4 text-sm text-muted-foreground">— Maya Patel, COO at Northwind Analytics</div>
        </div>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center p-6 md:p-10">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="w-full max-w-sm"
        >
          <Link to="/" className="md:hidden flex items-center gap-2 mb-8">
            <Logo size={36} />
            <span className="font-display font-bold">ZYNXIS</span>
          </Link>
          <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
          <div className="mt-6">{children}</div>
          {footer && <div className="mt-6 text-sm text-muted-foreground">{footer}</div>}
        </motion.div>
      </div>
    </div>
  );
}
