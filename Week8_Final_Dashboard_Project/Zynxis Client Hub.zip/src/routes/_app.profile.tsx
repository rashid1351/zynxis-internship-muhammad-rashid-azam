import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { useAuthStore, useSettingsStore, useThemeStore } from "@/store";
import { CheckCircle2, Pencil, Plus, Trash2, Upload, User, Sun, Moon, Monitor } from "lucide-react";
import { relativeTime } from "@/lib/format";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/profile")({
  head: () => ({
    meta: [
      { title: "Profile — Zynxis" },
      { name: "description", content: "Manage your account, security, preferences and recent activity." },
    ],
  }),
  component: ProfilePage,
});

const personalSchema = z.object({
  name: z.string().trim().min(2, "Name is too short").max(80),
  email: z.string().trim().email("Invalid email").max(120),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
});
type PersonalValues = z.infer<typeof personalSchema>;

const passwordSchema = z
  .object({
    current: z.string().min(1, "Current password is required"),
    next: z.string().min(8, "Use at least 8 characters").max(72),
    confirm: z.string(),
  })
  .refine((v) => v.next === v.confirm, { path: ["confirm"], message: "Passwords do not match" });
type PasswordValues = z.infer<typeof passwordSchema>;

const activity = [
  { id: 1, icon: CheckCircle2, label: "Marked task 'Polish dashboard charts' as done", at: new Date(Date.now() - 1000 * 60 * 9).toISOString() },
  { id: 2, icon: Pencil, label: "Updated client profile for Helix Labs", at: new Date(Date.now() - 1000 * 60 * 47).toISOString() },
  { id: 3, icon: Plus, label: "Created project 'Quantum Onboarding'", at: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString() },
  { id: 4, icon: User, label: "Signed in from a new device", at: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString() },
  { id: 5, icon: Trash2, label: "Archived 2 old notifications", at: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString() },
];

function ProfilePage() {
  const user = useAuthStore((s) => s.user);
  const updateUser = useAuthStore((s) => s.updateUser);
  const settings = useSettingsStore();
  const theme = useThemeStore((s) => s.theme);
  const setTheme = useThemeStore((s) => s.setTheme);
  const fileInput = useRef<HTMLInputElement>(null);
  const [sessions, setSessions] = useState([
    { id: "s1", device: "MacBook Pro · Safari", loc: "San Francisco, USA", current: true },
    { id: "s2", device: "iPhone 15 · Mobile App", loc: "San Francisco, USA", current: false },
    { id: "s3", device: "Windows · Chrome", loc: "Berlin, Germany", current: false },
  ]);

  const personal = useForm<PersonalValues>({
    resolver: zodResolver(personalSchema),
    defaultValues: { name: user?.name ?? "", email: user?.email ?? "", phone: user?.phone ?? "" },
  });

  const password = useForm<PasswordValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: { current: "", next: "", confirm: "" },
  });

  const onPersonal = personal.handleSubmit((v) => {
    updateUser({ name: v.name, email: v.email, phone: v.phone || undefined });
    toast.success("Profile updated");
  });

  const onPassword = password.handleSubmit(async (_v) => {
    await new Promise((r) => setTimeout(r, 400));
    password.reset({ current: "", next: "", confirm: "" });
    toast.success("Password updated");
  });

  const onUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!/^image\/(png|jpeg|jpg|webp|gif)$/.test(file.type)) {
      toast.error("Please choose a PNG, JPG, WEBP or GIF image"); return;
    }
    if (file.size > 2 * 1024 * 1024) { toast.error("Image must be 2 MB or smaller"); return; }
    const reader = new FileReader();
    reader.onload = () => {
      updateUser({ avatar: reader.result as string });
      toast.success("Photo updated");
    };
    reader.readAsDataURL(file);
  };

  return (
    <PageShell>
      <PageHeader title="Profile" description="Manage your personal information, security and activity." />

      <Tabs defaultValue="personal">
        <TabsList>
          <TabsTrigger value="personal">Personal</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="personal" className="mt-4">
          <Card>
            <CardHeader><CardTitle>Personal information</CardTitle></CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="h-20 w-20"><AvatarImage src={user?.avatar} alt="" /><AvatarFallback className="text-xl">{user?.name?.[0]}</AvatarFallback></Avatar>
                <div>
                  <input ref={fileInput} type="file" accept="image/*" className="hidden" onChange={onUpload} />
                  <Button variant="outline" size="sm" onClick={() => fileInput.current?.click()}>
                    <Upload className="h-4 w-4 mr-1.5" /> Change photo
                  </Button>
                  {user?.avatar && user.avatar.startsWith("data:") && (
                    <Button variant="ghost" size="sm" className="ml-2" onClick={() => { updateUser({ avatar: undefined }); toast.success("Photo removed"); }}>
                      Remove
                    </Button>
                  )}
                  <p className="mt-1 text-xs text-muted-foreground">PNG, JPG, WEBP or GIF up to 2MB.</p>
                </div>
              </div>
              <form onSubmit={onPersonal} className="space-y-4" noValidate>
                <div className="grid sm:grid-cols-2 gap-4">
                  <Field label="Full name" error={personal.formState.errors.name?.message}>
                    <Input {...personal.register("name")} />
                  </Field>
                  <Field label="Email" error={personal.formState.errors.email?.message}>
                    <Input type="email" {...personal.register("email")} />
                  </Field>
                  <Field label="Phone" error={personal.formState.errors.phone?.message}>
                    <Input {...personal.register("phone")} placeholder="+1 (555) 000-0000" />
                  </Field>
                  <Field label="Role">
                    <Input value={user?.role ?? ""} readOnly />
                  </Field>
                </div>
                <div className="flex gap-2">
                  <Button type="submit" disabled={personal.formState.isSubmitting || !personal.formState.isDirty}>
                    {personal.formState.isSubmitting ? "Saving…" : "Save changes"}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => personal.reset({ name: user?.name ?? "", email: user?.email ?? "", phone: user?.phone ?? "" })}>Reset</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="mt-4 space-y-4">
          <Card>
            <CardHeader><CardTitle>Change password</CardTitle></CardHeader>
            <CardContent>
              <form onSubmit={onPassword} className="space-y-3 max-w-md" noValidate>
                <Field label="Current password" error={password.formState.errors.current?.message}>
                  <Input type="password" {...password.register("current")} />
                </Field>
                <Field label="New password" error={password.formState.errors.next?.message}>
                  <Input type="password" {...password.register("next")} />
                </Field>
                <Field label="Confirm new password" error={password.formState.errors.confirm?.message}>
                  <Input type="password" {...password.register("confirm")} />
                </Field>
                <Button type="submit" disabled={password.formState.isSubmitting}>
                  {password.formState.isSubmitting ? "Updating…" : "Update password"}
                </Button>
              </form>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Login sessions</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {sessions.map((s) => (
                <div key={s.id} className="flex items-center justify-between rounded-lg border border-border/60 p-3">
                  <div>
                    <div className="text-sm font-medium">{s.device} {s.current && <span className="ml-2 rounded-full bg-success/15 text-success px-1.5 py-0.5 text-[10px]">Current</span>}</div>
                    <div className="text-xs text-muted-foreground">{s.loc}</div>
                  </div>
                  {!s.current && (
                    <Button variant="ghost" size="sm" onClick={() => { setSessions((arr) => arr.filter((x) => x.id !== s.id)); toast.success("Session revoked"); }}>
                      Revoke
                    </Button>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences" className="mt-4 space-y-4">
          <Card>
            <CardHeader><CardTitle>Theme</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-3 max-w-md">
                {[
                  { v: "light" as const, Icon: Sun, label: "Light" },
                  { v: "dark" as const, Icon: Moon, label: "Dark" },
                  { v: "system" as const, Icon: Monitor, label: "System" },
                ].map(({ v, Icon, label }) => (
                  <button
                    key={v}
                    onClick={() => { setTheme(v); toast.success(`Theme set to ${label.toLowerCase()}`); }}
                    className={cn(
                      "flex flex-col items-center gap-2 rounded-lg border-2 p-4 transition-all",
                      theme === v ? "border-primary bg-primary/5" : "border-border hover:border-primary/40",
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="text-sm font-medium">{label}</span>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Notifications</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <ToggleRow
                label="Email notifications"
                desc="Weekly digest, alerts and reports."
                checked={settings.emailNotifications}
                onChange={(v) => { settings.setEmailNotifications(v); toast.success(`Email notifications ${v ? "enabled" : "disabled"}`); }}
              />
              <ToggleRow
                label="Push notifications"
                desc="Real-time alerts in your browser."
                checked={settings.pushNotifications}
                onChange={(v) => { settings.setPushNotifications(v); toast.success(`Push notifications ${v ? "enabled" : "disabled"}`); }}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="mt-4">
          <Card>
            <CardHeader><CardTitle>Recent activity</CardTitle></CardHeader>
            <CardContent>
              <ol className="space-y-4">
                {activity.map((a, i) => {
                  const Icon = a.icon;
                  return (
                    <li key={a.id} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <div className="grid h-8 w-8 place-items-center rounded-full bg-primary/10 text-primary"><Icon className="h-4 w-4" /></div>
                        {i < activity.length - 1 && <div className="flex-1 w-px bg-border mt-1" />}
                      </div>
                      <div className="pb-4">
                        <div className="text-sm">{a.label}</div>
                        <div className="text-xs text-muted-foreground">{relativeTime(a.at)}</div>
                      </div>
                    </li>
                  );
                })}
              </ol>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageShell>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

function ToggleRow({ label, desc, checked, onChange }: { label: string; desc: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-lg border border-border/60 p-3">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
