import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHeader } from "@/components/layout/PageShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, RefreshCw } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/status")({
  head: () => ({
    meta: [
      { title: "System Status — Zynxis Client Dashboard" },
      { name: "description", content: "Live operational status of Zynxis services." },
    ],
  }),
  component: StatusPage,
});

const services = [
  { name: "Dashboard & API", region: "Global" },
  { name: "Authentication", region: "Global" },
  { name: "Workspace storage", region: "us-east-1" },
  { name: "Analytics pipeline", region: "eu-west-2" },
  { name: "Notifications delivery", region: "Global" },
  { name: "Webhooks", region: "Global" },
];

function seedUptime(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return 99.9 + (h % 10) / 100;
}

function StatusPage() {
  const [checkedAt, setCheckedAt] = useState(() => new Date());

  const bars = useMemo(() => {
    return Array.from({ length: 60 }, (_, i) => {
      const v = (Math.sin(i * 0.7) + 1) / 2;
      return v > 0.92 ? "degraded" : "operational";
    });
  }, []);

  function refresh() {
    setCheckedAt(new Date());
    toast.success("Status refreshed — all systems operational.");
  }

  return (
    <PageShell>
      <PageHeader
        title="System Status"
        description="Real-time health of the Zynxis platform across all regions."
        action={
          <Button variant="outline" size="sm" onClick={refresh} className="gap-2">
            <RefreshCw className="h-4 w-4" /> Refresh
          </Button>
        }
      />
      <Card className="border-emerald-500/30 bg-emerald-500/5">
        <CardContent className="flex items-center gap-4 p-6">
          <div className="grid h-12 w-12 place-items-center rounded-full bg-emerald-500/15 text-emerald-500">
            <CheckCircle2 className="h-6 w-6" />
          </div>
          <div className="flex-1">
            <div className="font-display text-lg font-semibold">All systems operational</div>
            <div className="text-sm text-muted-foreground">
              Last checked {checkedAt.toLocaleTimeString()} · Updates every 60s
            </div>
          </div>
          <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30 hover:bg-emerald-500/20">
            99.98% uptime
          </Badge>
        </CardContent>
      </Card>

      <div className="grid gap-3 mt-4">
        {services.map((s) => {
          const uptime = seedUptime(s.name).toFixed(2);
          return (
            <Card key={s.name} className="border-border/60">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <div>
                  <CardTitle className="text-base">{s.name}</CardTitle>
                  <div className="text-xs text-muted-foreground mt-0.5">{s.region}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm tabular-nums text-muted-foreground">{uptime}%</span>
                  <Badge variant="outline" className="border-emerald-500/40 text-emerald-600">
                    Operational
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-[2px]" aria-label="60-day uptime history">
                  {bars.map((b, i) => (
                    <div
                      key={i}
                      className={`h-8 flex-1 rounded-sm ${
                        b === "operational" ? "bg-emerald-500/70" : "bg-amber-500/70"
                      }`}
                      title={`Day -${60 - i}: ${b}`}
                    />
                  ))}
                </div>
                <div className="mt-2 flex justify-between text-[10px] uppercase tracking-wider text-muted-foreground">
                  <span>60 days ago</span>
                  <span>Today</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="mt-4 border-border/60">
        <CardHeader>
          <CardTitle className="text-base">Recent incidents</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          No incidents reported in the last 90 days.
        </CardContent>
      </Card>
    </PageShell>
  );
}
