import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Suspense, lazy, useMemo } from "react";
import { motion } from "framer-motion";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { DollarSign, TrendingUp, Users, FolderKanban, CheckCircle2, ArrowUpRight, ArrowDownRight, Activity, Target, Clock } from "lucide-react";
import { revenueSeries, clientGrowth } from "@/lib/mock-data";
import { currency, compactNumber, relativeTime } from "@/lib/format";
import { postsQueryOptions } from "@/services/api";
import { useDataStore } from "@/store/data";

const RevenueChart = lazy(() => import("@/components/charts/RevenueChart").then((m) => ({ default: m.RevenueChart })));
const GrowthChart = lazy(() => import("@/components/charts/GrowthChart").then((m) => ({ default: m.GrowthChart })));

export const Route = createFileRoute("/_app/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Zynxis" },
      { name: "description", content: "Executive overview of revenue, clients, projects and team performance." },
    ],
  }),
  loader: ({ context }) => { context.queryClient.prefetchQuery(postsQueryOptions); },
  component: Dashboard,
});

interface Kpi { label: string; value: string; delta: number; icon: React.ComponentType<{ className?: string }>; }

function KpiCard({ kpi, i }: { kpi: Kpi; i: number }) {
  const positive = kpi.delta >= 0;
  const Icon = kpi.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: i * 0.04 }}
      whileHover={{ y: -2 }}
    >
      <Card className="relative overflow-hidden border-border/60 hover:border-primary/30 transition-colors">
        <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
        <CardContent className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{kpi.label}</div>
              <div className="mt-2 text-2xl font-bold tracking-tight">{kpi.value}</div>
            </div>
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
              <Icon className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 flex items-center gap-1.5 text-xs">
            <span className={positive ? "inline-flex items-center gap-0.5 rounded-full bg-success/10 px-1.5 py-0.5 text-success font-medium" : "inline-flex items-center gap-0.5 rounded-full bg-destructive/10 px-1.5 py-0.5 text-destructive font-medium"}>
              {positive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              {Math.abs(kpi.delta).toFixed(1)}%
            </span>
            <span className="text-muted-foreground">vs last month</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function Dashboard() {
  const clients = useDataStore((s) => s.clients);
  const projects = useDataStore((s) => s.projects);
  const tasks = useDataStore((s) => s.tasks);

  const kpis = useMemo<Kpi[]>(() => {
    const totalRevenue = clients.reduce((s, c) => s + c.revenue, 0);
    const activeClients = clients.filter((c) => c.status === "active").length;
    const activeProjects = projects.filter((p) => p.status === "in_progress" || p.status === "planning").length;
    const pendingTasks = tasks.filter((t) => t.status !== "done").length;
    const done = tasks.filter((t) => t.status === "done").length;
    const completion = tasks.length > 0 ? (done / tasks.length) * 100 : 0;
    const retention = clients.length > 0 ? (activeClients / clients.length) * 100 : 0;
    const monthly = totalRevenue / 12;
    return [
      { label: "Total Revenue", value: currency(totalRevenue), delta: 12.4, icon: DollarSign },
      { label: "Monthly Revenue", value: currency(Math.round(monthly)), delta: 8.2, icon: TrendingUp },
      { label: "Active Clients", value: String(activeClients), delta: 4.6, icon: Users },
      { label: "Active Projects", value: String(activeProjects), delta: 2.1, icon: FolderKanban },
      { label: "Pending Tasks", value: String(pendingTasks), delta: -5.3, icon: Clock },
      { label: "Completion Rate", value: `${completion.toFixed(1)}%`, delta: 1.8, icon: CheckCircle2 },
      { label: "Team Members", value: String(new Set(projects.flatMap((p) => p.team)).size), delta: 6.7, icon: Activity },
      { label: "Client Retention", value: `${retention.toFixed(1)}%`, delta: 0.9, icon: Target },
    ];
  }, [clients, projects, tasks]);

  const topClients = useMemo(() => [...clients].sort((a, b) => b.revenue - a.revenue).slice(0, 5), [clients]);
  const activeProjects = useMemo(() => projects.filter((p) => p.status === "in_progress").slice(0, 6), [projects]);

  return (
    <PageShell>
      <PageHeader
        title="Good day, Avery"
        description="Here's what's happening across your workspace today."
        action={<Button asChild><Link to="/analytics">View analytics</Link></Button>}
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        {kpis.map((k, i) => <KpiCard key={k.label} kpi={k} i={i} />)}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Revenue performance</CardTitle></CardHeader>
          <CardContent>
            <Suspense fallback={<Skeleton className="h-72 w-full" />}>
              <RevenueChart data={revenueSeries} />
            </Suspense>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Client growth</CardTitle></CardHeader>
          <CardContent>
            <Suspense fallback={<Skeleton className="h-72 w-full" />}>
              <GrowthChart data={clientGrowth} />
            </Suspense>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle>Top clients by revenue</CardTitle>
            <Button asChild variant="ghost" size="sm"><Link to="/clients">View all</Link></Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {topClients.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-lg border border-border/60 px-3 py-2.5 hover:bg-accent/40 transition-colors">
                <Avatar className="h-9 w-9"><AvatarImage src={c.avatar} alt="" /><AvatarFallback>{c.name[0]}</AvatarFallback></Avatar>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{c.name}</div>
                  <div className="truncate text-xs text-muted-foreground">{c.company} · {c.industry}</div>
                </div>
                <div className="text-sm font-semibold tabular-nums">{compactNumber(c.revenue)}</div>
              </div>
            ))}
            {topClients.length === 0 && <div className="text-sm text-muted-foreground text-center py-6">No clients yet. <Link to="/clients" className="text-primary hover:underline">Add one</Link>.</div>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Recent activity</CardTitle></CardHeader>
          <CardContent>
            <Suspense fallback={<Skeleton className="h-72 w-full" />}>
              <ActivityFeed />
            </Suspense>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle>Active projects</CardTitle>
          <Button asChild variant="ghost" size="sm"><Link to="/projects">View all</Link></Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {activeProjects.map((p) => {
              const projectTasks = tasks.filter((t) => t.project === p.name);
              return (
                <div key={p.id} className="rounded-lg border border-border/60 p-4 hover:border-primary/30 transition-colors">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold">{p.name}</div>
                      <div className="truncate text-xs text-muted-foreground">{p.client}</div>
                    </div>
                    <Badge variant="outline" className="shrink-0 capitalize text-[10px]">{p.priority}</Badge>
                  </div>
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-xs text-muted-foreground"><span>Progress</span><span className="font-medium text-foreground">{p.progress}%</span></div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-muted">
                      <div className="h-full rounded-full bg-gradient-to-r from-primary to-primary-glow" style={{ width: `${p.progress}%` }} />
                    </div>
                  </div>
                  <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                    <span>{p.team.length} members</span>
                    <span>{projectTasks.length} tasks</span>
                  </div>
                </div>
              );
            })}
            {activeProjects.length === 0 && (
              <div className="col-span-full p-8 text-center text-sm text-muted-foreground">
                No active projects. <Link to="/projects" className="text-primary hover:underline">Create one</Link>.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </PageShell>
  );
}

function ActivityFeed() {
  const { data } = useSuspenseQuery(postsQueryOptions);
  return (
    <ol className="space-y-3">
      {data.slice(0, 6).map((p, i) => (
        <li key={p.id} className="flex gap-3">
          <div className="relative flex flex-col items-center">
            <div className="h-2 w-2 mt-1.5 rounded-full bg-primary ring-4 ring-primary/15" />
            {i < 5 && <div className="flex-1 w-px bg-border" />}
          </div>
          <div className="pb-3 min-w-0">
            <div className="text-sm font-medium truncate">{p.title}</div>
            <div className="text-xs text-muted-foreground line-clamp-1">{p.body}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mt-0.5">{relativeTime(new Date(Date.now() - i * 3600000).toISOString())}</div>
          </div>
        </li>
      ))}
    </ol>
  );
}
