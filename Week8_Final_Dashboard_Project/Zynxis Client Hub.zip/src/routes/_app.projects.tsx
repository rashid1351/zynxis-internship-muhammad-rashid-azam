import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Search, Plus, Calendar, Users as UsersIcon, Download, MoreHorizontal, Pencil, Trash2, FileJson, FileText } from "lucide-react";
import { type Project, type ProjectStatus } from "@/lib/mock-data";
import { currency, formatDate, downloadFile, toCSV } from "@/lib/format";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useDataStore } from "@/store/data";
import { useNotificationsStore } from "@/store";
import { ProjectForm, type ProjectFormValues } from "@/components/forms/ProjectForm";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";

export const Route = createFileRoute("/_app/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Zynxis" },
      { name: "description", content: "Track active projects, budgets, progress and team allocation." },
    ],
  }),
  component: ProjectsPage,
});

const statusLabel: Record<ProjectStatus, string> = {
  planning: "Planning",
  in_progress: "In Progress",
  review: "Review",
  completed: "Completed",
  cancelled: "Cancelled",
};
const statusStyle: Record<ProjectStatus, string> = {
  planning: "bg-info/15 text-info border-info/30",
  in_progress: "bg-primary/15 text-primary border-primary/30",
  review: "bg-warning/15 text-warning border-warning/30",
  completed: "bg-success/15 text-success border-success/30",
  cancelled: "bg-destructive/15 text-destructive border-destructive/30",
};
const priorityDot: Record<string, string> = {
  low: "bg-muted-foreground",
  medium: "bg-info",
  high: "bg-warning",
  critical: "bg-destructive",
};

function toProjectPatch(v: ProjectFormValues): Omit<Project, "id"> {
  return {
    name: v.name,
    client: v.client,
    description: v.description,
    budget: v.budget,
    deadline: new Date(v.deadline).toISOString(),
    team: v.team.split(",").map((s) => s.trim()).filter(Boolean),
    progress: v.progress,
    priority: v.priority,
    status: v.status,
  };
}

function ProjectsPage() {
  const projects = useDataStore((s) => s.projects);
  const addProject = useDataStore((s) => s.addProject);
  const updateProject = useDataStore((s) => s.updateProject);
  const deleteProject = useDataStore((s) => s.deleteProject);
  const deleteProjects = useDataStore((s) => s.deleteProjects);
  const notify = useNotificationsStore((s) => s.add);

  const [q, setQ] = useState("");
  const [status, setStatus] = useState<ProjectStatus | "all">("all");
  const [open, setOpen] = useState<Project | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Project | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [confirmBulk, setConfirmBulk] = useState(false);
  const [selection, setSelection] = useState<Set<string>>(new Set());

  const filtered = useMemo(
    () => projects.filter((p) =>
      (status === "all" || p.status === status) &&
      (q === "" || [p.name, p.client].some((f) => f.toLowerCase().includes(q.toLowerCase()))),
    ),
    [projects, q, status],
  );

  const toggle = (id: string) =>
    setSelection((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const handleSubmit = (v: ProjectFormValues) => {
    const patch = toProjectPatch(v);
    if (editing) {
      updateProject(editing.id, patch);
      toast.success("Project updated");
      notify({ type: "info", title: "Project updated", message: `${v.name} was updated.` });
    } else {
      const p = addProject(patch);
      toast.success("Project created");
      notify({ type: "success", title: "New project", message: `${p.name} for ${p.client} was created.` });
    }
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    const p = projects.find((x) => x.id === id);
    deleteProject(id);
    setSelection((s) => { const n = new Set(s); n.delete(id); return n; });
    toast.success("Project removed");
    if (p) notify({ type: "warning", title: "Project removed", message: `${p.name} was deleted.` });
  };

  const handleBulkDelete = () => {
    const ids = Array.from(selection);
    deleteProjects(ids);
    setSelection(new Set());
    toast.success(`${ids.length} projects removed`);
    notify({ type: "warning", title: "Projects removed", message: `${ids.length} projects were deleted.` });
  };

  const updateStatus = (id: string, s: ProjectStatus) => {
    updateProject(id, { status: s, ...(s === "completed" ? { progress: 100 } : {}) });
    toast.success(`Status updated to ${statusLabel[s]}`);
  };

  const exportCsv = () => {
    downloadFile("projects.csv", toCSV(filtered.map((p) => ({ ...p, team: p.team.join("|") }))), "text/csv");
    toast.success("Exported CSV");
  };
  const exportJson = () => {
    downloadFile("projects.json", JSON.stringify(filtered, null, 2), "application/json");
    toast.success("Exported JSON");
  };

  return (
    <PageShell>
      <PageHeader
        title="Projects"
        description={`${filtered.length} of ${projects.length} projects`}
        action={
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-1.5" /> Export</Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={exportCsv}><FileText className="h-4 w-4 mr-2" /> CSV</DropdownMenuItem>
                <DropdownMenuItem onClick={exportJson}><FileJson className="h-4 w-4 mr-2" /> JSON</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button size="sm" onClick={() => { setEditing(null); setFormOpen(true); }}>
              <Plus className="h-4 w-4 mr-1.5" /> New project
            </Button>
          </div>
        }
      />

      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search projects…" className="pl-9" />
          </div>
          <Select value={status} onValueChange={(v) => setStatus(v as ProjectStatus | "all")}>
            <SelectTrigger className="w-full sm:w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {Object.entries(statusLabel).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {selection.size > 0 && (
        <div className="flex items-center justify-between gap-2 rounded-lg border border-border bg-accent/40 px-3 py-2 text-sm">
          <span><strong>{selection.size}</strong> selected</span>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => setSelection(new Set())}>Clear</Button>
            <Button size="sm" variant="destructive" onClick={() => setConfirmBulk(true)}>
              <Trash2 className="h-4 w-4 mr-1.5" /> Delete selected
            </Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((p, i) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: Math.min(i * 0.03, 0.3) }}
          >
            <Card className="cursor-pointer hover:border-primary/40 transition-colors h-full" onClick={() => setOpen(p)}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${priorityDot[p.priority]}`} aria-label={`Priority: ${p.priority}`} />
                      <Badge variant="outline" className={statusStyle[p.status] + " text-[10px]"}>{statusLabel[p.status]}</Badge>
                    </div>
                    <h3 className="mt-2 font-semibold truncate">{p.name}</h3>
                    <p className="text-xs text-muted-foreground truncate">{p.client}</p>
                  </div>
                  <div className="flex items-center gap-1 -mr-2 -mt-1" onClick={(e) => e.stopPropagation()}>
                    <Checkbox checked={selection.has(p.id)} onCheckedChange={() => toggle(p.id)} aria-label={`Select ${p.name}`} />
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7" aria-label="Project actions"><MoreHorizontal className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => { setEditing(p); setFormOpen(true); }}><Pencil className="h-4 w-4 mr-2" /> Edit</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {(Object.entries(statusLabel) as [ProjectStatus, string][])
                          .filter(([k]) => k !== p.status)
                          .map(([k, l]) => (
                            <DropdownMenuItem key={k} onClick={() => updateStatus(p.id, k)}>Mark {l}</DropdownMenuItem>
                          ))}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive" onClick={() => setConfirmId(p.id)}><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="flex items-center justify-between text-xs text-muted-foreground"><span>Progress</span><span className="font-medium text-foreground">{p.progress}%</span></div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-gradient-to-r from-primary to-primary-glow" style={{ width: `${p.progress}%` }} />
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {formatDate(p.deadline)}</span>
                  <span className="font-semibold text-foreground">{currency(p.budget)}</span>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div className="flex -space-x-2">
                    {p.team.slice(0, 4).map((m, idx) => (
                      <Avatar key={idx} className="h-6 w-6 border-2 border-card">
                        <AvatarFallback className="text-[10px] bg-secondary">{m.split(" ").map((s) => s[0]).join("")}</AvatarFallback>
                      </Avatar>
                    ))}
                    {p.team.length > 4 && (
                      <div className="grid h-6 w-6 place-items-center rounded-full border-2 border-card bg-muted text-[10px] font-medium">+{p.team.length - 4}</div>
                    )}
                  </div>
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground"><UsersIcon className="h-3 w-3" /> {p.team.length}</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
        {filtered.length === 0 && (
          <Card className="col-span-full p-12 text-center text-sm text-muted-foreground">
            No projects match your filters.
          </Card>
        )}
      </div>

      <Dialog open={!!open} onOpenChange={(v) => !v && setOpen(null)}>
        <DialogContent className="max-w-lg">
          {open && (
            <>
              <DialogHeader>
                <DialogTitle>{open.name}</DialogTitle>
                <DialogDescription>{open.client} · {statusLabel[open.status]}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <p className="text-muted-foreground">{open.description}</p>
                <div className="grid grid-cols-2 gap-3">
                  <Stat label="Budget" value={currency(open.budget)} />
                  <Stat label="Deadline" value={formatDate(open.deadline)} />
                  <Stat label="Priority" value={<span className="capitalize">{open.priority}</span>} />
                  <Stat label="Progress" value={`${open.progress}%`} />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Team</div>
                  <div className="flex flex-wrap gap-1.5">
                    {open.team.map((m) => <Badge key={m} variant="secondary">{m}</Badge>)}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => { setEditing(open); setFormOpen(true); setOpen(null); }}><Pencil className="h-4 w-4 mr-1.5" /> Edit</Button>
                <Button variant="destructive" onClick={() => { setConfirmId(open.id); setOpen(null); }}><Trash2 className="h-4 w-4 mr-1.5" /> Delete</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <ProjectForm
        open={formOpen}
        onOpenChange={(v) => { setFormOpen(v); if (!v) setEditing(null); }}
        initial={editing}
        onSubmit={handleSubmit}
      />

      <ConfirmDialog
        open={!!confirmId}
        onOpenChange={(v) => !v && setConfirmId(null)}
        title="Delete this project?"
        description="This action cannot be undone."
        confirmLabel="Delete"
        destructive
        onConfirm={() => { if (confirmId) handleDelete(confirmId); setConfirmId(null); }}
      />
      <ConfirmDialog
        open={confirmBulk}
        onOpenChange={setConfirmBulk}
        title={`Delete ${selection.size} projects?`}
        description="This action cannot be undone."
        confirmLabel="Delete all"
        destructive
        onConfirm={() => { handleBulkDelete(); setConfirmBulk(false); }}
      />
    </PageShell>
  );
}

function Stat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border/60 bg-muted/30 p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-semibold">{value}</div>
    </div>
  );
}
