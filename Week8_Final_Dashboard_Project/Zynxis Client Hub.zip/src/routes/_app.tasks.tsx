import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, MoreHorizontal, Search, Pencil, Trash2, Check, Download, FileText, FileJson } from "lucide-react";
import { type Priority, type Task, type TaskStatus } from "@/lib/mock-data";
import { downloadFile, formatDate, toCSV } from "@/lib/format";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useDataStore } from "@/store/data";
import { useNotificationsStore } from "@/store";
import { TaskForm, type TaskFormValues } from "@/components/forms/TaskForm";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";

export const Route = createFileRoute("/_app/tasks")({
  head: () => ({
    meta: [
      { title: "Tasks — Zynxis" },
      { name: "description", content: "Kanban board and table view for team task management." },
    ],
  }),
  component: TasksPage,
});

const columns: { key: TaskStatus; title: string }[] = [
  { key: "todo", title: "To do" },
  { key: "in_progress", title: "In progress" },
  { key: "review", title: "Review" },
  { key: "done", title: "Done" },
];

const priorityStyle: Record<string, string> = {
  low: "bg-muted text-muted-foreground",
  medium: "bg-info/15 text-info",
  high: "bg-warning/15 text-warning",
  critical: "bg-destructive/15 text-destructive",
};

function toTaskPatch(v: TaskFormValues): Omit<Task, "id"> {
  return {
    title: v.title,
    description: v.description,
    assignee: v.assignee,
    project: v.project,
    dueDate: new Date(v.dueDate).toISOString(),
    priority: v.priority,
    status: v.status,
  };
}

function TasksPage() {
  const tasks = useDataStore((s) => s.tasks);
  const projects = useDataStore((s) => s.projects);
  const clients = useDataStore((s) => s.clients);
  const addTask = useDataStore((s) => s.addTask);
  const updateTask = useDataStore((s) => s.updateTask);
  const deleteTask = useDataStore((s) => s.deleteTask);
  const deleteTasks = useDataStore((s) => s.deleteTasks);
  const notify = useNotificationsStore((s) => s.add);

  const [q, setQ] = useState("");
  const [priorityFilter, setPriorityFilter] = useState<Priority | "all">("all");
  const [statusFilter, setStatusFilter] = useState<TaskStatus | "all">("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [confirmBulk, setConfirmBulk] = useState(false);
  const [selection, setSelection] = useState<Set<string>>(new Set());

  const projectOptions = useMemo(() => projects.map((p) => p.name), [projects]);
  const assigneeOptions = useMemo(() => Array.from(new Set([
    ...clients.map((c) => c.name),
    ...projects.flatMap((p) => p.team),
  ])).sort(), [clients, projects]);

  const filtered = useMemo(
    () => tasks.filter((t) =>
      (priorityFilter === "all" || t.priority === priorityFilter) &&
      (statusFilter === "all" || t.status === statusFilter) &&
      (q === "" || [t.title, t.assignee, t.project].some((f) => f.toLowerCase().includes(q.toLowerCase()))),
    ),
    [tasks, q, priorityFilter, statusFilter],
  );

  const toggle = (id: string) =>
    setSelection((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const allFilteredSelected = filtered.length > 0 && filtered.every((t) => selection.has(t.id));
  const toggleAll = () =>
    setSelection((s) => {
      const n = new Set(s);
      if (allFilteredSelected) filtered.forEach((t) => n.delete(t.id));
      else filtered.forEach((t) => n.add(t.id));
      return n;
    });

  const moveTask = (id: string, status: TaskStatus) => {
    updateTask(id, { status });
    toast.success(`Moved to ${columns.find((c) => c.key === status)?.title}`);
  };

  const changePriority = (id: string, priority: Priority) => {
    updateTask(id, { priority });
    toast.success(`Priority set to ${priority}`);
  };

  const markComplete = (id: string) => moveTask(id, "done");

  const handleSubmit = (v: TaskFormValues) => {
    const patch = toTaskPatch(v);
    if (editing) {
      updateTask(editing.id, patch);
      toast.success("Task updated");
      notify({ type: "info", title: "Task updated", message: `${v.title} was updated.` });
    } else {
      addTask(patch);
      toast.success("Task created");
      notify({ type: "success", title: "New task", message: `${v.title} assigned to ${v.assignee}.` });
    }
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    deleteTask(id);
    setSelection((s) => { const n = new Set(s); n.delete(id); return n; });
    toast.success("Task removed");
  };

  const handleBulkDelete = () => {
    const ids = Array.from(selection);
    deleteTasks(ids);
    setSelection(new Set());
    toast.success(`${ids.length} tasks removed`);
  };

  const exportCsv = () => {
    downloadFile("tasks.csv", toCSV(filtered), "text/csv");
    toast.success("Exported CSV");
  };
  const exportJson = () => {
    downloadFile("tasks.json", JSON.stringify(filtered, null, 2), "application/json");
    toast.success("Exported JSON");
  };

  return (
    <PageShell>
      <PageHeader
        title="Tasks"
        description={`${filtered.length} of ${tasks.length} tasks`}
        action={
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-1.5" /> Export</Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={exportCsv}><FileText className="h-4 w-4 mr-2" /> CSV</DropdownMenuItem>
                <DropdownMenuItem onClick={exportJson}><FileJson className="h-4 w-4 mr-2" /> JSON</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button size="sm" onClick={() => { setEditing(null); setFormOpen(true); }}>
              <Plus className="h-4 w-4 mr-1.5" /> New task
            </Button>
          </div>
        }
      />

      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search tasks, assignees, projects…" className="pl-9" />
          </div>
          <Select value={priorityFilter} onValueChange={(v) => setPriorityFilter(v as Priority | "all")}>
            <SelectTrigger className="w-full sm:w-40"><SelectValue placeholder="Priority" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All priorities</SelectItem>
              {(["low", "medium", "high", "critical"] as Priority[]).map((p) => (
                <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as TaskStatus | "all")}>
            <SelectTrigger className="w-full sm:w-40"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {columns.map((c) => <SelectItem key={c.key} value={c.key}>{c.title}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {selection.size > 0 && (
        <div className="flex items-center justify-between gap-2 rounded-lg border border-border bg-accent/40 px-3 py-2 text-sm">
          <span><strong>{selection.size}</strong> selected</span>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => setSelection(new Set())}>Clear</Button>
            <Button size="sm" variant="destructive" onClick={() => setConfirmBulk(true)}>
              <Trash2 className="h-4 w-4 mr-1.5" /> Delete selected
            </Button>
          </div>
        </div>
      )}

      <Tabs defaultValue="board">
        <TabsList>
          <TabsTrigger value="board">Kanban</TabsTrigger>
          <TabsTrigger value="table">Table</TabsTrigger>
        </TabsList>

        <TabsContent value="board" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {columns.map((col) => {
              const colTasks = filtered.filter((t) => t.status === col.key);
              return (
                <Card key={col.key} className="bg-muted/30">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center justify-between text-sm">
                      <span>{col.title}</span>
                      <Badge variant="secondary">{colTasks.length}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {colTasks.map((t, i) => (
                      <motion.div
                        key={t.id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, delay: Math.min(i * 0.02, 0.2) }}
                        className="rounded-lg border border-border/60 bg-card p-3 shadow-sm hover:shadow-md hover:border-primary/30 transition-all"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-start gap-2 min-w-0">
                            <Checkbox checked={selection.has(t.id)} onCheckedChange={() => toggle(t.id)} aria-label={`Select ${t.title}`} className="mt-0.5" />
                            <div className="text-sm font-medium leading-snug truncate">{t.title}</div>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-6 w-6 -mr-1" aria-label="Task actions"><MoreHorizontal className="h-3.5 w-3.5" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => { setEditing(t); setFormOpen(true); }}><Pencil className="h-4 w-4 mr-2" /> Edit</DropdownMenuItem>
                              {t.status !== "done" && (
                                <DropdownMenuItem onClick={() => markComplete(t.id)}><Check className="h-4 w-4 mr-2" /> Mark complete</DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              {columns.filter((c) => c.key !== t.status).map((c) => (
                                <DropdownMenuItem key={c.key} onClick={() => moveTask(t.id, c.key)}>Move to {c.title}</DropdownMenuItem>
                              ))}
                              <DropdownMenuSeparator />
                              {(["low", "medium", "high", "critical"] as Priority[])
                                .filter((p) => p !== t.priority)
                                .map((p) => (
                                  <DropdownMenuItem key={p} onClick={() => changePriority(t.id, p)} className="capitalize">Set priority: {p}</DropdownMenuItem>
                                ))}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-destructive" onClick={() => setConfirmId(t.id)}><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        <div className="mt-1 text-xs text-muted-foreground truncate">{t.project}</div>
                        <div className="mt-3 flex items-center justify-between">
                          <span className={`inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium capitalize ${priorityStyle[t.priority]}`}>{t.priority}</span>
                          <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                            <span>{formatDate(t.dueDate)}</span>
                            <Avatar className="h-5 w-5"><AvatarFallback className="text-[9px] bg-secondary">{t.assignee.split(" ").map((s) => s[0]).join("")}</AvatarFallback></Avatar>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                    {colTasks.length === 0 && (
                      <div className="text-center text-xs text-muted-foreground py-6">No tasks</div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="table" className="mt-4">
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Checkbox checked={allFilteredSelected} onCheckedChange={toggleAll} aria-label="Select all" />
                  </TableHead>
                  <TableHead>Task</TableHead>
                  <TableHead>Project</TableHead>
                  <TableHead>Assignee</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Due</TableHead>
                  <TableHead className="w-12" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell>
                      <Checkbox checked={selection.has(t.id)} onCheckedChange={() => toggle(t.id)} aria-label={`Select ${t.title}`} />
                    </TableCell>
                    <TableCell className="font-medium">{t.title}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{t.project}</TableCell>
                    <TableCell className="text-sm">{t.assignee}</TableCell>
                    <TableCell><Badge variant="outline" className={priorityStyle[t.priority] + " capitalize"}>{t.priority}</Badge></TableCell>
                    <TableCell className="text-sm capitalize">{t.status.replace("_", " ")}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{formatDate(t.dueDate)}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7" aria-label="Task actions"><MoreHorizontal className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => { setEditing(t); setFormOpen(true); }}><Pencil className="h-4 w-4 mr-2" /> Edit</DropdownMenuItem>
                          {t.status !== "done" && (
                            <DropdownMenuItem onClick={() => markComplete(t.id)}><Check className="h-4 w-4 mr-2" /> Mark complete</DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive" onClick={() => setConfirmId(t.id)}><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
                {filtered.length === 0 && (
                  <TableRow><TableCell colSpan={8} className="h-32 text-center text-sm text-muted-foreground">No tasks match your filters.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>

      <TaskForm
        open={formOpen}
        onOpenChange={(v) => { setFormOpen(v); if (!v) setEditing(null); }}
        initial={editing}
        projectOptions={projectOptions}
        assigneeOptions={assigneeOptions}
        onSubmit={handleSubmit}
      />

      <ConfirmDialog
        open={!!confirmId}
        onOpenChange={(v) => !v && setConfirmId(null)}
        title="Delete this task?"
        description="This action cannot be undone."
        confirmLabel="Delete"
        destructive
        onConfirm={() => { if (confirmId) handleDelete(confirmId); setConfirmId(null); }}
      />
      <ConfirmDialog
        open={confirmBulk}
        onOpenChange={setConfirmBulk}
        title={`Delete ${selection.size} tasks?`}
        description="This action cannot be undone."
        confirmLabel="Delete all"
        destructive
        onConfirm={() => { handleBulkDelete(); setConfirmBulk(false); }}
      />
    </PageShell>
  );
}
