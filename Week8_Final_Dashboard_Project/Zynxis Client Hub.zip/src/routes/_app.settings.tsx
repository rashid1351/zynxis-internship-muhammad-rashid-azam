import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useSettingsStore, useThemeStore } from "@/store";
import { useDataStore } from "@/store/data";
import { Sun, Moon, Monitor } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";

export const Route = createFileRoute("/_app/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Zynxis" },
      { name: "description", content: "Configure appearance, language, security and account preferences." },
    ],
  }),
  component: SettingsPage,
});

const prefsSchema = z.object({
  language: z.string().min(2),
  timezone: z.string().min(1),
});

const workspaceSchema = z.object({
  name: z.string().trim().min(2, "Workspace name is required").max(80),
  billingEmail: z.string().trim().email("Invalid email"),
});

const passwordSchema = z
  .object({
    current: z.string().min(1, "Required"),
    next: z.string().min(8, "Use at least 8 characters").max(72),
    confirm: z.string(),
  })
  .refine((v) => v.next === v.confirm, { path: ["confirm"], message: "Passwords do not match" });

function SettingsPage() {
  const theme = useThemeStore((s) => s.theme);
  const setTheme = useThemeStore((s) => s.setTheme);
  const settings = useSettingsStore();
  const resetData = useDataStore((s) => s.resetData);
  const [confirmDanger, setConfirmDanger] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const prefs = useForm<z.infer<typeof prefsSchema>>({
    resolver: zodResolver(prefsSchema),
    defaultValues: { language: settings.language, timezone: settings.timezone },
  });
  const workspace = useForm<z.infer<typeof workspaceSchema>>({
    resolver: zodResolver(workspaceSchema),
    defaultValues: { name: "Zynxis HQ", billingEmail: "billing@zynxis.app" },
  });
  const password = useForm<z.infer<typeof passwordSchema>>({
    resolver: zodResolver(passwordSchema),
    defaultValues: { current: "", next: "", confirm: "" },
  });

  const onPrefs = prefs.handleSubmit((v) => {
    settings.setLanguage(v.language);
    settings.setTimezone(v.timezone);
    toast.success("Preferences saved");
  });

  const onWorkspace = workspace.handleSubmit(async (_v) => {
    await new Promise((r) => setTimeout(r, 250));
    toast.success("Account updated");
  });

  const onPassword = password.handleSubmit(async (_v) => {
    await new Promise((r) => setTimeout(r, 350));
    password.reset({ current: "", next: "", confirm: "" });
    toast.success("Password updated");
  });

  return (
    <PageShell>
      <PageHeader title="Settings" description="Tailor Zynxis to fit how your team operates." />

      <Tabs defaultValue="appearance">
        <TabsList>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
        </TabsList>

        <TabsContent value="appearance" className="mt-4">
          <Card>
            <CardHeader><CardTitle>Theme</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-3 max-w-md">
                {[
                  { v: "light" as const, Icon: Sun, label: "Light" },
                  { v: "dark" as const, Icon: Moon, label: "Dark" },
                  { v: "system" as const, Icon: Monitor, label: "System" },
                ].map(({ v, Icon, label }) => (
                  <button
                    key={v}
                    onClick={() => { setTheme(v); toast.success(`Theme set to ${label.toLowerCase()}`); }}
                    className={cn(
                      "flex flex-col items-center gap-2 rounded-lg border-2 p-4 transition-all",
                      theme === v ? "border-primary bg-primary/5" : "border-border hover:border-primary/40",
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="text-sm font-medium">{label}</span>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences" className="mt-4">
          <Card>
            <CardHeader><CardTitle>Localization</CardTitle></CardHeader>
            <CardContent>
              <form onSubmit={onPrefs} className="space-y-4 max-w-md" noValidate>
                <Field label="Language" error={prefs.formState.errors.language?.message}>
                  <Select value={prefs.watch("language")} onValueChange={(v) => prefs.setValue("language", v, { shouldDirty: true })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en-US">English (US)</SelectItem>
                      <SelectItem value="en-GB">English (UK)</SelectItem>
                      <SelectItem value="es-ES">Español</SelectItem>
                      <SelectItem value="fr-FR">Français</SelectItem>
                      <SelectItem value="de-DE">Deutsch</SelectItem>
                      <SelectItem value="ja-JP">日本語</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Timezone" error={prefs.formState.errors.timezone?.message}>
                  <Select value={prefs.watch("timezone")} onValueChange={(v) => prefs.setValue("timezone", v, { shouldDirty: true })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UTC">UTC</SelectItem>
                      <SelectItem value="America/Los_Angeles">Pacific (US)</SelectItem>
                      <SelectItem value="America/New_York">Eastern (US)</SelectItem>
                      <SelectItem value="Europe/London">London</SelectItem>
                      <SelectItem value="Europe/Berlin">Berlin</SelectItem>
                      <SelectItem value="Asia/Tokyo">Tokyo</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <div className="flex gap-2">
                  <Button type="submit" disabled={prefs.formState.isSubmitting}>Save preferences</Button>
                  <Button type="button" variant="outline" onClick={() => prefs.reset({ language: settings.language, timezone: settings.timezone })}>Reset</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="mt-4">
          <Card>
            <CardHeader><CardTitle>Password</CardTitle></CardHeader>
            <CardContent>
              <form onSubmit={onPassword} className="space-y-3 max-w-md" noValidate>
                <Field label="Current" error={password.formState.errors.current?.message}>
                  <Input type="password" {...password.register("current")} />
                </Field>
                <Field label="New" error={password.formState.errors.next?.message}>
                  <Input type="password" {...password.register("next")} />
                </Field>
                <Field label="Confirm" error={password.formState.errors.confirm?.message}>
                  <Input type="password" {...password.register("confirm")} />
                </Field>
                <Button type="submit" disabled={password.formState.isSubmitting}>
                  {password.formState.isSubmitting ? "Updating…" : "Update password"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account" className="mt-4 space-y-4">
          <Card>
            <CardHeader><CardTitle>Workspace</CardTitle></CardHeader>
            <CardContent>
              <form onSubmit={onWorkspace} className="space-y-4 max-w-md" noValidate>
                <Field label="Workspace name" error={workspace.formState.errors.name?.message}>
                  <Input {...workspace.register("name")} />
                </Field>
                <Field label="Billing email" error={workspace.formState.errors.billingEmail?.message}>
                  <Input type="email" {...workspace.register("billingEmail")} />
                </Field>
                <Button type="submit" disabled={workspace.formState.isSubmitting}>Save</Button>
              </form>
            </CardContent>
          </Card>
          <Card className="border-warning/30">
            <CardHeader><CardTitle className="text-warning">Reset demo data</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">Restore the original sample clients, projects and tasks. Any custom data will be lost.</p>
              <Button variant="outline" onClick={() => setConfirmReset(true)}>Reset workspace data</Button>
            </CardContent>
          </Card>
          <Card className="border-destructive/30">
            <CardHeader><CardTitle className="text-destructive">Danger zone</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">Permanently delete this workspace and all of its data. This action cannot be undone.</p>
              <Button variant="destructive" onClick={() => setConfirmDanger(true)}>Delete workspace</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ConfirmDialog
        open={confirmReset}
        onOpenChange={setConfirmReset}
        title="Reset all workspace data?"
        description="Sample clients, projects and tasks will be restored. Any custom records will be removed."
        confirmLabel="Reset"
        destructive
        onConfirm={() => { resetData(); setConfirmReset(false); toast.success("Workspace data reset"); }}
      />
      <ConfirmDialog
        open={confirmDanger}
        onOpenChange={setConfirmDanger}
        title="Delete this workspace?"
        description="This will permanently delete the workspace and all of its data. This action cannot be undone."
        confirmLabel="Delete workspace"
        destructive
        onConfirm={() => { resetData(); setConfirmDanger(false); toast.success("Workspace deleted (demo)"); }}
      />
    </PageShell>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
