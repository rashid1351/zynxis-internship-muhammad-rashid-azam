import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { useAuthStore } from "@/store";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { Topbar } from "@/components/layout/Topbar";
import { AppFooter } from "@/components/layout/AppFooter";

export const Route = createFileRoute("/_app")({
  beforeLoad: () => {
    if (typeof window === "undefined") return;
    const { isAuthenticated, login } = useAuthStore.getState();
    if (!isAuthenticated) {
      // Auto-login demo user for portfolio demo
      login({
        id: "u_demo",
        name: "Avery Sterling",
        email: "avery@zynxis.app",
        role: "Admin",
        avatar: "https://api.dicebear.com/9.x/initials/svg?seed=Avery%20Sterling",
      });
    }
  },
  component: AppLayout,
});

function AppLayout() {
  return (
    <div className="flex min-h-dvh w-full bg-background">
      <AppSidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-[1600px] w-full mx-auto">
          <Outlet />
        </main>
        <AppFooter />
      </div>
    </div>
  );
}

// Redirect guard helper for auth pages
export function redirectIfAuthed() {
  if (typeof window !== "undefined" && useAuthStore.getState().isAuthenticated) {
    throw redirect({ to: "/" });
  }
}
