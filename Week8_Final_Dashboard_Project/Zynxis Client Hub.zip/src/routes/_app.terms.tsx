import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHeader } from "@/components/layout/PageShell";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_app/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Zynxis Client Dashboard" },
      { name: "description", content: "The terms that govern your use of Zynxis." },
    ],
  }),
  component: TermsPage,
});

const clauses = [
  {
    n: "01",
    title: "Acceptance of terms",
    body: "By accessing Zynxis Client Dashboard you agree to these terms. If you do not agree, do not use the service.",
  },
  {
    n: "02",
    title: "Your account",
    body: "You are responsible for safeguarding your credentials and for any activity in your workspace. Notify us immediately of unauthorized access.",
  },
  {
    n: "03",
    title: "Acceptable use",
    body: "Don't use Zynxis to store unlawful content, attempt to breach security, reverse engineer the platform, or interfere with other customers' workspaces.",
  },
  {
    n: "04",
    title: "Your content",
    body: "You retain full ownership of clients, projects, tasks and any data you create. You grant Zynxis a limited license to process this data solely to operate the service for you.",
  },
  {
    n: "05",
    title: "Service availability",
    body: "We target 99.9% monthly uptime but provide the service on an 'as is' basis. Planned maintenance is announced via the Status page.",
  },
  {
    n: "06",
    title: "Termination",
    body: "You may delete your workspace at any time from Settings. We may suspend accounts that violate these terms with reasonable notice except in cases of abuse.",
  },
  {
    n: "07",
    title: "Limitation of liability",
    body: "To the maximum extent permitted by law, Zynxis is not liable for indirect, incidental or consequential damages arising from your use of the service.",
  },
  {
    n: "08",
    title: "Changes",
    body: "We may update these terms; material changes will be announced in-app at least 14 days before they take effect.",
  },
];

function TermsPage() {
  return (
    <PageShell>
      <PageHeader
        title="Terms of Service"
        description="Effective June 18, 2026 — the agreement between you and Zynxis Labs."
      />
      <Card className="border-border/60">
        <CardContent className="p-0">
          <ol className="divide-y divide-border">
            {clauses.map((c) => (
              <li key={c.n} className="grid grid-cols-[auto_1fr] gap-6 p-6">
                <div className="font-display text-2xl font-bold text-primary tabular-nums">{c.n}</div>
                <div className="space-y-1.5">
                  <div className="font-semibold tracking-tight">{c.title}</div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{c.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </CardContent>
      </Card>
    </PageShell>
  );
}
