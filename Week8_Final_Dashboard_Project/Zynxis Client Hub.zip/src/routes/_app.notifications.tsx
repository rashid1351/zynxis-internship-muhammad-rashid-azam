import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle2, AlertCircle, AlertTriangle, Info, Trash2, Plus } from "lucide-react";
import { useNotificationsStore, type NotificationType } from "@/store";
import { relativeTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { NotificationForm } from "@/components/forms/NotificationForm";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";

export const Route = createFileRoute("/_app/notifications")({
  head: () => ({
    meta: [
      { title: "Notifications — Zynxis" },
      { name: "description", content: "Review, filter and triage notifications across your workspace." },
    ],
  }),
  component: NotificationsPage,
});

const iconFor: Record<NotificationType, { Icon: React.ComponentType<{ className?: string }>; cls: string }> = {
  success: { Icon: CheckCircle2, cls: "text-success bg-success/15" },
  warning: { Icon: AlertTriangle, cls: "text-warning bg-warning/15" },
  error: { Icon: AlertCircle, cls: "text-destructive bg-destructive/15" },
  info: { Icon: Info, cls: "text-info bg-info/15" },
};

function NotificationsPage() {
  const items = useNotificationsStore((s) => s.items);
  const markRead = useNotificationsStore((s) => s.markRead);
  const markAllRead = useNotificationsStore((s) => s.markAllRead);
  const remove = useNotificationsStore((s) => s.remove);
  const add = useNotificationsStore((s) => s.add);
  const [filter, setFilter] = useState<"all" | "unread" | NotificationType>("all");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [formOpen, setFormOpen] = useState(false);
  const [confirmBulk, setConfirmBulk] = useState(false);

  const filtered = useMemo(() => {
    if (filter === "all") return items;
    if (filter === "unread") return items.filter((n) => !n.read);
    return items.filter((n) => n.type === filter);
  }, [items, filter]);

  const toggle = (id: string) =>
    setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const bulkDelete = () => {
    selected.forEach(remove);
    setSelected(new Set());
    toast.success("Notifications removed");
  };

  return (
    <PageShell>
      <PageHeader
        title="Notifications"
        description={`${items.filter((n) => !n.read).length} unread of ${items.length}`}
        action={
          <div className="flex gap-2">
            {selected.size > 0 && (
              <Button variant="destructive" size="sm" onClick={() => setConfirmBulk(true)}>
                <Trash2 className="h-4 w-4 mr-1.5" /> Delete ({selected.size})
              </Button>
            )}
            <Button size="sm" variant="outline" onClick={markAllRead}>Mark all read</Button>
            <Button size="sm" onClick={() => setFormOpen(true)}>
              <Plus className="h-4 w-4 mr-1.5" /> New
            </Button>
          </div>
        }
      />

      <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="unread">Unread</TabsTrigger>
          <TabsTrigger value="success">Success</TabsTrigger>
          <TabsTrigger value="warning">Warning</TabsTrigger>
          <TabsTrigger value="error">Error</TabsTrigger>
          <TabsTrigger value="info">Info</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card className="divide-y">
        {filtered.length === 0 && (
          <div className="p-12 text-center text-sm text-muted-foreground">You're all caught up.</div>
        )}
        {filtered.map((n) => {
          const { Icon, cls } = iconFor[n.type];
          return (
            <div key={n.id} className={cn("flex gap-3 p-4 hover:bg-accent/30 transition-colors", !n.read && "bg-accent/15")}>
              <Checkbox checked={selected.has(n.id)} onCheckedChange={() => toggle(n.id)} className="mt-1" aria-label="Select" />
              <div className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-full", cls)}><Icon className="h-4 w-4" /></div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-medium truncate">{n.title}</div>
                  <div className="text-xs text-muted-foreground shrink-0">{relativeTime(n.createdAt)}</div>
                </div>
                <div className="text-sm text-muted-foreground">{n.message}</div>
                <div className="mt-1.5 flex gap-3">
                  {!n.read && <button onClick={() => markRead(n.id)} className="text-xs text-primary hover:underline">Mark read</button>}
                  <button onClick={() => remove(n.id)} className="text-xs text-muted-foreground hover:text-destructive">Delete</button>
                </div>
              </div>
            </div>
          );
        })}
      </Card>

      <NotificationForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={(v) => { add(v); toast.success("Notification sent"); }}
      />
      <ConfirmDialog
        open={confirmBulk}
        onOpenChange={setConfirmBulk}
        title={`Delete ${selected.size} notifications?`}
        description="This action cannot be undone."
        confirmLabel="Delete all"
        destructive
        onConfirm={() => { bulkDelete(); setConfirmBulk(false); }}
      />
    </PageShell>
  );
}
