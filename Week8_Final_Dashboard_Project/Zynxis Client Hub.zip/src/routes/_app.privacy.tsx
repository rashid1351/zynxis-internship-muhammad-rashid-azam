import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHeader } from "@/components/layout/PageShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Lock, Database, Cookie, UserCheck, Mail } from "lucide-react";

export const Route = createFileRoute("/_app/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Zynxis Client Dashboard" },
      { name: "description", content: "How Zynxis collects, uses and protects your data." },
    ],
  }),
  component: PrivacyPage,
});

const sections = [
  {
    icon: Database,
    title: "Information we collect",
    body: "Account details you provide (name, email, avatar), workspace data you create (clients, projects, tasks, notifications), and minimal telemetry (page views, errors) required to keep Zynxis reliable.",
  },
  {
    icon: UserCheck,
    title: "How we use your data",
    body: "To operate the dashboard, personalize your workspace, secure your account, and respond to support requests. We never sell your data, and we don't use customer workspace data to train external models.",
  },
  {
    icon: Lock,
    title: "Storage & security",
    body: "Workspace data is stored locally in your browser for this demo build. Production deployments use encrypted-at-rest databases (AES-256) and TLS 1.3 in transit, with least-privilege access controls.",
  },
  {
    icon: Cookie,
    title: "Cookies & local storage",
    body: "Zynxis uses local storage to remember your theme, sidebar state, and authentication session. No third-party advertising cookies are set.",
  },
  {
    icon: Shield,
    title: "Your rights",
    body: "You may export, edit, or permanently delete any workspace data from Settings → Danger Zone at any time. Account deletion is immediate and irreversible.",
  },
  {
    icon: Mail,
    title: "Contact",
    body: "Questions about this policy? Reach the privacy team at privacy@zynxis.app — we respond within 5 business days.",
  },
];

function PrivacyPage() {
  return (
    <PageShell>
      <PageHeader
        title="Privacy Policy"
        description="Last updated June 18, 2026 — what we collect, why we collect it, and the controls you have."
      />
      <div className="grid gap-4 md:grid-cols-2">
        {sections.map((s) => (
          <Card key={s.title} className="border-border/60">
            <CardHeader className="flex flex-row items-start gap-3 space-y-0">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                <s.icon className="h-5 w-5" />
              </div>
              <CardTitle className="text-base pt-1.5">{s.title}</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground leading-relaxed">
              {s.body}
            </CardContent>
          </Card>
        ))}
      </div>
    </PageShell>
  );
}
