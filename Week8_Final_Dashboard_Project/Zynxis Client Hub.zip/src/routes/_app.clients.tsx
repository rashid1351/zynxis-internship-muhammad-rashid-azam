import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, PageShell } from "@/components/layout/PageShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Search, Download, MoreHorizontal, Eye, Pencil, Trash2, Plus, ArrowUpDown, FileJson, FileText } from "lucide-react";
import { type Client, type ClientStatus } from "@/lib/mock-data";
import { currency, formatDate, downloadFile, toCSV } from "@/lib/format";
import { toast } from "sonner";
import { useDataStore } from "@/store/data";
import { useNotificationsStore } from "@/store";
import { ClientForm, type ClientFormValues } from "@/components/forms/ClientForm";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";

export const Route = createFileRoute("/_app/clients")({
  head: () => ({
    meta: [
      { title: "Clients — Zynxis" },
      { name: "description", content: "Manage your client roster: search, filter, sort and review activity at a glance." },
    ],
  }),
  component: ClientsPage,
});

const statusStyle: Record<ClientStatus, string> = {
  active: "bg-success/15 text-success border-success/30",
  pending: "bg-warning/15 text-warning border-warning/30",
  suspended: "bg-destructive/15 text-destructive border-destructive/30",
};

function ClientsPage() {
  const clients = useDataStore((s) => s.clients);
  const addClient = useDataStore((s) => s.addClient);
  const updateClient = useDataStore((s) => s.updateClient);
  const deleteClient = useDataStore((s) => s.deleteClient);
  const deleteClients = useDataStore((s) => s.deleteClients);
  const notify = useNotificationsStore((s) => s.add);

  const [q, setQ] = useState("");
  const [status, setStatus] = useState<ClientStatus | "all">("all");
  const [sortBy, setSortBy] = useState<"name" | "revenue" | "joinDate">("revenue");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Client | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [confirmBulk, setConfirmBulk] = useState(false);
  const [rowSelection, setRowSelection] = useState<Set<string>>(new Set());
  const perPage = 8;

  const filtered = useMemo(() => {
    let r = clients.filter((c) =>
      (status === "all" || c.status === status) &&
      (q.trim() === "" || [c.name, c.company, c.email, c.industry].some((f) => f.toLowerCase().includes(q.toLowerCase()))),
    );
    r = [...r].sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name);
      if (sortBy === "revenue") return b.revenue - a.revenue;
      return new Date(b.joinDate).getTime() - new Date(a.joinDate).getTime();
    });
    return r;
  }, [clients, q, status, sortBy]);

  const pageItems = filtered.slice((page - 1) * perPage, page * perPage);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const allPageSelected = pageItems.length > 0 && pageItems.every((c) => rowSelection.has(c.id));

  const toggleRow = (id: string) =>
    setRowSelection((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const togglePage = () =>
    setRowSelection((s) => {
      const n = new Set(s);
      if (allPageSelected) pageItems.forEach((c) => n.delete(c.id));
      else pageItems.forEach((c) => n.add(c.id));
      return n;
    });

  const handleSubmit = (values: ClientFormValues) => {
    if (editing) {
      updateClient(editing.id, values);
      toast.success("Client updated");
      notify({ type: "info", title: "Client updated", message: `${values.name} (${values.company}) details were updated.` });
    } else {
      const c = addClient(values);
      toast.success("Client created");
      notify({ type: "success", title: "New client added", message: `${c.name} from ${c.company} was added to your workspace.` });
    }
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    const c = clients.find((x) => x.id === id);
    deleteClient(id);
    setRowSelection((s) => { const n = new Set(s); n.delete(id); return n; });
    toast.success("Client removed");
    if (c) notify({ type: "warning", title: "Client removed", message: `${c.name} was deleted.` });
  };

  const handleBulkDelete = () => {
    const ids = Array.from(rowSelection);
    deleteClients(ids);
    setRowSelection(new Set());
    toast.success(`${ids.length} clients removed`);
    notify({ type: "warning", title: "Clients removed", message: `${ids.length} clients were deleted in bulk.` });
  };

  const exportCsv = () => {
    const rows = filtered.length === clients.length ? clients : filtered;
    downloadFile("clients.csv", toCSV(rows), "text/csv");
    toast.success("Exported CSV");
  };
  const exportJson = () => {
    downloadFile("clients.json", JSON.stringify(filtered, null, 2), "application/json");
    toast.success("Exported JSON");
  };

  return (
    <PageShell>
      <PageHeader
        title="Clients"
        description={`${filtered.length} of ${clients.length} clients`}
        action={
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-1.5" /> Export</Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={exportCsv}><FileText className="h-4 w-4 mr-2" /> CSV</DropdownMenuItem>
                <DropdownMenuItem onClick={exportJson}><FileJson className="h-4 w-4 mr-2" /> JSON</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button size="sm" onClick={() => { setEditing(null); setFormOpen(true); }}>
              <Plus className="h-4 w-4 mr-1.5" /> Add client
            </Button>
          </div>
        }
      />

      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="Search by name, company, email…" className="pl-9" />
          </div>
          <Select value={status} onValueChange={(v) => { setStatus(v as ClientStatus | "all"); setPage(1); }}>
            <SelectTrigger className="w-full sm:w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="suspended">Suspended</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
            <SelectTrigger className="w-full sm:w-44"><ArrowUpDown className="h-3.5 w-3.5 mr-1.5" /><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="revenue">Revenue (high → low)</SelectItem>
              <SelectItem value="name">Name (A → Z)</SelectItem>
              <SelectItem value="joinDate">Newest first</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {rowSelection.size > 0 && (
          <div className="mb-3 flex items-center justify-between gap-2 rounded-lg border border-border bg-accent/40 px-3 py-2 text-sm">
            <span><strong>{rowSelection.size}</strong> selected</span>
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" onClick={() => setRowSelection(new Set())}>Clear</Button>
              <Button size="sm" variant="destructive" onClick={() => setConfirmBulk(true)}>
                <Trash2 className="h-4 w-4 mr-1.5" /> Delete selected
              </Button>
            </div>
          </div>
        )}

        <div className="rounded-lg border border-border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead className="w-10">
                  <Checkbox checked={allPageSelected} onCheckedChange={togglePage} aria-label="Select page" />
                </TableHead>
                <TableHead>Client</TableHead>
                <TableHead className="hidden md:table-cell">Industry</TableHead>
                <TableHead className="hidden lg:table-cell">Status</TableHead>
                <TableHead className="hidden lg:table-cell">Joined</TableHead>
                <TableHead className="text-right">Revenue</TableHead>
                <TableHead className="w-12" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {pageItems.map((c) => (
                <TableRow key={c.id} className="cursor-pointer" onClick={() => setSelected(c)}>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Checkbox checked={rowSelection.has(c.id)} onCheckedChange={() => toggleRow(c.id)} aria-label={`Select ${c.name}`} />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-9 w-9"><AvatarImage src={c.avatar} alt="" /><AvatarFallback>{c.name[0]}</AvatarFallback></Avatar>
                      <div className="min-w-0">
                        <div className="font-medium truncate">{c.name}</div>
                        <div className="text-xs text-muted-foreground truncate">{c.company}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-muted-foreground">{c.industry}</TableCell>
                  <TableCell className="hidden lg:table-cell">
                    <Badge variant="outline" className={statusStyle[c.status]}>{c.status}</Badge>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">{formatDate(c.joinDate)}</TableCell>
                  <TableCell className="text-right font-semibold tabular-nums">{currency(c.revenue)}</TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" aria-label="Row actions"><MoreHorizontal className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setSelected(c)}><Eye className="h-4 w-4 mr-2" /> View</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { setEditing(c); setFormOpen(true); }}><Pencil className="h-4 w-4 mr-2" /> Edit</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive" onClick={() => setConfirmId(c.id)}><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
              {pageItems.length === 0 && (
                <TableRow><TableCell colSpan={7} className="h-32 text-center text-sm text-muted-foreground">
                  No clients match your filters. <button className="text-primary hover:underline" onClick={() => { setQ(""); setStatus("all"); }}>Reset filters</button>
                </TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
          <div>Page {page} of {totalPages} · {filtered.length} results</div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>Previous</Button>
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</Button>
          </div>
        </div>
      </Card>

      <Sheet open={!!selected} onOpenChange={(v) => !v && setSelected(null)}>
        <SheetContent className="w-full sm:max-w-md">
          {selected && (
            <>
              <SheetHeader>
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12"><AvatarImage src={selected.avatar} alt="" /><AvatarFallback>{selected.name[0]}</AvatarFallback></Avatar>
                  <div>
                    <SheetTitle>{selected.name}</SheetTitle>
                    <SheetDescription>{selected.company}</SheetDescription>
                  </div>
                </div>
              </SheetHeader>
              <div className="mt-6 space-y-4 px-4">
                <Row label="Email" value={selected.email} />
                <Row label="Phone" value={selected.phone} />
                <Row label="Industry" value={selected.industry} />
                <Row label="Status" value={<Badge variant="outline" className={statusStyle[selected.status]}>{selected.status}</Badge>} />
                <Row label="Joined" value={formatDate(selected.joinDate)} />
                <Row label="Revenue" value={<span className="font-semibold">{currency(selected.revenue)}</span>} />
              </div>
              <div className="mt-6 px-4 flex gap-2">
                <Button className="flex-1" onClick={() => { setEditing(selected); setFormOpen(true); setSelected(null); }}>
                  <Pencil className="h-4 w-4 mr-1.5" /> Edit
                </Button>
                <Button variant="destructive" className="flex-1" onClick={() => { setConfirmId(selected.id); setSelected(null); }}>
                  <Trash2 className="h-4 w-4 mr-1.5" /> Delete
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

      <ClientForm
        open={formOpen}
        onOpenChange={(v) => { setFormOpen(v); if (!v) setEditing(null); }}
        initial={editing}
        onSubmit={handleSubmit}
      />

      <ConfirmDialog
        open={!!confirmId}
        onOpenChange={(v) => !v && setConfirmId(null)}
        title="Delete this client?"
        description="This action cannot be undone. The client and their record will be removed from your workspace."
        confirmLabel="Delete"
        destructive
        onConfirm={() => { if (confirmId) handleDelete(confirmId); setConfirmId(null); }}
      />
      <ConfirmDialog
        open={confirmBulk}
        onOpenChange={setConfirmBulk}
        title={`Delete ${rowSelection.size} clients?`}
        description="This action cannot be undone."
        confirmLabel="Delete all"
        destructive
        onConfirm={() => { handleBulkDelete(); setConfirmBulk(false); }}
      />
    </PageShell>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-border/50 pb-3">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-sm text-right">{value}</div>
    </div>
  );
}
