import { Link, useRouterState } from "@tanstack/react-router";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { LayoutDashboard, BarChart3, Users, FolderKanban, ListChecks, User, Bell, Settings } from "lucide-react";
import { Logo } from "@/components/common/Logo";
import { cn } from "@/lib/utils";

import type { LucideIcon } from "lucide-react";
interface NavItem { to: string; label: string; icon: LucideIcon; exact?: boolean; badge?: boolean }
const items: NavItem[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/clients", label: "Clients", icon: Users },
  { to: "/projects", label: "Projects", icon: FolderKanban },
  { to: "/tasks", label: "Tasks", icon: ListChecks },
  { to: "/profile", label: "Profile", icon: User },
  { to: "/notifications", label: "Notifications", icon: Bell },
  { to: "/settings", label: "Settings", icon: Settings },
];

export function MobileNav({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <Sheet open={open} onOpenChange={(v) => !v && onClose()}>
      <SheetContent side="left" className="w-72 p-0 bg-sidebar text-sidebar-foreground">
        <SheetHeader className="h-16 flex-row items-center gap-2 border-b border-sidebar-border px-4 space-y-0">
          <Logo size={36} />
          <SheetTitle className="text-sm font-bold tracking-tight">ZYNXIS</SheetTitle>
        </SheetHeader>
        <nav className="p-2 space-y-1" aria-label="Mobile navigation">
          {items.map(({ to, label, icon: Icon, exact }) => {
            const active = exact ? pathname === to : pathname.startsWith(to);
            return (
              <Link
                key={to} to={to as "/"} onClick={onClose}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium",
                  active ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-muted-foreground hover:bg-sidebar-accent/60",
                )}
              >
                <Icon className="h-4 w-4" /> {label}
              </Link>
            );
          })}
        </nav>
      </SheetContent>
    </Sheet>
  );
}
