import { Link } from "@tanstack/react-router";
import { Github, Twitter, Linkedin, Mail } from "lucide-react";
import { Logo } from "@/components/common/Logo";
import { toast } from "sonner";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const productLinks = [
  { to: "/", label: "Dashboard" },
  { to: "/analytics", label: "Analytics" },
  { to: "/clients", label: "Clients" },
  { to: "/projects", label: "Projects" },
  { to: "/tasks", label: "Tasks" },
] as const;

const accountLinks = [
  { to: "/profile", label: "Profile" },
  { to: "/notifications", label: "Notifications" },
  { to: "/settings", label: "Settings" },
] as const;

export function AppFooter() {
  const [email, setEmail] = useState("");
  const year = new Date().getFullYear();

  function onSubscribe(e: React.FormEvent) {
    e.preventDefault();
    const ok = /.+@.+\..+/.test(email);
    if (!ok) {
      toast.error("Please enter a valid email address.");
      return;
    }
    toast.success(`Subscribed ${email} to the Zynxis newsletter.`);
    setEmail("");
  }

  return (
    <footer className="mt-12 border-t border-border bg-sidebar/40">
      <div className="mx-auto max-w-[1600px] px-4 md:px-6 lg:px-8 py-10 grid gap-10 md:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2 space-y-4">
          <Link to="/" className="inline-flex items-center gap-3">
            <Logo size={40} />
            <div className="leading-tight">
              <div className="font-display text-base font-bold tracking-tight">ZYNXIS</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Client Dashboard</div>
            </div>
          </Link>
          <p className="text-sm text-muted-foreground max-w-xs">
            The enterprise command center for modern teams — clients, projects, analytics and revenue in one polished workspace.
          </p>
          <div className="flex items-center gap-2 pt-1">
            <SocialLink href="https://github.com" label="GitHub"><Github className="h-4 w-4" /></SocialLink>
            <SocialLink href="https://twitter.com" label="Twitter"><Twitter className="h-4 w-4" /></SocialLink>
            <SocialLink href="https://linkedin.com" label="LinkedIn"><Linkedin className="h-4 w-4" /></SocialLink>
            <SocialLink href="mailto:hello@zynxis.app" label="Email"><Mail className="h-4 w-4" /></SocialLink>
          </div>
        </div>

        <FooterColumn title="Product">
          {productLinks.map((l) => (
            <Link key={l.to} to={l.to as "/"} className="text-sm text-muted-foreground hover:text-foreground transition-colors">{l.label}</Link>
          ))}
        </FooterColumn>

        <FooterColumn title="Account">
          {accountLinks.map((l) => (
            <Link key={l.to} to={l.to as "/"} className="text-sm text-muted-foreground hover:text-foreground transition-colors">{l.label}</Link>
          ))}
        </FooterColumn>

        <div className="space-y-3">
          <div className="text-xs font-semibold uppercase tracking-wider text-foreground">Stay in the loop</div>
          <p className="text-sm text-muted-foreground">Monthly product updates. No spam, unsubscribe anytime.</p>
          <form onSubmit={onSubscribe} className="flex gap-2">
            <Input
              type="email"
              required
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              aria-label="Email address"
              className="h-9"
            />
            <Button type="submit" size="sm">Subscribe</Button>
          </form>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto max-w-[1600px] px-4 md:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <div>© {year} Zynxis Labs. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <Link to="/privacy" className="hover:text-foreground transition-colors">Privacy</Link>
            <Link to="/terms" className="hover:text-foreground transition-colors">Terms</Link>
            <Link to="/status" className="hover:text-foreground transition-colors">Status</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <div className="text-xs font-semibold uppercase tracking-wider text-foreground">{title}</div>
      <div className="flex flex-col gap-2">{children}</div>
    </div>
  );
}

function SocialLink({ href, label, children }: { href: string; label: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="grid h-8 w-8 place-items-center rounded-md border border-border bg-background/60 text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
    >
      {children}
    </a>
  );
}
