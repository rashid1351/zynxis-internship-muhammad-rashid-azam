import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { useUIStore, useAuthStore } from "@/store";
import { useDataStore } from "@/store/data";
import { LayoutDashboard, BarChart3, Users, FolderKanban, ListChecks, User, Bell, Settings, LogOut } from "lucide-react";

export function CommandPalette() {
  const open = useUIStore((s) => s.commandOpen);
  const setOpen = useUIStore((s) => s.setCommandOpen);
  const navigate = useNavigate();
  const logout = useAuthStore((s) => s.logout);
  const clients = useDataStore((s) => s.clients);
  const projects = useDataStore((s) => s.projects);
  const tasks = useDataStore((s) => s.tasks);
  const [q, setQ] = useState("");

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen(!open);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, [open, setOpen]);

  useEffect(() => { if (!open) setQ(""); }, [open]);

  const go = (to: string) => {
    setOpen(false);
    navigate({ to });
  };

  const filteredClients = useMemo(
    () => (q ? clients.filter((c) => [c.name, c.company, c.email].some((f) => f.toLowerCase().includes(q.toLowerCase()))) : clients).slice(0, 6),
    [clients, q],
  );
  const filteredProjects = useMemo(
    () => (q ? projects.filter((p) => [p.name, p.client].some((f) => f.toLowerCase().includes(q.toLowerCase()))) : projects).slice(0, 6),
    [projects, q],
  );
  const filteredTasks = useMemo(
    () => (q ? tasks.filter((t) => [t.title, t.assignee, t.project].some((f) => f.toLowerCase().includes(q.toLowerCase()))) : tasks).slice(0, 6),
    [tasks, q],
  );

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput value={q} onValueChange={setQ} placeholder="Search clients, projects, tasks, or jump to a page…" />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Navigate">
          <CommandItem onSelect={() => go("/")}><LayoutDashboard /> Dashboard</CommandItem>
          <CommandItem onSelect={() => go("/analytics")}><BarChart3 /> Analytics</CommandItem>
          <CommandItem onSelect={() => go("/clients")}><Users /> Clients</CommandItem>
          <CommandItem onSelect={() => go("/projects")}><FolderKanban /> Projects</CommandItem>
          <CommandItem onSelect={() => go("/tasks")}><ListChecks /> Tasks</CommandItem>
          <CommandItem onSelect={() => go("/profile")}><User /> Profile</CommandItem>
          <CommandItem onSelect={() => go("/notifications")}><Bell /> Notifications</CommandItem>
          <CommandItem onSelect={() => go("/settings")}><Settings /> Settings</CommandItem>
        </CommandGroup>
        <CommandSeparator />
        {filteredClients.length > 0 && (
          <CommandGroup heading="Clients">
            {filteredClients.map((c) => (
              <CommandItem key={c.id} onSelect={() => go("/clients")}>
                <Users /> {c.name} <span className="ml-auto text-xs text-muted-foreground">{c.company}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {filteredProjects.length > 0 && (
          <CommandGroup heading="Projects">
            {filteredProjects.map((p) => (
              <CommandItem key={p.id} onSelect={() => go("/projects")}>
                <FolderKanban /> {p.name} <span className="ml-auto text-xs text-muted-foreground">{p.client}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {filteredTasks.length > 0 && (
          <CommandGroup heading="Tasks">
            {filteredTasks.map((t) => (
              <CommandItem key={t.id} onSelect={() => go("/tasks")}>
                <ListChecks /> {t.title} <span className="ml-auto text-xs text-muted-foreground">{t.assignee}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        <CommandSeparator />
        <CommandGroup heading="Account">
          <CommandItem onSelect={() => { logout(); go("/auth/login"); }}><LogOut /> Sign out</CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
