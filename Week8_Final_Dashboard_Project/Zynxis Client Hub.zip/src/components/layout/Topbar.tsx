import { useNavigate, Link } from "@tanstack/react-router";
import { Search, Sun, Moon, Bell, LogOut, User as UserIcon, Settings, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useAuthStore, useNotificationsStore, useThemeStore, useUIStore } from "@/store";
import { relativeTime } from "@/lib/format";
import { MobileNav } from "./MobileNav";
import { useState } from "react";
import { cn } from "@/lib/utils";

export function Topbar() {
  const theme = useThemeStore((s) => s.theme);
  const setTheme = useThemeStore((s) => s.setTheme);
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const setCommandOpen = useUIStore((s) => s.setCommandOpen);
  const notifs = useNotificationsStore((s) => s.items);
  const markAllRead = useNotificationsStore((s) => s.markAllRead);
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const unread = notifs.filter((n) => !n.read).length;

  return (
    <>
      <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-background/80 backdrop-blur-xl px-4 md:px-6">
        <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation">
          <Menu className="h-5 w-5" />
        </Button>

        <button
          onClick={() => setCommandOpen(true)}
          className="group flex-1 max-w-md inline-flex items-center gap-2 rounded-lg border border-border bg-muted/50 px-3 py-2 text-sm text-muted-foreground hover:bg-muted transition-colors"
          aria-label="Open search"
        >
          <Search className="h-4 w-4" />
          <span className="hidden sm:inline">Search clients, projects, tasks…</span>
          <span className="sm:hidden">Search</span>
          <kbd className="ml-auto hidden sm:inline rounded border border-border bg-background px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">⌘K</kbd>
        </button>

        <div className="flex items-center gap-1 ml-auto">
          <Button
            variant="ghost" size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label="Toggle theme"
          >
            <Sun className="h-4 w-4 dark:hidden" />
            <Moon className="h-4 w-4 hidden dark:inline" />
          </Button>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="relative" aria-label={`Notifications (${unread} unread)`}>
                <Bell className="h-4 w-4" />
                {unread > 0 && (
                  <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-primary ring-2 ring-background" />
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-80 p-0">
              <div className="flex items-center justify-between px-4 py-3 border-b">
                <div className="text-sm font-semibold">Notifications</div>
                <button onClick={markAllRead} className="text-xs text-muted-foreground hover:text-foreground">Mark all read</button>
              </div>
              <div className="max-h-80 overflow-y-auto scrollbar-thin divide-y">
                {notifs.slice(0, 6).map((n) => (
                  <div key={n.id} className={cn("px-4 py-3 text-sm", !n.read && "bg-accent/30")}>
                    <div className="font-medium">{n.title}</div>
                    <div className="text-xs text-muted-foreground line-clamp-2">{n.message}</div>
                    <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">{relativeTime(n.createdAt)}</div>
                  </div>
                ))}
              </div>
              <Link to="/notifications" className="block px-4 py-2.5 border-t text-center text-xs font-medium text-primary hover:bg-accent">
                View all
              </Link>
            </PopoverContent>
          </Popover>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 rounded-lg px-2 py-1 hover:bg-accent transition-colors" aria-label="Account menu">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user?.avatar} alt="" />
                  <AvatarFallback className="bg-gradient-to-br from-primary to-primary-glow text-primary-foreground text-xs font-semibold">
                    {user?.name?.split(" ").map((s) => s[0]).join("").slice(0, 2) ?? "ZX"}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden lg:block text-left leading-tight">
                  <div className="text-xs font-semibold">{user?.name ?? "Guest"}</div>
                  <div className="text-[10px] text-muted-foreground">{user?.role ?? "Demo"}</div>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>{user?.email ?? "demo@zynxis.app"}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate({ to: "/profile" })}><UserIcon className="mr-2 h-4 w-4" /> Profile</DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate({ to: "/settings" })}><Settings className="mr-2 h-4 w-4" /> Settings</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => { logout(); navigate({ to: "/auth/login" }); }}>
                <LogOut className="mr-2 h-4 w-4" /> Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>
      <MobileNav open={mobileOpen} onClose={() => setMobileOpen(false)} />
    </>
  );
}
