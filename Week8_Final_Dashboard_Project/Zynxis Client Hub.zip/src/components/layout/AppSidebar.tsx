import { Link, useRouterState } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { LayoutDashboard, BarChart3, Users, FolderKanban, ListChecks, User, Bell, Settings, ChevronLeft } from "lucide-react";
import { useUIStore, useNotificationsStore } from "@/store";
import { cn } from "@/lib/utils";
import { Logo } from "@/components/common/Logo";

import type { LucideIcon } from "lucide-react";
interface NavItem { to: string; label: string; icon: LucideIcon; exact?: boolean; badge?: boolean }
const items: NavItem[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/clients", label: "Clients", icon: Users },
  { to: "/projects", label: "Projects", icon: FolderKanban },
  { to: "/tasks", label: "Tasks", icon: ListChecks },
  { to: "/profile", label: "Profile", icon: User },
  { to: "/notifications", label: "Notifications", icon: Bell, badge: true },
  { to: "/settings", label: "Settings", icon: Settings },
];

export function AppSidebar() {
  const collapsed = useUIStore((s) => s.sidebarCollapsed);
  const toggle = useUIStore((s) => s.toggleSidebar);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const unread = useNotificationsStore((s) => s.items.filter((n) => !n.read).length);

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 72 : 256 }}
      transition={{ type: "spring", stiffness: 260, damping: 28 }}
      className="hidden md:flex sticky top-0 h-dvh flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground"
      aria-label="Primary"
    >
      <div className="flex h-16 items-center gap-2 px-4 border-b border-sidebar-border">
        <Logo size={36} className="shrink-0" />
        {!collapsed && (
          <div className="min-w-0 leading-tight">
            <div className="text-sm font-bold tracking-tight">ZYNXIS</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Client Dashboard</div>
          </div>
        )}
      </div>

      <nav className="flex-1 px-2 py-4 space-y-1 scrollbar-thin overflow-y-auto" aria-label="Main">
        {items.map(({ to, label, icon: Icon, exact, badge }) => {
          const active = exact ? pathname === to : pathname.startsWith(to);
          return (
            <Link
              key={to}
              to={to as "/"}
              className={cn(
                "group relative flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
              )}
            >
              {active && (
                <motion.span
                  layoutId="sidebar-active"
                  className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-0.5 rounded-r bg-primary"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <Icon className="h-4 w-4 shrink-0" />
              {!collapsed && <span className="truncate">{label}</span>}
              {!collapsed && badge && unread > 0 && (
                <span className="ml-auto rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-semibold text-primary-foreground">
                  {unread}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      <button
        onClick={toggle}
        className="m-2 inline-flex items-center justify-center gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/40 px-2 py-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        <ChevronLeft className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")} />
        {!collapsed && <span>Collapse</span>}
      </button>
    </motion.aside>
  );
}
