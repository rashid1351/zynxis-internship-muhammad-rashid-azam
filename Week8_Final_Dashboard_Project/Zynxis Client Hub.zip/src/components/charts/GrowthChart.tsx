// Re-export so dynamic imports resolve cleanly
export { GrowthChart } from "./RevenueChart";
