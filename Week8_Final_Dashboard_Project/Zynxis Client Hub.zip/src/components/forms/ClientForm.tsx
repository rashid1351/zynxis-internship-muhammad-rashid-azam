import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { Client, ClientStatus } from "@/lib/mock-data";

const schema = z.object({
  name: z.string().trim().min(2, "Name is too short").max(80),
  company: z.string().trim().min(1, "Company is required").max(80),
  email: z.string().trim().email("Invalid email").max(120),
  phone: z.string().trim().min(4, "Phone is too short").max(40),
  industry: z.string().trim().min(1, "Industry is required"),
  status: z.enum(["active", "pending", "suspended"]),
  revenue: z.coerce.number().min(0, "Revenue must be positive").max(1_000_000_000),
});

export type ClientFormValues = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial?: Client | null;
  onSubmit: (values: ClientFormValues) => Promise<void> | void;
}

const industries = ["SaaS", "Fintech", "Healthcare", "E-commerce", "Education", "Media", "Logistics", "Real Estate"];

export function ClientForm({ open, onOpenChange, initial, onSubmit }: Props) {
  const form = useForm<ClientFormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "", company: "", email: "", phone: "",
      industry: "SaaS", status: "active" as ClientStatus, revenue: 0,
    },
  });

  useEffect(() => {
    if (open) {
      form.reset(
        initial
          ? {
              name: initial.name, company: initial.company, email: initial.email,
              phone: initial.phone, industry: initial.industry, status: initial.status,
              revenue: initial.revenue,
            }
          : { name: "", company: "", email: "", phone: "", industry: "SaaS", status: "active", revenue: 0 },
      );
    }
  }, [open, initial, form]);

  const submit = form.handleSubmit(async (values) => {
    await onSubmit(values);
    onOpenChange(false);
  });

  const status = form.watch("status");
  const industry = form.watch("industry");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{initial ? "Edit client" : "New client"}</DialogTitle>
          <DialogDescription>
            {initial ? "Update client details." : "Add a new client to your workspace."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3" noValidate>
          <Field label="Full name" error={form.formState.errors.name?.message}>
            <Input {...form.register("name")} autoFocus />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Company" error={form.formState.errors.company?.message}>
              <Input {...form.register("company")} />
            </Field>
            <Field label="Industry" error={form.formState.errors.industry?.message}>
              <Select value={industry} onValueChange={(v) => form.setValue("industry", v, { shouldValidate: true })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{industries.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
          </div>
          <Field label="Email" error={form.formState.errors.email?.message}>
            <Input type="email" {...form.register("email")} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Phone" error={form.formState.errors.phone?.message}>
              <Input {...form.register("phone")} />
            </Field>
            <Field label="Status" error={form.formState.errors.status?.message}>
              <Select value={status} onValueChange={(v) => form.setValue("status", v as ClientStatus, { shouldValidate: true })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <Field label="Annual revenue (USD)" error={form.formState.errors.revenue?.message}>
            <Input type="number" min={0} step={100} {...form.register("revenue")} />
          </Field>
          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => form.reset()}>Reset</Button>
            <Button type="submit" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? "Saving…" : initial ? "Save changes" : "Create client"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
