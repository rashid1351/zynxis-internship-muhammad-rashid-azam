import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { Priority, Project, ProjectStatus } from "@/lib/mock-data";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  client: z.string().trim().min(1, "Client is required").max(80),
  description: z.string().trim().max(500),
  budget: z.coerce.number().min(0).max(10_000_000),
  deadline: z.string().min(1, "Deadline is required"),
  team: z.string().trim().max(500),
  progress: z.coerce.number().min(0).max(100),
  priority: z.enum(["low", "medium", "high", "critical"]),
  status: z.enum(["planning", "in_progress", "review", "completed", "cancelled"]),
});

export type ProjectFormValues = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial?: Project | null;
  onSubmit: (values: ProjectFormValues) => Promise<void> | void;
}

export function ProjectForm({ open, onOpenChange, initial, onSubmit }: Props) {
  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "", client: "", description: "", budget: 25000,
      deadline: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10),
      team: "", progress: 0, priority: "medium", status: "planning",
    },
  });

  useEffect(() => {
    if (open) {
      form.reset(
        initial
          ? {
              name: initial.name, client: initial.client, description: initial.description,
              budget: initial.budget, deadline: initial.deadline.slice(0, 10),
              team: initial.team.join(", "), progress: initial.progress,
              priority: initial.priority, status: initial.status,
            }
          : {
              name: "", client: "", description: "", budget: 25000,
              deadline: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10),
              team: "", progress: 0, priority: "medium", status: "planning",
            },
      );
    }
  }, [open, initial, form]);

  const submit = form.handleSubmit(async (values) => {
    await onSubmit(values);
    onOpenChange(false);
  });

  const progress = form.watch("progress");
  const priority = form.watch("priority");
  const status = form.watch("status");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{initial ? "Edit project" : "New project"}</DialogTitle>
          <DialogDescription>
            {initial ? "Update project details and status." : "Create a new project engagement."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3" noValidate>
          <Field label="Name" error={form.formState.errors.name?.message}>
            <Input {...form.register("name")} autoFocus />
          </Field>
          <Field label="Client" error={form.formState.errors.client?.message}>
            <Input {...form.register("client")} />
          </Field>
          <Field label="Description" error={form.formState.errors.description?.message}>
            <Textarea rows={3} {...form.register("description")} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Budget (USD)" error={form.formState.errors.budget?.message}>
              <Input type="number" min={0} step={1000} {...form.register("budget")} />
            </Field>
            <Field label="Deadline" error={form.formState.errors.deadline?.message}>
              <Input type="date" {...form.register("deadline")} />
            </Field>
          </div>
          <Field label="Team (comma-separated)">
            <Input placeholder="Alex Chen, Priya Patel" {...form.register("team")} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Priority">
              <Select value={priority} onValueChange={(v) => form.setValue("priority", v as Priority)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(["low", "medium", "high", "critical"] as Priority[]).map((p) => (
                    <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Status">
              <Select value={status} onValueChange={(v) => form.setValue("status", v as ProjectStatus)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="planning">Planning</SelectItem>
                  <SelectItem value="in_progress">In progress</SelectItem>
                  <SelectItem value="review">Review</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <Field label={`Progress · ${progress}%`}>
            <Slider value={[progress]} max={100} step={1} onValueChange={(v) => form.setValue("progress", v[0])} />
          </Field>
          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => form.reset()}>Reset</Button>
            <Button type="submit" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? "Saving…" : initial ? "Save changes" : "Create project"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
