import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { Priority, Task, TaskStatus } from "@/lib/mock-data";

const schema = z.object({
  title: z.string().trim().min(2).max(120),
  description: z.string().trim().max(500),
  assignee: z.string().trim().min(2, "Assignee is required").max(80),
  project: z.string().trim().min(1, "Project is required").max(80),
  dueDate: z.string().min(1, "Due date is required"),
  priority: z.enum(["low", "medium", "high", "critical"]),
  status: z.enum(["todo", "in_progress", "review", "done"]),
});

export type TaskFormValues = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial?: Task | null;
  projectOptions?: string[];
  assigneeOptions?: string[];
  onSubmit: (values: TaskFormValues) => Promise<void> | void;
}

export function TaskForm({ open, onOpenChange, initial, projectOptions = [], assigneeOptions = [], onSubmit }: Props) {
  const form = useForm<TaskFormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      title: "", description: "", assignee: "", project: "",
      dueDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
      priority: "medium", status: "todo",
    },
  });

  useEffect(() => {
    if (open) {
      form.reset(
        initial
          ? {
              title: initial.title, description: initial.description, assignee: initial.assignee,
              project: initial.project, dueDate: initial.dueDate.slice(0, 10),
              priority: initial.priority, status: initial.status,
            }
          : {
              title: "", description: "", assignee: assigneeOptions[0] ?? "",
              project: projectOptions[0] ?? "",
              dueDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
              priority: "medium", status: "todo",
            },
      );
    }
  }, [open, initial, form, projectOptions, assigneeOptions]);

  const submit = form.handleSubmit(async (values) => {
    await onSubmit(values);
    onOpenChange(false);
  });

  const priority = form.watch("priority");
  const status = form.watch("status");
  const project = form.watch("project");
  const assignee = form.watch("assignee");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{initial ? "Edit task" : "New task"}</DialogTitle>
          <DialogDescription>
            {initial ? "Update task details and progress." : "Create a new task and assign it to a teammate."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3" noValidate>
          <Field label="Title" error={form.formState.errors.title?.message}>
            <Input {...form.register("title")} autoFocus />
          </Field>
          <Field label="Description">
            <Textarea rows={3} {...form.register("description")} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Project" error={form.formState.errors.project?.message}>
              {projectOptions.length > 0 ? (
                <Select value={project} onValueChange={(v) => form.setValue("project", v, { shouldValidate: true })}>
                  <SelectTrigger><SelectValue placeholder="Select project" /></SelectTrigger>
                  <SelectContent>
                    {projectOptions.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              ) : (
                <Input {...form.register("project")} />
              )}
            </Field>
            <Field label="Assignee" error={form.formState.errors.assignee?.message}>
              {assigneeOptions.length > 0 ? (
                <Select value={assignee} onValueChange={(v) => form.setValue("assignee", v, { shouldValidate: true })}>
                  <SelectTrigger><SelectValue placeholder="Assign to" /></SelectTrigger>
                  <SelectContent>
                    {assigneeOptions.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                  </SelectContent>
                </Select>
              ) : (
                <Input {...form.register("assignee")} />
              )}
            </Field>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Due date" error={form.formState.errors.dueDate?.message}>
              <Input type="date" {...form.register("dueDate")} />
            </Field>
            <Field label="Priority">
              <Select value={priority} onValueChange={(v) => form.setValue("priority", v as Priority)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(["low", "medium", "high", "critical"] as Priority[]).map((p) => (
                    <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Status">
              <Select value={status} onValueChange={(v) => form.setValue("status", v as TaskStatus)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todo">To do</SelectItem>
                  <SelectItem value="in_progress">In progress</SelectItem>
                  <SelectItem value="review">Review</SelectItem>
                  <SelectItem value="done">Done</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => form.reset()}>Reset</Button>
            <Button type="submit" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? "Saving…" : initial ? "Save changes" : "Create task"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
