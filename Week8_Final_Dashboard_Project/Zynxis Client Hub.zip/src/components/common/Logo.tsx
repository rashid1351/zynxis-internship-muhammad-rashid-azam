import logoUrl from "@/assets/zynxis-logo.png";
import { cn } from "@/lib/utils";

export function Logo({ className, size = 36 }: { className?: string; size?: number }) {
  return (
    <img
      src={logoUrl}
      alt="Zynxis"
      width={size}
      height={size}
      className={cn("rounded-lg object-cover shadow-elegant", className)}
      loading="eager"
      decoding="async"
    />
  );
}
