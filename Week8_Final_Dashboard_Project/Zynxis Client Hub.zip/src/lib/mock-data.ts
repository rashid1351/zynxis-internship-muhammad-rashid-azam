export type ClientStatus = "active" | "pending" | "suspended";
export interface Client {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  industry: string;
  status: ClientStatus;
  joinDate: string;
  revenue: number;
  avatar?: string;
}

export type ProjectStatus = "planning" | "in_progress" | "review" | "completed" | "cancelled";
export type Priority = "low" | "medium" | "high" | "critical";
export interface Project {
  id: string;
  name: string;
  client: string;
  budget: number;
  deadline: string;
  team: string[];
  progress: number;
  priority: Priority;
  status: ProjectStatus;
  description: string;
}

export type TaskStatus = "todo" | "in_progress" | "review" | "done";
export interface Task {
  id: string;
  title: string;
  description: string;
  assignee: string;
  priority: Priority;
  status: TaskStatus;
  dueDate: string;
  project: string;
}

const industries = ["SaaS", "Fintech", "Healthcare", "E-commerce", "Education", "Media", "Logistics", "Real Estate"];
const companies = ["Helix Labs", "Northwind Analytics", "Aurora Studio", "Quantum Forge", "Vertex Capital", "Lumen Health", "Atlas Logistics", "Cobalt Media", "Nimbus AI", "Sable Realty", "Orbit Commerce", "Pinnacle Edu"];
const firstNames = ["Alex", "Priya", "Jordan", "Maya", "Diego", "Sora", "Lena", "Ethan", "Yuki", "Noah", "Aisha", "Marco"];
const lastNames = ["Chen", "Patel", "Walker", "Nakamura", "Silva", "Kowalski", "Bauer", "Reyes", "O'Neil", "Khan", "Volkov", "Adler"];

function rand<T>(arr: T[], i: number): T { return arr[i % arr.length]; }

export const seedClients: Client[] = Array.from({ length: 24 }, (_, i) => {
  const first = rand(firstNames, i);
  const last = rand(lastNames, i + 3);
  const status: ClientStatus = i % 7 === 0 ? "suspended" : i % 4 === 0 ? "pending" : "active";
  return {
    id: `cli_${i + 1}`,
    name: `${first} ${last}`,
    company: rand(companies, i),
    email: `${first.toLowerCase()}.${last.toLowerCase().replace(/[^a-z]/g, "")}@${rand(companies, i).toLowerCase().replace(/\s+/g, "")}.com`,
    phone: `+1 (${200 + i}) ${100 + i * 7} ${1000 + i * 13}`.slice(0, 20),
    industry: rand(industries, i),
    status,
    joinDate: new Date(Date.now() - (i + 1) * 86400000 * 9).toISOString(),
    revenue: 12000 + ((i * 4283) % 180000),
    avatar: `https://api.dicebear.com/9.x/initials/svg?seed=${encodeURIComponent(first + " " + last)}`,
  };
});

const projectNames = ["Aurora Redesign", "Helios Migration", "Atlas Mobile App", "Quantum Onboarding", "Nimbus Analytics", "Orbit Checkout", "Cobalt Brand System", "Vertex Data Pipeline", "Lumen Patient Portal", "Sable Listing CMS", "Pinnacle LMS", "Northwind Reports"];

export const seedProjects: Project[] = Array.from({ length: 12 }, (_, i) => {
  const statuses: ProjectStatus[] = ["planning", "in_progress", "review", "completed", "cancelled"];
  const priorities: Priority[] = ["low", "medium", "high", "critical"];
  return {
    id: `prj_${i + 1}`,
    name: projectNames[i],
    client: rand(companies, i),
    budget: 25000 + (i * 9173) % 250000,
    deadline: new Date(Date.now() + (i - 2) * 86400000 * 11).toISOString(),
    team: Array.from({ length: 3 + (i % 4) }, (_, j) => `${rand(firstNames, i + j)} ${rand(lastNames, i + j + 1)}`),
    progress: i === 3 ? 100 : Math.min(95, 10 + (i * 17) % 90),
    priority: rand(priorities, i),
    status: rand(statuses, i),
    description: "Cross-functional engagement covering discovery, design, build and launch with weekly stakeholder reviews.",
  };
});

const taskTitles = [
  "Define onboarding KPIs", "Audit checkout funnel", "Refactor billing module", "Design Q4 landing", "Migrate auth to OIDC",
  "Set up uptime alerts", "Polish dashboard charts", "Wire Stripe webhooks", "QA mobile nav", "Write API docs",
  "Review pull requests", "Plan sprint 14", "User research interviews", "Refresh brand guidelines", "Optimize database indices",
  "Roll out feature flags",
];

export const seedTasks: Task[] = taskTitles.map((title, i) => {
  const statuses: TaskStatus[] = ["todo", "in_progress", "review", "done"];
  const priorities: Priority[] = ["low", "medium", "high", "critical"];
  return {
    id: `tsk_${i + 1}`,
    title,
    description: "Owned end-to-end including specification, implementation, review and post-launch validation.",
    assignee: `${rand(firstNames, i)} ${rand(lastNames, i + 1)}`,
    priority: rand(priorities, i),
    status: rand(statuses, i),
    dueDate: new Date(Date.now() + (i - 3) * 86400000 * 2).toISOString(),
    project: rand(projectNames, i),
  };
});

// Time series data
export const revenueSeries = Array.from({ length: 12 }, (_, i) => {
  const month = new Date(2025, i, 1).toLocaleString("en", { month: "short" });
  return {
    month,
    revenue: 42000 + (i * 7813) % 60000 + i * 3200,
    expenses: 18000 + (i * 4221) % 22000 + i * 900,
    profit: 0,
  };
}).map((d) => ({ ...d, profit: d.revenue - d.expenses }));

export const clientGrowth = Array.from({ length: 12 }, (_, i) => ({
  month: new Date(2025, i, 1).toLocaleString("en", { month: "short" }),
  clients: 120 + i * 14 + ((i * 5) % 11),
  churned: 3 + (i % 5),
}));

export const revenueBreakdown = [
  { name: "Subscriptions", value: 412000 },
  { name: "Services", value: 218000 },
  { name: "Licensing", value: 96000 },
  { name: "Add-ons", value: 54000 },
];

export const acquisition = Array.from({ length: 8 }, (_, i) => ({
  week: `W${i + 1}`,
  organic: 12 + (i * 3) % 9,
  paid: 6 + (i * 2) % 7,
  referral: 4 + (i * 5) % 6,
}));

export const weeklyActivity = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => ({
  day,
  sessions: 1200 + (i * 173) % 800,
  conversions: 80 + (i * 31) % 90,
  revenue: 4200 + (i * 521) % 3000,
}));
