# ZYNXIS — Client Dashboard

A premium, enterprise-grade SaaS client management dashboard built as a frontend internship capstone. ZYNXIS delivers a polished command center for clients, projects, tasks, analytics and revenue — comparable to dashboards from Stripe, Linear and Vercel.

> **Live preview:** built with TanStack Start + React 19 + Tailwind v4. Fully responsive, dark/light themed, keyboard-accessible.

---

## ✨ Features

- **Authentication shell** — login, register, forgot/reset password (demo auth, no backend required)
- **Dashboard** — KPIs, revenue & growth charts, recent activity, quick actions
- **Clients** — full CRUD, search, multi-filter, sort, bulk delete, CSV/JSON export
- **Projects** — full CRUD, status & priority filters, progress tracking
- **Tasks** — Kanban board with drag-friendly status transitions, priority management
- **Analytics** — interactive revenue & growth charts (Recharts), exportable datasets
- **Notifications** — triage center with read/unread, filtering, deletion
- **Profile & Settings** — avatar upload, password change, theme switch, danger-zone reset
- **Static pages** — Privacy, Terms, System Status (with uptime visualization)
- **Command Palette** — global ⌘K / Ctrl+K search & navigation
- **Persistent state** — all data stored in `localStorage` via Zustand `persist`
- **Design system** — semantic tokens, gradients, glass surfaces, full dark mode

## 🧱 Tech stack

| Layer | Tech |
|---|---|
| Framework | **TanStack Start v1** (React 19, file-based routing, SSR) |
| Build | **Vite 7** |
| Styling | **Tailwind CSS v4** with CSS variables + `tw-animate-css` |
| UI primitives | **shadcn/ui** (Radix) |
| State | **Zustand** with `persist` middleware |
| Forms | **react-hook-form** + **Zod** |
| Charts | **Recharts** |
| Icons | **lucide-react** |
| Animation | **Framer Motion** |
| Server | **Nitro** (Vercel preset for production) |

## 🚀 Getting started

### Prerequisites

- **Node.js 20+** (or Bun 1.1+)
- **npm**, **pnpm**, or **bun**

### Installation

```bash
git clone <your-repo-url>
cd zynxis-client-dashboard
npm install        # or: bun install
```

### Development

```bash
npm run dev        # vite dev server on http://localhost:8080
```

### Production build

```bash
npm run build      # outputs .vercel/output/ (Vercel preset)
npm run preview    # preview the production build locally
```

### Lint & format

```bash
npm run lint
npm run format
```

## 🌐 Deploying to Vercel

This project is **pre-configured for Vercel** via the Nitro `vercel` preset. No `vercel.json` is required.

### One-time setup

1. Push your code to GitHub / GitLab / Bitbucket.
2. Visit [vercel.com/new](https://vercel.com/new) and import the repository.
3. Vercel auto-detects the framework. Confirm:
   - **Build command**: `npm run build`
   - **Output directory**: *(leave default — Nitro writes to `.vercel/output/`)*
   - **Install command**: `npm install`
4. Click **Deploy**. That's it.

Every push to your default branch triggers a production deploy; every push to other branches creates a preview deployment.

### Environment variables

This project requires **zero** environment variables to run. See `.env.example` — only add `VITE_*` variables if you later wire up an external API.

### SPA routing & deep links

TanStack Start's file-based routing renders every route server-side, so deep links and page refreshes work out of the box — no rewrite rules, no `_redirects`, no 404s on refresh.

## 📁 Project structure

```
src/
├── assets/              CDN-pointer JSON for logo & favicon
├── components/
│   ├── charts/          Recharts wrappers
│   ├── common/          Logo, ConfirmDialog, …
│   ├── forms/           CRUD forms (RHF + Zod)
│   ├── layout/          Sidebar, Topbar, Footer, CommandPalette
│   └── ui/              shadcn primitives
├── features/auth/       Auth shell
├── hooks/
├── lib/                 utilities (formatting, mock data, error pages)
├── routes/              file-based routes (TanStack Router)
│   ├── __root.tsx       root shell, head metadata, providers
│   ├── _app.tsx         authenticated layout (sidebar + topbar + footer)
│   ├── _app.index.tsx   dashboard
│   ├── _app.clients.tsx
│   ├── _app.projects.tsx
│   ├── _app.tasks.tsx
│   ├── _app.analytics.tsx
│   ├── _app.notifications.tsx
│   ├── _app.profile.tsx
│   ├── _app.settings.tsx
│   ├── _app.privacy.tsx
│   ├── _app.terms.tsx
│   ├── _app.status.tsx
│   └── auth.*.tsx       login / register / forgot / reset
├── services/            mock API layer
├── store/               Zustand stores (auth, data)
├── styles.css           Tailwind v4 + design tokens
├── router.tsx           router setup
├── start.ts             TanStack Start instance + middleware
└── server.ts            SSR worker entry (Nitro)
```

## ♿ Accessibility & quality

- Semantic HTML, ARIA labels on icon-only controls
- Keyboard navigation throughout (Tab, ⌘K palette, Esc to dismiss)
- Color contrast tuned in both light & dark modes
- Fully responsive (mobile, tablet, desktop) with a dedicated mobile nav
- Reduced-motion friendly animations

## 📄 License

MIT © Zynxis Labs
